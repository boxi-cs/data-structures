import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.TreeSet;
import org.junit.jupiter.api.Test;

class Ex7ProbingTest {
    static final int[] VIDEO_KEYS = {18, 41, 22, 44, 59, 32, 31, 73};

    static Ex7Probing videoTable(List<List<Integer>> probes) {
        Ex7Probing table = new Ex7Probing(13);
        for (int k : VIDEO_KEYS) {
            table.put(k, String.valueOf(k));
            if (probes != null) {
                probes.add(new ArrayList<>(table.probes()));
            }
        }
        return table;
    }

    @Test
    void theTableOfVideo3() {
        List<List<Integer>> probes = new ArrayList<>();
        Ex7Probing table = videoTable(probes);
        assertEquals(
            List.of(List.of(5), List.of(2), List.of(9), List.of(5, 6), List.of(7), List.of(6, 7, 8),
                List.of(5, 6, 7, 8, 9, 10), List.of(8, 9, 10, 11)),
            probes);
        assertEquals(19, probes.stream().mapToInt(List::size).sum());
        assertEquals(List.of("-", "-", "41", "-", "-", "18", "44", "59", "32", "22", "31", "73", "-"), table.cells());
        assertEquals(8, table.size());
    }

    @Test
    void getAndUpdate() {
        Ex7Probing table = videoTable(null);
        assertEquals("32", table.get(32));
        assertEquals(List.of(6, 7, 8), table.probes());
        assertNull(table.get(99)); // 99 % 13 = 8, stops at the empty slot 12
        assertEquals(List.of(8, 9, 10, 11, 12), table.probes());
        assertEquals("32", table.put(32, "new"));
        assertEquals("new", table.get(32));
        assertEquals(8, table.size());
    }

    @Test
    void wrappingAroundTheEnd() {
        Ex7Probing table = new Ex7Probing(5);
        table.put(4, "a");
        table.put(9, "b"); // 9 % 5 = 4: probes 4, then wraps to 0
        assertEquals(List.of(4, 0), table.probes());
        assertEquals(List.of("9", "-", "-", "-", "4"), table.cells());
        assertNull(table.get(14));
        assertEquals(List.of(4, 0, 1), table.probes());
    }

    @Test
    void negativeKeys() {
        Ex7Probing table = new Ex7Probing(7);
        table.put(-3, "x"); // floorMod(-3, 7) = 4
        assertEquals(List.of(4), table.probes());
        assertEquals("x", table.get(-3));
    }

    @Test
    void aFullTable() {
        Ex7Probing table = new Ex7Probing(4);
        for (int k = 0; k < 4; k++) {
            table.put(k, "v" + k);
        }
        assertNull(table.get(7)); // no empty slot: stop after `capacity` probes
        assertEquals(List.of(3, 0, 1, 2), table.probes());
        assertEquals("v2", table.get(2));
        assertThrows(IllegalStateException.class, () -> table.put(7, "x"));
        assertEquals("v2", table.put(2, "updated")); // an existing key still works
        assertEquals(4, table.size());
    }

    @Test
    void removeLeavesATombstoneAndGetSkipsIt() {
        Ex7Probing table = videoTable(null);
        assertEquals("44", table.remove(44));
        assertEquals(List.of("-", "-", "41", "-", "-", "18", "x", "59", "32", "22", "31", "73", "-"), table.cells());
        assertEquals(7, table.size());
        assertEquals(1, table.tombstones());
        assertEquals("32", table.get(32));
        assertEquals(List.of(6, 7, 8), table.probes()); // still found, past the tombstone
        assertNull(table.get(44));
        assertEquals(List.of(5, 6, 7, 8, 9, 10, 11, 12), table.probes());
        assertThrows(NoSuchElementException.class, () -> table.remove(44));
        assertThrows(NoSuchElementException.class, () -> table.remove(100));
        assertEquals(1, table.tombstones());
    }

    @Test
    void aNewKeyReusesTheFirstTombstone() {
        Ex7Probing table = videoTable(null);
        table.remove(44);
        assertNull(table.put(57, "57")); // 57 % 13 = 5
        assertEquals(List.of(5, 6, 7, 8, 9, 10, 11, 12), table.probes()); // probes to the empty slot 12 ...
        assertEquals(List.of("-", "-", "41", "-", "-", "18", "57", "59", "32", "22", "31", "73", "-"), table.cells()); // ... but is stored in the tombstone
        assertEquals(0, table.tombstones());
        assertEquals(8, table.size());
    }

    @Test
    void anExistingKeyBehindATombstoneIsUpdatedNotDuplicated() {
        Ex7Probing table = videoTable(null);
        table.remove(44);
        assertEquals("32", table.put(32, "again")); // 32 lives past the tombstone at 6
        assertEquals("x", table.cells().get(6));
        assertEquals("32", table.cells().get(8));
        assertEquals(7, table.size());
    }

    @Test
    void aTableWithoutEmptySlotsStillAnswers() {
        Ex7Probing table = new Ex7Probing(5);
        for (int k = 0; k < 5; k++) {
            table.put(k, "v" + k);
        }
        for (int k = 0; k < 5; k++) {
            table.remove(k); // five tombstones, no EMPTY slot, no entries
        }
        assertEquals(List.of("x", "x", "x", "x", "x"), table.cells());
        assertEquals(0, table.size());
        assertNull(table.get(7));
        assertEquals(List.of(2, 3, 4, 0, 1), table.probes());
        assertNull(table.put(7, "seven"));
        assertEquals(List.of("x", "x", "7", "x", "x"), table.cells());
        assertEquals(4, table.tombstones());
        assertEquals("seven", table.get(7));
    }

    @Test
    void randomOperationsMatchAHashMap() {
        Random rng = new Random(11);
        Ex7Probing table = new Ex7Probing(13);
        Map<Integer, String> model = new HashMap<>();
        for (int step = 0; step < 5000; step++) {
            int k = rng.nextInt(40);
            double op = rng.nextDouble();
            if (op < 0.45) {
                if (model.containsKey(k) || model.size() + table.tombstones() < 13 || table.tombstones() > 0) {
                    String v = "v" + k * 10;
                    assertEquals(model.put(k, v), table.put(k, v));
                }
            } else if (op < 0.75) {
                assertEquals(model.get(k), table.get(k));
            } else if (model.containsKey(k)) {
                assertEquals(model.remove(k), table.remove(k));
            } else {
                assertThrows(NoSuchElementException.class, () -> table.remove(k));
            }
            assertEquals(model.size(), table.size());
        }
        TreeSet<String> stored = new TreeSet<>();
        for (String c : table.cells()) {
            if (!c.equals("-") && !c.equals("x")) {
                stored.add(c);
            }
        }
        TreeSet<String> expected = new TreeSet<>();
        for (int k : model.keySet()) {
            expected.add(String.valueOf(k));
        }
        assertEquals(expected, stored);
    }
}
