import java.util.List;

/**
 * Exercise 7 (implementation): a hash map with separate chaining and rehashing, int keys and String values.
 *
 * Three milestones, in order; run the tests after each one.
 *
 * The hash code of an int key is the key itself and the bucket is Math.floorMod(key, capacity) (a plain % would
 * give a negative index for a negative key). Every bucket is a list of entries in insertion order; a new key is
 * APPENDED to its chain.
 *
 * Milestone 1 -- put and get.
 *     put(key, value): if the key is in its chain, replace the value and return the OLD value (the size does not
 *     change); otherwise append the entry to the chain, increase the size and return null.
 *     get(key): the value of the key, or null.
 *     Both set lastComparisons() to the number of keys compared while walking the chain: when the key is found at
 *     position p of the chain (0-based) that is p + 1; when it is not in the chain it is the length of the chain
 *     (video 2: get(12) = 1, get(16) = 3 and get(9) = 3 in the map of the video).
 *     size() is the number of entries; keys() lists the keys bucket by bucket, each chain in order, for the tests;
 *     bucketKeys(i) lists the keys of bucket i.
 * Milestone 2 -- remove(key): delete the entry and return its value; throw NoSuchElementException if the key is
 *     missing (and set lastComparisons as for get).
 * Milestone 3 -- rehashing. After a put that ADDED an entry, if maxLoad > 0 and size > maxLoad * capacity, build a new
 *     table of nextPrime(2 * capacity) buckets and insert every entry again (walk the old buckets in order, each chain
 *     in order, and append each entry to its new chain). Count the entries re-inserted in moves() (all rehashes
 *     together) and record every new capacity in capacities() (starting with the initial one). maxLoad <= 0 never
 *     rehashes.
 */
public final class Ex7Chained {
    /** Given: the smallest prime >= n. */
    public static int nextPrime(int n) {
        while (!isPrime(n)) {
            n++;
        }
        return n;
    }

    /** Given. */
    public static boolean isPrime(int n) {
        if (n < 2) {
            return false;
        }
        for (int d = 2; (long) d * d <= n; d++) {
            if (n % d == 0) {
                return false;
            }
        }
        return true;
    }

    public Ex7Chained(int capacity, double maxLoad) {
        throw new UnsupportedOperationException("not implemented");
    }

    public int size() {
        throw new UnsupportedOperationException("not implemented");
    }

    public int capacity() {
        throw new UnsupportedOperationException("not implemented");
    }

    public long moves() {
        throw new UnsupportedOperationException("not implemented");
    }

    public List<Integer> capacities() {
        throw new UnsupportedOperationException("not implemented");
    }

    public int lastComparisons() {
        throw new UnsupportedOperationException("not implemented");
    }

    public String put(int key, String value) {
        throw new UnsupportedOperationException("not implemented");
    }

    public String get(int key) {
        throw new UnsupportedOperationException("not implemented");
    }

    public String remove(int key) {
        throw new UnsupportedOperationException("not implemented");
    }

    public List<Integer> keys() {
        throw new UnsupportedOperationException("not implemented");
    }

    public List<Integer> bucketKeys(int i) {
        throw new UnsupportedOperationException("not implemented");
    }
}
