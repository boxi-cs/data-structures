import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

class Ex7HashTest {
    /** The same polynomial with exact integers, wrapped to a signed 32-bit value once at the end. */
    static int reference(String s, int base) {
        BigInteger total = BigInteger.ZERO;
        BigInteger b = BigInteger.valueOf(base);
        for (int i = 0; i < s.length(); i++) {
            total = total.multiply(b).add(BigInteger.valueOf(s.charAt(i)));
        }
        return total.intValue(); // intValue keeps the low 32 bits, like Java int arithmetic
    }

    static List<String> anagrams() {
        List<String> out = new ArrayList<>();
        permute("", "abcdef", out);
        return out;
    }

    static void permute(String prefix, String rest, List<String> out) {
        if (rest.isEmpty()) {
            out.add(prefix);
            return;
        }
        for (int i = 0; i < rest.length(); i++) {
            permute(prefix + rest.charAt(i), rest.substring(0, i) + rest.substring(i + 1), out);
        }
    }

    @Test
    void theNumbersOfVideo1() {
        assertEquals(99162322, Ex7Hash.polyHash("hello", 31));
        assertEquals(3540994, Ex7Hash.polyHash("stop", 31));
        assertEquals(3446974, Ex7Hash.polyHash("pots", 31));
        assertEquals(2112, Ex7Hash.polyHash("Aa", 31));
        assertEquals(2112, Ex7Hash.polyHash("BB", 31));
        assertEquals(0, Ex7Hash.polyHash("", 31));
        assertEquals(454, Ex7Hash.sumHash("stop"));
        assertEquals(454, Ex7Hash.sumHash("pots"));
    }

    @Test
    void theMostNegativeInt() {
        assertEquals(Integer.MIN_VALUE, Ex7Hash.polyHash("polygenelubricants", 31));
    }

    @Test
    void base31IsStringHashCodeAndOtherBasesMatchTheExactPolynomial() {
        String[] words = {"a", "ab", "hello world, this is a long enough string to overflow 32 bits many times", "zzzzzzzzzzzz"};
        for (String s : words) {
            assertEquals(s.hashCode(), Ex7Hash.polyHash(s, 31));
            for (int base : new int[] {33, 131, 65599}) {
                assertEquals(reference(s, base), Ex7Hash.polyHash(s, base));
            }
        }
    }

    @Test
    void compressIsNeverNegative() {
        assertEquals(12, Ex7Hash.compress(99162322, 13));
        assertEquals(4, Ex7Hash.compress(-3, 7));
        assertEquals(2, Ex7Hash.compress(Integer.MIN_VALUE, 10));
        for (int h : new int[] {-100, -1, 0, 1, 100, Integer.MAX_VALUE, Integer.MIN_VALUE}) {
            for (int m : new int[] {1, 2, 7, 13, 1009}) {
                int index = Ex7Hash.compress(h, m);
                assertTrue(0 <= index && index < m, h + " mod " + m + " gave " + index);
            }
        }
    }

    @Test
    void primes() {
        List<Integer> primes = new ArrayList<>();
        for (int p = 2; p < 40; p++) {
            if (Ex7Hash.isPrime(p)) {
                primes.add(p);
            }
        }
        assertEquals(List.of(2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37), primes);
        assertFalse(Ex7Hash.isPrime(1));
        assertFalse(Ex7Hash.isPrime(0));
        assertFalse(Ex7Hash.isPrime(-7));
        assertEquals(17, Ex7Hash.nextPrime(14));
        assertEquals(17, Ex7Hash.nextPrime(17));
        assertEquals(1361, Ex7Hash.nextPrime(2 * 673));
        assertEquals(2, Ex7Hash.nextPrime(1));
    }

    @Test
    void bucketStatsSmall() {
        assertArrayEquals(new int[] {1, 3, 4}, Ex7Hash.bucketStats(List.of("a", "b", "c"), k -> 0, 5));
        assertArrayEquals(new int[] {3, 1, 0}, Ex7Hash.bucketStats(List.of("a", "b", "c"), k -> k.charAt(0), 3));
    }

    @Test
    void anagramsWithTheBadHash() {
        List<String> keys = anagrams();
        assertEquals(720, keys.size());
        assertArrayEquals(new int[] {1, 720, 1008}, Ex7Hash.bucketStats(keys, Ex7Hash::sumHash, 1009));
    }

    @Test
    void anagramsWithThePolynomialHash() {
        assertArrayEquals(new int[] {720, 4, 514}, Ex7Hash.bucketStats(anagrams(), s -> Ex7Hash.polyHash(s, 31), 1009));
    }
}
