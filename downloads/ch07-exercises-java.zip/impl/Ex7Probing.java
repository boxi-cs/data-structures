import java.util.List;

/**
 * Exercise 8 (implementation): open addressing with linear probing and tombstones, int keys, String values,
 * fixed capacity.
 *
 * Three milestones, in order; run the tests after each one.
 *
 * The hash code of an int key is the key itself. The i-th slot probed for a key is
 * (Math.floorMod(key, capacity) + i) % capacity for i = 0, 1, 2, ... (video 3). A slot is EMPTY (never used), a
 * tombstone (DELETED) or holds a key and a value. probes() is the list of slots probed by the last operation, in order.
 *
 * Milestone 1 -- put and get, no deletions yet.
 *     put(key, value): probe until the key is found (replace its value, return the old one) or an EMPTY slot is
 *     reached (store the entry there, size + 1, return null). get(key) probes the same way and returns the value or
 *     null. Probe at most `capacity` slots: when no slot is EMPTY and the key is not found, get returns null, and
 *     put throws IllegalStateException("table full") if the key is new and no slot can take it.
 *     cells() returns the table as a list of strings: "-" for an EMPTY slot, "x" for a tombstone, the key as text
 *     otherwise. In the table of video 3 (13 slots, keys 18, 41, 22, 44, 59, 32, 31, 73 in this order) the probes
 *     are [5] [2] [9] [5, 6] [7] [6, 7, 8] [5, 6, 7, 8, 9, 10] [8, 9, 10, 11] (19 probes for the eight puts).
 * Milestone 2 -- remove(key) with a TOMBSTONE: turn the slot of the key into a tombstone (tombstones + 1, size - 1) and
 *     return its value; throw NoSuchElementException if the key is missing. The probe loops must now SKIP
 *     tombstones (a tombstone never stops a search and never equals a key): after removing 44, get(32) must still
 *     find 32 with probes [6, 7, 8].
 * Milestone 3 -- reuse tombstones. A put of a NEW key still probes until an EMPTY slot (to be sure the key is not
 *     further along), but then stores the entry in the FIRST tombstone met on the way (tombstones - 1) and only
 *     otherwise in the EMPTY slot. A table with no EMPTY slot at all (every slot an entry or a tombstone) must still
 *     answer: get of a missing key probes `capacity` slots and returns null, and put of a new key uses a tombstone.
 */
public final class Ex7Probing {
    public Ex7Probing(int capacity) {
        throw new UnsupportedOperationException("not implemented");
    }

    public int size() {
        throw new UnsupportedOperationException("not implemented");
    }

    public int tombstones() {
        throw new UnsupportedOperationException("not implemented");
    }

    public List<Integer> probes() {
        throw new UnsupportedOperationException("not implemented");
    }

    public String put(int key, String value) {
        throw new UnsupportedOperationException("not implemented");
    }

    public String get(int key) {
        throw new UnsupportedOperationException("not implemented");
    }

    public String remove(int key) {
        throw new UnsupportedOperationException("not implemented");
    }

    public List<String> cells() {
        throw new UnsupportedOperationException("not implemented");
    }
}
