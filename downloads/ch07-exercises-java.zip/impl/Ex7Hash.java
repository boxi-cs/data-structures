import java.util.List;
import java.util.function.ToIntFunction;

/**
 * Exercise 6 (implementation): hash codes, compression and a look at how well a hash spreads keys.
 *
 * Three milestones, in order; run the tests after each one.
 *
 * Milestone 1 -- the polynomial string hash of video 1.
 *     polyHash(s, base) is h = s[0]*base^(n-1) + s[1]*base^(n-2) + ... + s[n-1], every character taken as its
 *     char code, computed with the loop  h = base * h + c  in plain int arithmetic (Java ints wrap around at 32
 *     bits by themselves). With base 31 it equals s.hashCode(), but write the loop yourself: the tests also use
 *     other bases. The empty string has hash code 0.
 * Milestone 2 -- compression and primes.
 *     compress(h, m) maps a hash code (it may be negative!) to a table index 0 ... m - 1; remember that the %
 *     operator keeps the sign of the left side, so -3 % 7 is -3 in Java.
 *     nextPrime(n) is the smallest prime >= n (use isPrime, which you also write).
 * Milestone 3 -- measure a hash function.
 *     bucketStats(keys, hash, m) puts every key in the bucket compress(hash.applyAsInt(key), m) and returns
 *     {distinct, longest, empty}: the number of distinct hash codes, the length of the longest bucket and the number
 *     of empty buckets. The tests repeat the experiment of video 1 on the 720 anagrams of "abcdef".
 */
public final class Ex7Hash {
    private Ex7Hash() {}

    public static int polyHash(String s, int base) {
        throw new UnsupportedOperationException("not implemented");
    }

    /** The bad hash of video 1 (given): add up the character codes. */
    public static int sumHash(String s) {
        int sum = 0;
        for (int i = 0; i < s.length(); i++) {
            sum += s.charAt(i);
        }
        return sum;
    }

    public static int compress(int h, int m) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static boolean isPrime(int n) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static int nextPrime(int n) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static int[] bucketStats(List<String> keys, ToIntFunction<String> hash, int m) {
        throw new UnsupportedOperationException("not implemented");
    }
}
