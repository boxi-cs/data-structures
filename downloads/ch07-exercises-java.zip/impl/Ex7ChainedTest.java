import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.TreeSet;
import org.junit.jupiter.api.Test;

class Ex7ChainedTest {
    static final int[] VIDEO_KEYS = {12, 44, 13, 88, 23, 94, 11, 39, 20, 16};

    static Ex7Chained videoMap() {
        Ex7Chained table = new Ex7Chained(7, 0);
        for (int k : VIDEO_KEYS) {
            table.put(k, String.valueOf(k));
        }
        return table;
    }

    @Test
    void theChainsOfVideo2() {
        Ex7Chained table = videoMap();
        assertEquals(10, table.size());
        assertEquals(List.of(), table.bucketKeys(0));
        assertEquals(List.of(), table.bucketKeys(1));
        assertEquals(List.of(44, 23, 16), table.bucketKeys(2));
        assertEquals(List.of(94), table.bucketKeys(3));
        assertEquals(List.of(88, 11, 39), table.bucketKeys(4));
        assertEquals(List.of(12), table.bucketKeys(5));
        assertEquals(List.of(13, 20), table.bucketKeys(6));
        assertEquals(List.of(44, 23, 16, 94, 88, 11, 39, 12, 13, 20), table.keys());
    }

    @Test
    void putReturnsTheOldValueAndDoesNotGrow() {
        Ex7Chained table = new Ex7Chained(7, 0);
        assertNull(table.put(5, "a"));
        assertNull(table.put(12, "b")); // 12 % 7 = 5, the same chain
        assertEquals("a", table.put(5, "c"));
        assertEquals(2, table.size());
        assertEquals("c", table.get(5));
        assertEquals("b", table.get(12));
        assertEquals(List.of(5, 12), table.bucketKeys(5)); // the position of 5 did not change
    }

    @Test
    void comparisonsOfVideo2() {
        Ex7Chained table = videoMap();
        assertEquals("12", table.get(12));
        assertEquals(1, table.lastComparisons());
        assertEquals("16", table.get(16));
        assertEquals(3, table.lastComparisons());
        assertNull(table.get(9));
        assertEquals(3, table.lastComparisons());
        assertNull(table.get(0));
        assertEquals(0, table.lastComparisons()); // an empty chain: nothing to compare
        int total = 0;
        for (int k : VIDEO_KEYS) {
            table.get(k);
            total += table.lastComparisons();
        }
        assertEquals(17, total); // 1.70 on average, the number of video 2
    }

    @Test
    void negativeKeysUseAValidBucket() {
        Ex7Chained table = new Ex7Chained(7, 0);
        table.put(-3, "x");
        assertEquals(List.of(-3), table.bucketKeys(4)); // floorMod(-3, 7) = 4
        assertEquals("x", table.get(-3));
    }

    @Test
    void remove() {
        Ex7Chained table = videoMap();
        assertEquals("23", table.remove(23));
        assertEquals(9, table.size());
        assertEquals(List.of(44, 16, 94, 88, 11, 39, 12, 13, 20), table.keys());
        assertEquals(2, table.lastComparisons());
        assertNull(table.get(23));
        assertThrows(NoSuchElementException.class, () -> table.remove(23));
        assertEquals(2, table.lastComparisons()); // the chain of bucket 2 now has two keys
        assertThrows(NoSuchElementException.class, () -> table.remove(1)); // an empty chain
        assertEquals(9, table.size());
    }

    @Test
    void rehashing1000PutsLikeVideo4() {
        Ex7Chained table = new Ex7Chained(7, 0.75);
        for (int k = 0; k < 1000; k++) {
            table.put(k, String.valueOf(k));
        }
        assertEquals(List.of(7, 17, 37, 79, 163, 331, 673, 1361), table.capacities());
        assertEquals(984, table.moves());
        assertEquals(1000, table.size());
        assertEquals(1361, table.capacity());
        for (int k = 0; k < 1000; k++) {
            assertEquals(String.valueOf(k), table.get(k));
        }
    }

    @Test
    void theFirstRehashHappensWhenTheSixthEntryArrives() {
        Ex7Chained table = new Ex7Chained(7, 0.75);
        for (int k = 0; k < 5; k++) {
            table.put(k, "v");
        }
        assertEquals(7, table.capacity());
        assertEquals(0, table.moves()); // 5 > 0.75 * 7 = 5.25 is false
        table.put(5, "v");
        assertEquals(17, table.capacity());
        assertEquals(6, table.moves());
        assertEquals(List.of(5), table.bucketKeys(5)); // the entries moved: 5 % 17 = 5, not 5 % 7
        table.put(5, "again"); // an update must not rehash
        assertEquals(17, table.capacity());
        assertEquals(6, table.moves());
    }

    @Test
    void noRehashWithoutMaxLoad() {
        Ex7Chained table = new Ex7Chained(7, 0);
        for (int k = 0; k < 100; k++) {
            table.put(k, "v");
        }
        assertEquals(7, table.capacity());
        assertEquals(0, table.moves());
        int longest = 0;
        for (int i = 0; i < 7; i++) {
            longest = Math.max(longest, table.bucketKeys(i).size());
        }
        assertEquals(15, longest);
    }

    @Test
    void randomOperationsMatchAHashMap() {
        Random rng = new Random(7);
        Ex7Chained table = new Ex7Chained(7, 0.75);
        Map<Integer, String> model = new HashMap<>();
        for (int step = 0; step < 4000; step++) {
            int k = rng.nextInt(120) - 60;
            double op = rng.nextDouble();
            if (op < 0.5) {
                String v = "v" + rng.nextInt(1000);
                assertEquals(model.put(k, v), table.put(k, v));
            } else if (op < 0.8) {
                assertEquals(model.get(k), table.get(k));
            } else if (model.containsKey(k)) {
                assertEquals(model.remove(k), table.remove(k));
            } else {
                assertThrows(NoSuchElementException.class, () -> table.remove(k));
            }
            assertEquals(model.size(), table.size());
        }
        assertEquals(new TreeSet<>(model.keySet()), new TreeSet<>(table.keys()));
        assertTrue(table.capacity() >= model.size() / 0.75 - 1);
    }
}
