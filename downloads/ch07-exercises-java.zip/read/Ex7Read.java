import java.util.Objects;

/**
 * Exercises 9 and 10 (read the code). Each class below came from an AI assistant together with a claim.
 *
 * In both exercises the claim is wrong because of a bug. For each: find a small input that shows the bug, say what
 * exactly goes wrong and why the usual quick test does not show it, and write the fix.
 *
 * Exercise 9:  Reading -- "a sensor reading for use as a HashMap key; two readings with the same temperature are
 *                          equal and are the same key".
 * Exercise 10: Probe10 -- "open addressing with linear probing and tombstones; put, get and remove always
 *                          terminate and take O(1) on average".
 */
public final class Ex7Read {
    private Ex7Read() {}

    /** A sensor reading. Two readings with the same temperature are equal and are the same HashMap key. */
    public static final class Reading {
        private final int number; // which reading it was: 1, 2, 3, ...
        private final int temperature;

        public Reading(int number, int temperature) {
            this.number = number;
            this.temperature = temperature;
        }

        @Override
        public boolean equals(Object other) {
            return other instanceof Reading r && r.temperature == temperature;
        }

        @Override
        public int hashCode() {
            return Objects.hash(number, temperature);
        }

        @Override
        public String toString() {
            return "Reading(" + number + ", " + temperature + ")";
        }
    }

    /** Open addressing with linear probing and tombstones, int keys. put, get and remove always terminate and
     * take O(1) on average. */
    public static class Probe10 {
        private static final int EMPTY = 0;
        private static final int USED = 1;
        private static final int DELETED = 2; // tombstone

        private final int[] state;
        private final int[] keys;
        private final String[] values;
        private int size;

        public Probe10(int capacity) {
            state = new int[capacity];
            keys = new int[capacity];
            values = new String[capacity];
        }

        public int size() {
            return size;
        }

        protected int next(int i) {
            return (i + 1) % keys.length;
        }

        /** The slot where the key is, or the first EMPTY slot of its probe sequence. */
        private int find(int key) {
            int i = Math.floorMod(key, keys.length);
            while (state[i] != EMPTY && !(state[i] == USED && keys[i] == key)) { // a tombstone matches no key
                i = next(i);
            }
            return i;
        }

        public String get(int key) {
            int i = find(key);
            return state[i] == USED ? values[i] : null;
        }

        public String put(int key, String value) {
            int i = find(key);
            String old = state[i] == USED ? values[i] : null;
            if (state[i] == EMPTY) {
                size++;
            }
            state[i] = USED;
            keys[i] = key;
            values[i] = value;
            return old;
        }

        public String remove(int key) {
            int i = find(key);
            if (state[i] == EMPTY) {
                throw new java.util.NoSuchElementException(String.valueOf(key));
            }
            String value = values[i];
            state[i] = DELETED;
            values[i] = null;
            size--;
            return value;
        }
    }
}
