import java.util.List;
import java.util.Map;

/**
 * Exercise 6 (implementation): breadth-first search with levels and parents.
 *
 * graph: a Map that gives, for every vertex, the List of its neighbours (an undirected edge appears in both lists).
 * Visit the neighbours in the order of the list, and fetch a vertex's list with graph.get(u) (the tests count the calls).
 *
 * Three milestones, in order; run the tests after each one.
 * Milestone 1 -- bfs(graph, start) returns a Result whose order() is the list of vertices in the order a queue-based
 *     search takes them out of the queue. Only vertices reachable from start appear.
 * Milestone 2 -- level().get(v) is the number of edges on a route from start to v with the fewest edges (start: 0).
 * Milestone 3 -- parent().get(v) is the vertex from which v was discovered (null for start); following parents from any v
 *     leads back to start along a route with level(v) edges. The cost must be right as well: the adjacency list of every
 *     reachable vertex is fetched exactly ONCE, so mark a vertex the moment it is put into the queue, not when it is
 *     taken out.
 */
public final class Ex9Bfs {
    private Ex9Bfs() {}

    public record Result<V>(List<V> order, Map<V, Integer> level, Map<V, V> parent) {}

    public static <V> Result<V> bfs(Map<V, List<V>> graph, V start) {
        throw new UnsupportedOperationException("not implemented");
    }
}
