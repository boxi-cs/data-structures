import java.util.List;
import java.util.Map;

/**
 * Exercise 7 (implementation): routes from BFS parents. You may call your Ex9Bfs.bfs (or write the search again).
 *
 * Milestone 1 -- pathFromParents(parent, target): the route start -> target, found by following parents back from target
 *     and reversing. A one-element list if target is the start, null if target is not a key of parent (unreachable).
 * Milestone 2 -- shortestPath(graph, source, target): a route with the fewest edges, or null when there is none.
 * Milestone 3 -- countShortestPaths(graph, source): for every reachable vertex, the NUMBER of different routes with the
 *     fewest edges from source (source itself: 1). Hint: a vertex u at level d adds ways(u) to every neighbour v at
 *     level d + 1, and to nobody else.
 */
public final class Ex9Paths {
    private Ex9Paths() {}

    public static <V> List<V> pathFromParents(Map<V, V> parent, V target) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static <V> List<V> shortestPath(Map<V, List<V>> graph, V source, V target) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static <V> Map<V, Long> countShortestPaths(Map<V, List<V>> graph, V source) {
        throw new UnsupportedOperationException("not implemented");
    }
}
