import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import org.junit.jupiter.api.Test;

class Ex9PathsTest {
    static Map<String, List<String>> example() {
        Map<String, List<String>> g = new HashMap<>();
        g.put("A", List.of("B", "D"));
        g.put("B", List.of("A", "C", "D", "E"));
        g.put("C", List.of("B", "E"));
        g.put("D", List.of("A", "B", "E", "F"));
        g.put("E", List.of("B", "C", "D", "F", "G"));
        g.put("F", List.of("D", "E", "G"));
        g.put("G", List.of("E", "F"));
        return g;
    }

    static Map<Integer, List<Integer>> randomGraph(Random rng, int n, double p) {
        Map<Integer, List<Integer>> g = new HashMap<>();
        for (int v = 0; v < n; v++) {
            g.put(v, new ArrayList<>());
        }
        for (int a = 0; a < n; a++) {
            for (int b = a + 1; b < n; b++) {
                if (rng.nextDouble() < p) {
                    g.get(a).add(b);
                    g.get(b).add(a);
                }
            }
        }
        return g;
    }

    /** Every simple path from s to t (brute force). */
    static void walk(Map<Integer, List<Integer>> g, List<Integer> path, int t, List<List<Integer>> out) {
        int u = path.get(path.size() - 1);
        if (u == t) {
            out.add(new ArrayList<>(path));
            return;
        }
        for (int v : g.get(u)) {
            if (!path.contains(v)) {
                path.add(v);
                walk(g, path, t, out);
                path.remove(path.size() - 1);
            }
        }
    }

    static List<List<Integer>> allSimplePaths(Map<Integer, List<Integer>> g, int s, int t) {
        List<List<Integer>> out = new ArrayList<>();
        List<Integer> path = new ArrayList<>();
        path.add(s);
        walk(g, path, t, out);
        return out;
    }

    @Test
    void milestone1FollowTheParentsBack() {
        Map<String, String> parent = new HashMap<>();
        parent.put("A", null);
        parent.put("B", "A");
        parent.put("D", "A");
        parent.put("C", "B");
        parent.put("E", "B");
        assertEquals(List.of("A", "B", "C"), Ex9Paths.pathFromParents(parent, "C"));
        assertEquals(List.of("A"), Ex9Paths.pathFromParents(parent, "A"));
        assertNull(Ex9Paths.pathFromParents(parent, "Z"));
    }

    @Test
    void milestone1TheInputIsNotChanged() {
        Map<String, String> parent = new HashMap<>();
        parent.put("A", null);
        parent.put("B", "A");
        parent.put("C", "B");
        Ex9Paths.pathFromParents(parent, "C");
        assertEquals(3, parent.size());
        assertEquals("B", parent.get("C"));
    }

    @Test
    void milestone2ExampleGraph() {
        List<String> route = Ex9Paths.shortestPath(example(), "A", "G");
        assertEquals("A", route.get(0));
        assertEquals("G", route.get(route.size() - 1));
        assertEquals(4, route.size()); // three edges: A B E G, A D E G or A D F G
        for (int i = 0; i + 1 < route.size(); i++) {
            assertTrue(example().get(route.get(i)).contains(route.get(i + 1)));
        }
        assertEquals(List.of("A"), Ex9Paths.shortestPath(example(), "A", "A"));
    }

    @Test
    void milestone2UnreachableGivesNull() {
        Map<String, List<String>> g = new HashMap<>();
        g.put("A", List.of("B"));
        g.put("B", List.of("A"));
        g.put("C", List.of());
        assertNull(Ex9Paths.shortestPath(g, "A", "C"));
    }

    @Test
    void milestone2LengthMatchesBruteForce() {
        Random rng = new Random(2);
        for (int t = 0; t < 100; t++) {
            int n = 2 + rng.nextInt(6);
            Map<Integer, List<Integer>> g = randomGraph(rng, n, 0.4);
            List<Integer> route = Ex9Paths.shortestPath(g, 0, n - 1);
            List<List<Integer>> routes = allSimplePaths(g, 0, n - 1);
            if (routes.isEmpty()) {
                assertNull(route);
            } else {
                int best = routes.stream().mapToInt(List::size).min().getAsInt();
                assertEquals(best, route.size());
                for (int i = 0; i + 1 < route.size(); i++) {
                    assertTrue(g.get(route.get(i)).contains(route.get(i + 1)));
                }
            }
        }
    }

    @Test
    void milestone3CountsOnTheExampleGraph() {
        Map<String, Long> expected = Map.of("A", 1L, "B", 1L, "D", 1L, "C", 1L, "E", 2L, "F", 1L, "G", 3L);
        assertEquals(expected, Ex9Paths.countShortestPaths(example(), "A"));
    }

    @Test
    void milestone3TwoEqualRoutesAroundALoop() {
        Map<Integer, List<Integer>> g = new HashMap<>();
        g.put(0, List.of(1, 4));
        g.put(1, List.of(0, 2));
        g.put(2, List.of(1, 3));
        g.put(3, List.of(2, 7));
        g.put(4, List.of(0, 5));
        g.put(5, List.of(4, 6));
        g.put(6, List.of(5, 7));
        g.put(7, List.of(3, 6));
        assertEquals(2L, Ex9Paths.countShortestPaths(g, 0).get(7));
    }

    @Test
    void milestone3CountsMatchBruteForce() {
        Random rng = new Random(3);
        for (int t = 0; t < 100; t++) {
            int n = 2 + rng.nextInt(6);
            Map<Integer, List<Integer>> g = randomGraph(rng, n, 0.5);
            Map<Integer, Long> ways = Ex9Paths.countShortestPaths(g, 0);
            for (int target = 0; target < n; target++) {
                List<List<Integer>> routes = allSimplePaths(g, 0, target);
                if (routes.isEmpty()) {
                    assertTrue(!ways.containsKey(target));
                } else {
                    int best = routes.stream().mapToInt(List::size).min().getAsInt();
                    long count = routes.stream().filter(r -> r.size() == best).count();
                    assertEquals(count, ways.get(target));
                }
            }
        }
    }
}
