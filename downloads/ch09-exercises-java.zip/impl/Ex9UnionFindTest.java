import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.junit.jupiter.api.Test;

class Ex9UnionFindTest {
    static List<Integer> range(int n) {
        List<Integer> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            out.add(i);
        }
        return out;
    }

    @Test
    void milestone1UnionAndFind() {
        Ex9UnionFind<String> uf = new Ex9UnionFind<>(List.of("a", "b", "c", "d", "e"));
        assertEquals(5, uf.sets);
        assertFalse(uf.connected("a", "b"));
        assertTrue(uf.union("a", "b"));
        assertTrue(uf.connected("a", "b"));
        assertEquals(4, uf.sets);
        assertFalse(uf.union("b", "a"));
        assertEquals(4, uf.sets);
        uf.union("c", "d");
        uf.union("b", "d");
        assertTrue(uf.connected("a", "c"));
        assertFalse(uf.connected("a", "e"));
        assertEquals(2, uf.sets);
        assertEquals(uf.find("a"), uf.find("d"));
    }

    @Test
    void milestone1AgreesWithNaiveLabelling() {
        Random rng = new Random(1);
        for (int t = 0; t < 50; t++) {
            int n = 2 + rng.nextInt(28);
            Ex9UnionFind<Integer> uf = new Ex9UnionFind<>(range(n));
            int[] label = new int[n];
            for (int i = 0; i < n; i++) {
                label[i] = i;
            }
            for (int step = 0; step < 60; step++) {
                int a = rng.nextInt(n);
                int b = rng.nextInt(n);
                boolean changed = uf.union(a, b);
                assertEquals(label[a] != label[b], changed);
                if (label[a] != label[b]) {
                    int old = label[b];
                    for (int i = 0; i < n; i++) {
                        if (label[i] == old) {
                            label[i] = label[a];
                        }
                    }
                }
                assertEquals(java.util.Arrays.stream(label).distinct().count(), uf.sets);
            }
            for (int a = 0; a < n; a++) {
                for (int b = 0; b < n; b++) {
                    assertEquals(label[a] == label[b], uf.connected(a, b));
                }
            }
        }
    }

    @Test
    void milestone2TheSmallerTreeHangsUnderTheBiggerOne() {
        Ex9UnionFind<String> uf = new Ex9UnionFind<>(List.of("a", "b", "c", "d", "e", "f"));
        uf.union("a", "b");
        uf.union("c", "d");
        uf.union("a", "c"); // two trees of size 2: the first argument's root stays root
        String root = uf.find("a");
        assertEquals(4, uf.size.get(root));
        assertEquals("a", root);
        uf.union("e", "a"); // a single vertex joins a tree of 4: the big root stays
        assertEquals(root, uf.find("e"));
        assertEquals(5, uf.size.get(root));
        uf.union("f", "e");
        assertEquals(root, uf.find("f"));
        assertEquals(6, uf.size.get(root));
    }

    @Test
    void milestone2UnionBySizeKeepsTreesLogarithmicallyDeep() {
        int n = 1024;
        Ex9UnionFind<Integer> uf = new Ex9UnionFind<>(range(n));
        for (int step = 1; step < n; step *= 2) {
            for (int i = 0; i < n; i += 2 * step) {
                uf.union(i, i + step);
            }
        }
        int deepest = 0;
        for (int x = 0; x < n; x++) {
            deepest = Math.max(deepest, uf.depth(x));
        }
        assertEquals(10, deepest); // log2(1024)
        assertEquals(1, uf.sets);
    }

    @Test
    void milestone3PathCompressionFlattensAPath() {
        Ex9UnionFind<Integer> uf = new Ex9UnionFind<>(range(10));
        for (int i = 0; i < 9; i++) {
            uf.parent.put(i, i + 1); // a chain 0 -> 1 -> ... -> 9
        }
        assertEquals(9, uf.depth(0));
        assertEquals(9, uf.find(0));
        for (int x = 0; x < 10; x++) {
            assertTrue(uf.depth(x) <= 1); // every vertex of the path now points at the root
        }
        long steps = uf.findSteps;
        uf.find(0);
        assertEquals(1, uf.findSteps - steps); // a second find follows one link
    }

    @Test
    void milestone3FindDoesNotChangeTheAnswer() {
        Random rng = new Random(2);
        int n = 200;
        Ex9UnionFind<Integer> uf = new Ex9UnionFind<>(range(n));
        for (int t = 0; t < 300; t++) {
            uf.union(rng.nextInt(n), rng.nextInt(n));
        }
        int[] roots = new int[n];
        for (int x = 0; x < n; x++) {
            roots[x] = uf.find(x);
        }
        for (int x = 0; x < n; x++) {
            assertEquals(roots[x], uf.find(x));
        }
        assertEquals(java.util.Arrays.stream(roots).distinct().count(), uf.sets);
    }
}
