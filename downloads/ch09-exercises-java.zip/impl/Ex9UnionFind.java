import java.util.HashMap;
import java.util.Map;

/**
 * Exercise 8 (implementation): union-find with union by size and path compression.
 *
 * Milestone 1 -- find(x) returns the root of x's tree; union(a, b) merges the two sets and returns true, or returns false
 *     when a and b were already in the same set; connected(a, b); `sets` is the current number of sets.
 * Milestone 2 -- union by size: the root of the smaller tree becomes a child of the root of the bigger tree (on a tie the
 *     root of the FIRST argument's tree stays root); size.get(root) is the number of elements in that tree.
 * Milestone 3 -- path compression: after find(x) every vertex that was on the path from x to the root points straight
 *     at the root. findSteps counts how many parent links find() has followed in total (the tests use it).
 *
 * parent and size are plain maps: parent.get(x).equals(x) means x is a root. depth is given.
 */
public final class Ex9UnionFind<T> {
    public final Map<T, T> parent = new HashMap<>();
    public final Map<T, Integer> size = new HashMap<>();
    public int sets;
    public long findSteps = 0;

    public Ex9UnionFind(Iterable<T> items) {
        for (T x : items) {
            parent.put(x, x);
            size.put(x, 1);
        }
        sets = parent.size();
    }

    public T find(T x) {
        throw new UnsupportedOperationException("not implemented");
    }

    public boolean union(T a, T b) {
        throw new UnsupportedOperationException("not implemented");
    }

    public boolean connected(T a, T b) {
        throw new UnsupportedOperationException("not implemented");
    }

    /** How many links lie between x and its root (does not compress). */
    public int depth(T x) {
        int d = 0;
        while (!parent.get(x).equals(x)) {
            x = parent.get(x);
            d++;
        }
        return d;
    }
}
