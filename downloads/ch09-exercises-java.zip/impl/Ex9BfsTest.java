import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import org.junit.jupiter.api.Test;

class Ex9BfsTest {
    /** A map of adjacency lists that counts how often a vertex's list is fetched. */
    static class CountingGraph<V> extends HashMap<V, List<V>> {
        int lookups = 0;

        CountingGraph(Map<V, List<V>> from) {
            super(from);
        }

        @Override
        public List<V> get(Object key) {
            lookups++;
            return super.get(key);
        }
    }

    static Map<String, List<String>> example() {
        Map<String, List<String>> g = new HashMap<>();
        g.put("A", List.of("B", "D"));
        g.put("B", List.of("A", "C", "D", "E"));
        g.put("C", List.of("B", "E"));
        g.put("D", List.of("A", "B", "E", "F"));
        g.put("E", List.of("B", "C", "D", "F", "G"));
        g.put("F", List.of("D", "E", "G"));
        g.put("G", List.of("E", "F"));
        return g;
    }

    static Map<Integer, List<Integer>> randomGraph(Random rng, int n, double p) {
        Map<Integer, List<Integer>> g = new HashMap<>();
        for (int v = 0; v < n; v++) {
            g.put(v, new ArrayList<>());
        }
        for (int a = 0; a < n; a++) {
            for (int b = a + 1; b < n; b++) {
                if (rng.nextDouble() < p) {
                    g.get(a).add(b);
                    g.get(b).add(a);
                }
            }
        }
        return g;
    }

    /** Brute force (Floyd-Warshall) distances in edges from source, for the vertices reachable from it. */
    static Map<Integer, Integer> distances(Map<Integer, List<Integer>> g, int source) {
        int n = g.size();
        int inf = 1_000_000;
        int[][] d = new int[n][n];
        for (int a = 0; a < n; a++) {
            for (int b = 0; b < n; b++) {
                d[a][b] = a == b ? 0 : (g.get(a).contains(b) ? 1 : inf);
            }
        }
        for (int k = 0; k < n; k++) {
            for (int a = 0; a < n; a++) {
                for (int b = 0; b < n; b++) {
                    d[a][b] = Math.min(d[a][b], d[a][k] + d[k][b]);
                }
            }
        }
        Map<Integer, Integer> out = new HashMap<>();
        for (int b = 0; b < n; b++) {
            if (d[source][b] < inf) {
                out.put(b, d[source][b]);
            }
        }
        return out;
    }

    @Test
    void milestone1OrderOnTheExampleGraph() {
        assertEquals(List.of("A", "B", "D", "C", "E", "F", "G"), Ex9Bfs.bfs(example(), "A").order());
    }

    @Test
    void milestone1OnlyReachableVerticesAppear() {
        Map<String, List<String>> g = new HashMap<>();
        g.put("A", List.of("B"));
        g.put("B", List.of("A"));
        g.put("C", List.of("D"));
        g.put("D", List.of("C"));
        g.put("E", List.of());
        Ex9Bfs.Result<String> r = Ex9Bfs.bfs(g, "A");
        assertEquals(List.of("A", "B"), r.order());
        assertEquals(2, r.level().size());
        assertEquals(2, r.parent().size());
    }

    @Test
    void milestone2LevelsOnTheExampleGraph() {
        Map<String, Integer> expected = Map.of("A", 0, "B", 1, "D", 1, "C", 2, "E", 2, "F", 2, "G", 3);
        assertEquals(expected, Ex9Bfs.bfs(example(), "A").level());
    }

    @Test
    void milestone2LevelsAreTheFewestEdgesOnRandomGraphs() {
        Random rng = new Random(1);
        for (int t = 0; t < 100; t++) {
            int n = 1 + rng.nextInt(8);
            Map<Integer, List<Integer>> g = randomGraph(rng, n, rng.nextDouble());
            assertEquals(distances(g, 0), Ex9Bfs.bfs(g, 0).level());
        }
    }

    @Test
    void milestone2ATriangleNeedsOneEdgeToEveryVertex() {
        Map<Integer, List<Integer>> triangle = Map.of(0, List.of(1, 2), 1, List.of(0, 2), 2, List.of(0, 1));
        assertEquals(Map.of(0, 0, 1, 1, 2, 1), Ex9Bfs.bfs(triangle, 0).level());
    }

    @Test
    void milestone3Parents() {
        Map<String, List<String>> g = example();
        Ex9Bfs.Result<String> r = Ex9Bfs.bfs(g, "A");
        assertNull(r.parent().get("A"));
        assertEquals(Map.of("B", "A", "D", "A", "C", "B", "E", "B", "F", "D", "G", "E"),
            Map.copyOf(withoutNullEntries(r.parent())));
        for (Map.Entry<String, String> e : r.parent().entrySet()) {
            if (e.getValue() != null) {
                assertTrue(g.get(e.getValue()).contains(e.getKey()));
                assertEquals(r.level().get(e.getKey()) - 1, r.level().get(e.getValue()));
            }
        }
    }

    static <K, V> Map<K, V> withoutNullEntries(Map<K, V> m) {
        Map<K, V> out = new HashMap<>(m);
        out.values().removeIf(x -> x == null);
        return out;
    }

    @Test
    void milestone3EveryAdjacencyListIsReadExactlyOnce() {
        CountingGraph<String> g = new CountingGraph<>(example());
        Ex9Bfs.bfs(g, "A");
        assertEquals(7, g.lookups);
    }

    @Test
    void milestone3ACompleteGraphDoesNotBlowUpTheQueue() {
        int n = 40;
        Map<Integer, List<Integer>> plain = new HashMap<>();
        for (int v = 0; v < n; v++) {
            List<Integer> others = new ArrayList<>();
            for (int u = 0; u < n; u++) {
                if (u != v) {
                    others.add(u);
                }
            }
            plain.put(v, others);
        }
        CountingGraph<Integer> g = new CountingGraph<>(plain);
        Ex9Bfs.Result<Integer> r = Ex9Bfs.bfs(g, 0);
        assertEquals(n, r.order().size());
        assertEquals(n, g.lookups);
    }
}
