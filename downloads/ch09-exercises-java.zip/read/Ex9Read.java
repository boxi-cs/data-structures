import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.ArrayList;
import java.util.Set;

/**
 * Exercises 9 and 10 (read the code). Each piece below came from an AI assistant together with a claim.
 *
 * In both exercises the claim is wrong because of a bug. For each: find a small input that shows the bug (compare with a
 * brute-force answer), say what exactly goes wrong and why small examples do not show it, and fix it.
 *
 * Exercise 9:  bfsLevels9 -- "BFS from start; returns the visit order and the number of edges from start to every
 *              vertex. A vertex is marked visited when it is TAKEN from the queue, so it is processed once."
 * Exercise 10: Dijkstra10 -- "Dijkstra's algorithm with a binary heap and lazy deletion. Every edge is examined once, so
 *              the cost is O((V + E) log V); the distances are exact for non-negative weights."
 */
public final class Ex9Read {
    private Ex9Read() {}

    public record Bfs9(List<Integer> order, Map<Integer, Integer> level) {}

    public static Bfs9 bfsLevels9(Map<Integer, List<Integer>> graph, int start) {
        Map<Integer, Integer> level = new HashMap<>();
        List<Integer> order = new ArrayList<>();
        Set<Integer> visited = new HashSet<>();
        Deque<Integer> queue = new ArrayDeque<>();
        level.put(start, 0);
        queue.add(start);
        while (!queue.isEmpty()) {
            int u = queue.poll();
            if (visited.contains(u)) {
                continue;
            }
            visited.add(u);
            order.add(u);
            for (int v : graph.get(u)) {
                if (!visited.contains(v)) {
                    level.put(v, level.get(u) + 1);
                    queue.add(v);
                }
            }
        }
        return new Bfs9(order, level);
    }

    public record Edge(String to, int weight) {}

    public static final class Dijkstra10 {
        public long scans = 0;

        public Map<String, Long> run(Map<String, List<Edge>> graph, String source) {
            Map<String, Long> dist = new HashMap<>();
            for (String v : graph.keySet()) {
                dist.put(v, Long.MAX_VALUE / 4);
            }
            dist.put(source, 0L);
            PriorityQueue<Object[]> heap = new PriorityQueue<>((a, b) -> Long.compare((Long) a[0], (Long) b[0]));
            heap.add(new Object[] {0L, source});
            while (!heap.isEmpty()) {
                Object[] top = heap.poll();
                long d = (Long) top[0];
                String u = (String) top[1];
                for (Edge e : graph.get(u)) {
                    scans++;
                    if (d + e.weight() < dist.get(e.to())) {
                        dist.put(e.to(), d + e.weight());
                        heap.add(new Object[] {dist.get(e.to()), e.to()});
                    }
                }
            }
            return dist;
        }
    }
}
