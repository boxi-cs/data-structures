/**
 * Exercise 6 (implementation): an array-based stack that grows by doubling.
 *
 * The stack keeps its items in the array data (capacity = data.length, starting at 2) and the number of items in
 * size; the top item lives at index size - 1. push(x) first makes room if the array is full: it allocates an array of
 * twice the length and copies the old items over ONE AT A TIME, adding 1 to copies for every item copied. Then it stores x.
 *
 * Milestone 1: push, top and pop (LIFO order), while the array never fills up.
 * Milestone 2: pop and top on an empty stack throw NoSuchElementException; pop puts null back in the freed slot, so the
 *              stack does not keep an object alive that it no longer contains.
 * Milestone 3: growth by doubling with the copy counter; the tests check the capacities and the exact number of copies.
 */
public final class Ex3Stack<E> {
    private Object[] data = new Object[2];
    private int size = 0;
    private long copies = 0; // total number of item copies made by all resizes so far

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int capacity() {
        return data.length;
    }

    public long copies() {
        return copies;
    }

    Object slot(int i) { // lets the tests look at the array
        return data[i];
    }

    public void push(E x) {
        throw new UnsupportedOperationException("not implemented");
    }

    public E top() {
        throw new UnsupportedOperationException("not implemented");
    }

    public E pop() {
        throw new UnsupportedOperationException("not implemented");
    }
}
