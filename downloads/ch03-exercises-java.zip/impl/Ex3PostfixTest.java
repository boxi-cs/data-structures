import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

class Ex3PostfixTest {
    static int ev(String expr) {
        return Ex3Postfix.evaluate(expr.isEmpty() ? new String[0] : expr.split(" "));
    }

    @Test
    void m1NumbersAndPlusTimes() {
        assertEquals(14, ev("3 4 + 2 *"));
        assertEquals(42, ev("42"));
        assertEquals(14, ev("2 3 4 * +"));
    }

    @Test
    void m1MinusOperandOrder() {
        assertEquals(7, ev("10 3 -"));
        assertEquals(-7, ev("3 10 -"));
        assertEquals(14, ev("5 1 2 + 4 * + 3 -"));
    }

    @Test
    void m1NegativeLiterals() {
        assertEquals(1, ev("-3 4 +"));
        assertEquals(12, ev("-3 -4 *"));
    }

    @Test
    void m2DivisionTruncatesTowardZero() {
        assertEquals(3, ev("7 2 /"));
        assertEquals(-3, ev("-7 2 /"));
        assertEquals(-3, ev("7 -2 /"));
        assertEquals(3, ev("-7 -2 /"));
        assertEquals(0, ev("1 2 /"));
        assertEquals(0, ev("-1 2 /"));
    }

    @Test
    void m2DivisionOperandOrder() {
        assertEquals(20, ev("100 5 /"));
        assertEquals(0, ev("5 100 /"));
    }

    @Test
    void m3MalformedInputThrowsIllegalArgument() {
        for (String bad : new String[] {"", "+", "1 +", "1 2", "1 2 3 +", "1 x +", "1 2 ^"}) {
            assertThrows(IllegalArgumentException.class, () -> ev(bad), bad);
        }
    }

    @Test
    void m3DivisionByZero() {
        assertThrows(ArithmeticException.class, () -> ev("1 0 /"));
        assertThrows(ArithmeticException.class, () -> ev("5 2 2 - /"));
    }

    @Test
    void m3LongExpression() {
        // 1 + 2 + ... + 100 written in postfix
        StringBuilder sb = new StringBuilder("1");
        for (int k = 2; k <= 100; k++) {
            sb.append(' ').append(k).append(" +");
        }
        assertEquals(5050, ev(sb.toString()));
    }
}
