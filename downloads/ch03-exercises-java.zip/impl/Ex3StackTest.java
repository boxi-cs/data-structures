import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Random;
import org.junit.jupiter.api.Test;

class Ex3StackTest {
    @Test
    void m1LifoOrder() {
        Ex3Stack<Integer> s = new Ex3Stack<>();
        for (int x : new int[] {3, 7, 1}) {
            s.push(x);
        }
        assertEquals(3, s.size());
        assertEquals(1, s.top());
        assertEquals(1, s.pop());
        assertEquals(7, s.pop());
        assertEquals(3, s.pop());
        assertTrue(s.isEmpty());
    }

    @Test
    void m1TopDoesNotRemove() {
        Ex3Stack<Integer> s = new Ex3Stack<>();
        s.push(5);
        assertEquals(5, s.top());
        assertEquals(5, s.top());
        assertEquals(1, s.size());
    }

    @Test
    void m2EmptyStackThrows() {
        Ex3Stack<Integer> s = new Ex3Stack<>();
        assertThrows(NoSuchElementException.class, s::pop);
        assertThrows(NoSuchElementException.class, s::top);
        s.push(1);
        s.pop();
        assertThrows(NoSuchElementException.class, s::pop);
    }

    @Test
    void m2PopClearsTheSlot() {
        Ex3Stack<String> s = new Ex3Stack<>();
        s.push("a");
        s.push("b");
        assertEquals("b", s.pop());
        assertNull(s.slot(1));
        assertEquals("a", s.slot(0));
    }

    @Test
    void m3CapacitySequence() {
        Ex3Stack<Integer> s = new Ex3Stack<>();
        int[] caps = new int[9];
        for (int i = 0; i < 9; i++) {
            s.push(i);
            caps[i] = s.capacity();
        }
        assertArrayEquals(new int[] {2, 2, 4, 4, 8, 8, 8, 8, 16}, caps);
    }

    @Test
    void m3ExactCopies() {
        // the resizes copy 2, 4, 8, ... items; if the final capacity is C the total is C - 2
        Ex3Stack<Integer> s = new Ex3Stack<>();
        for (int n = 1; n < 300; n++) {
            s.push(n);
            assertEquals(s.capacity() - 2, s.copies());
        }
    }

    @Test
    void m3CopiesBelow2n() {
        for (int n : new int[] {1, 2, 3, 10, 100, 1000, 12345}) {
            Ex3Stack<Integer> s = new Ex3Stack<>();
            for (int i = 0; i < n; i++) {
                s.push(i);
            }
            assertTrue(s.copies() < 2L * n, "n = " + n);
        }
    }

    @Test
    void m3ValuesSurviveGrowth() {
        Ex3Stack<Integer> s = new Ex3Stack<>();
        for (int i = 0; i < 1000; i++) {
            s.push(i);
        }
        for (int i = 999; i >= 0; i--) {
            assertEquals(i, s.pop());
        }
    }

    @Test
    void m3RandomOperationsMatchAList() {
        Random rng = new Random(3);
        Ex3Stack<Integer> s = new Ex3Stack<>();
        ArrayList<Integer> ref = new ArrayList<>();
        for (int step = 0; step < 5000; step++) {
            if (!ref.isEmpty() && rng.nextDouble() < 0.45) {
                assertEquals(ref.remove(ref.size() - 1), s.pop());
            } else {
                int x = rng.nextInt(100);
                s.push(x);
                ref.add(x);
            }
            assertEquals(ref.size(), s.size());
            if (!ref.isEmpty()) {
                assertEquals(ref.get(ref.size() - 1), s.top());
            }
        }
    }
}
