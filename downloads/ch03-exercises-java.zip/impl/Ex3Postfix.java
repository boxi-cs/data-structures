/**
 * Exercise 8 (implementation): evaluate a postfix (reverse Polish) expression with a stack.
 *
 * evaluate(tokens) takes tokens such as {"5", "1", "2", "+", "4", "*", "+", "3", "-"} (that is 5 + (1 + 2) * 4 - 3) and
 * returns the value. Read the tokens left to right: a number is pushed; an operator pops the right operand first and then
 * the left operand, and pushes the result. Use java.util.ArrayDeque as the stack (not the legacy java.util.Stack).
 *
 * Milestone 1: integers (possibly negative, like "-3") and the operators + - *. Mind the operand order for "-".
 * Milestone 2: "/" divides and truncates toward zero (Java's int division does that; -7 / 2 is -3).
 * Milestone 3: malformed input. An operator with fewer than two operands on the stack, more than one value left at the
 *              end, an empty array, or a token that is neither an integer nor an operator throws IllegalArgumentException.
 *              Division by zero throws ArithmeticException.
 */
public final class Ex3Postfix {
    private Ex3Postfix() {}

    public static int evaluate(String[] tokens) {
        throw new UnsupportedOperationException("not implemented");
    }
}
