import java.util.Arrays;

/**
 * Exercise 7 (implementation): a queue in a circular array.
 *
 * The queue keeps its items in the array data, the index of the first item in front and the number of items in size.
 * The items occupy the cells (front + k) mod capacity for k = 0 .. size - 1.
 *
 * Milestone 1: enqueue, dequeue and first (FIFO order) while the array never fills up; dequeue and first throw
 *              NoSuchElementException on an empty queue; dequeue puts null back in the freed cell.
 * Milestone 2: wrap-around. The next free cell is (front + size) mod capacity, and dequeue moves front to
 *              (front + 1) mod capacity. No item is ever moved.
 * Milestone 3: when the array is full, enqueue first allocates an array of twice the length and copies the items over IN
 *              QUEUE ORDER starting at cell 0 (so the front becomes 0), then stores the new item.
 *
 * describe() is given: the tests compare it with the picture from the video.
 */
public final class Ex3CircQueue<E> {
    private Object[] data;
    private int front = 0;
    private int size = 0;

    public Ex3CircQueue() {
        this(4);
    }

    public Ex3CircQueue(int capacity) {
        data = new Object[capacity];
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    int capacity() {
        return data.length;
    }

    int front() {
        return front;
    }

    public E first() {
        throw new UnsupportedOperationException("not implemented");
    }

    public E dequeue() {
        throw new UnsupportedOperationException("not implemented");
    }

    public void enqueue(E x) {
        throw new UnsupportedOperationException("not implemented");
    }

    public String describe() {
        return "data=" + Arrays.toString(data) + " front=" + front + " size=" + size;
    }
}
