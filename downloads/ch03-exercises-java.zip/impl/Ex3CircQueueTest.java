import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayDeque;
import java.util.NoSuchElementException;
import java.util.Random;
import org.junit.jupiter.api.Test;

class Ex3CircQueueTest {
    @Test
    void m1FifoOrder() {
        Ex3CircQueue<String> q = new Ex3CircQueue<>();
        for (String x : new String[] {"A", "B", "C"}) {
            q.enqueue(x);
        }
        assertEquals(3, q.size());
        assertEquals("A", q.first());
        assertEquals("A", q.dequeue());
        assertEquals("B", q.dequeue());
        assertEquals("C", q.dequeue());
        assertTrue(q.isEmpty());
    }

    @Test
    void m1EmptyQueueThrows() {
        Ex3CircQueue<Integer> q = new Ex3CircQueue<>();
        assertThrows(NoSuchElementException.class, q::dequeue);
        assertThrows(NoSuchElementException.class, q::first);
        q.enqueue(1);
        q.dequeue();
        assertThrows(NoSuchElementException.class, q::dequeue);
    }

    @Test
    void m1DequeueClearsTheCell() {
        Ex3CircQueue<String> q = new Ex3CircQueue<>();
        q.enqueue("A");
        q.enqueue("B");
        assertEquals("A", q.dequeue());
        assertEquals("data=[null, B, null, null] front=1 size=1", q.describe());
    }

    @Test
    void m2WrapAroundAsInTheVideo() {
        Ex3CircQueue<String> q = new Ex3CircQueue<>();
        for (String x : new String[] {"A", "B", "C", "D"}) {
            q.enqueue(x);
        }
        assertEquals("data=[A, B, C, D] front=0 size=4", q.describe());
        assertEquals("A", q.dequeue());
        assertEquals("B", q.dequeue());
        assertEquals("data=[null, null, C, D] front=2 size=2", q.describe());
        q.enqueue("E");
        q.enqueue("F");
        assertEquals("data=[E, F, C, D] front=2 size=4", q.describe());
    }

    @Test
    void m2FrontWrapsAfterAFullLap() {
        Ex3CircQueue<Integer> q = new Ex3CircQueue<>(3);
        for (int lap = 0; lap < 10; lap++) {
            q.enqueue(lap);
            assertEquals(lap, q.dequeue());
        }
        assertEquals(10 % 3, q.front());
        assertEquals(3, q.capacity());
    }

    @Test
    void m3ResizeStraightensTheCircle() {
        Ex3CircQueue<String> q = new Ex3CircQueue<>();
        for (String x : new String[] {"A", "B", "C", "D"}) {
            q.enqueue(x);
        }
        q.dequeue();
        q.dequeue();
        q.enqueue("E");
        q.enqueue("F");
        q.enqueue("G");
        assertEquals("data=[C, D, E, F, G, null, null, null] front=0 size=5", q.describe());
        for (String x : new String[] {"C", "D", "E", "F", "G"}) {
            assertEquals(x, q.dequeue());
        }
    }

    @Test
    void m3CapacityOnlyChangesWhenFull() {
        Ex3CircQueue<Integer> q = new Ex3CircQueue<>(4);
        for (int i = 0; i < 1000; i++) {
            q.enqueue(i);
            q.enqueue(i);
            q.dequeue();
            q.dequeue();
            assertEquals(4, q.capacity());
        }
    }

    @Test
    void m3RandomOperationsMatchArrayDeque() {
        for (int capacity : new int[] {1, 2, 4, 5}) {
            Random rng = new Random(capacity);
            Ex3CircQueue<Integer> q = new Ex3CircQueue<>(capacity);
            ArrayDeque<Integer> ref = new ArrayDeque<>();
            for (int step = 0; step < 20000; step++) {
                if (!ref.isEmpty() && rng.nextDouble() < 0.48) {
                    assertEquals(ref.pollFirst(), q.dequeue());
                } else {
                    q.enqueue(step);
                    ref.addLast(step);
                }
                assertEquals(ref.size(), q.size());
                if (!ref.isEmpty()) {
                    assertEquals(ref.peekFirst(), q.first());
                }
            }
        }
    }
}
