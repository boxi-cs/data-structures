import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Exercises 9 and 10 (read the code). Each piece of code below was written by an AI assistant together with a claim
 * about how well it was tested. The claims sound reasonable. The code is NOT correct: find an input on which it fails,
 * say which line is wrong and what happens, fix it, and say what test would have caught it.
 */
public final class Ex3Read {
    private Ex3Read() {}

    /**
     * A FIFO queue of ints with fixed capacity, stored in a circular array.
     *
     * Tested: enqueue three items into a RingQueue(3), dequeue them in order (they came out as 1, 2, 3), enqueue again.
     * All of it works, and every operation takes constant time.
     */
    public static final class RingQueue {
        private final int[] data;
        private int front = 0;
        private int size = 0;

        public RingQueue(int capacity) {
            data = new int[capacity];
        }

        public int size() {
            return size;
        }

        public void enqueue(int x) {
            if (size == data.length) {
                throw new IllegalStateException("queue is full");
            }
            data[(front + size) % data.length] = x;
            size++;
        }

        public int dequeue() {
            if (size == 0) {
                throw new java.util.NoSuchElementException("queue is empty");
            }
            int x = data[front];
            front++;
            size--;
            return x;
        }
    }

    /**
     * Returns true if the brackets ( ) [ ] { } in expr are properly nested, ignoring all other characters.
     *
     * Tested on "([]{})", "(a[b]c)" and "[(])": true, true, false, as expected.
     */
    public static boolean isMatched(String expr) {
        Deque<Character> stack = new ArrayDeque<>();
        for (char ch : expr.toCharArray()) {
            if ("([{".indexOf(ch) >= 0) {
                stack.push(ch);
            } else if (")]}".indexOf(ch) >= 0) {
                char top = stack.pop();
                if ("([{".indexOf(top) != ")]}".indexOf(ch)) {
                    return false;
                }
            }
        }
        return true;
    }
}
