"""Exercises 9 and 10 (read the code).  Each function below came from an AI assistant together with a claim.

In both exercises the claim is wrong because of a bug.  For each: find a small input that shows the bug
(compare with a brute-force answer), say what exactly goes wrong and why small examples do not show it, and fix it.

Exercise 9:  bfs_levels_9 -- "BFS from start; returns the visit order and the number of edges from start to every
             vertex.  A vertex is marked visited when it is TAKEN from the queue, so it is processed once."
Exercise 10: Dijkstra10   -- "Dijkstra's algorithm with a binary heap and lazy deletion.  Every edge is examined
             once, so the cost is O((V + E) log V); the distances are exact for non-negative weights."
"""
import heapq
from collections import deque

INF = float("inf")


def bfs_levels_9(graph, start):
    """graph: dict vertex -> list of neighbours.  Returns (order, level)."""
    level = {start: 0}
    order = []
    visited = set()
    queue = deque([start])
    while queue:
        u = queue.popleft()
        if u in visited:
            continue
        visited.add(u)
        order.append(u)
        for v in graph[u]:
            if v not in visited:
                level[v] = level[u] + 1
                queue.append(v)
    return order, level


class Dijkstra10:
    """graph: dict vertex -> list of (neighbour, weight), weights >= 0.  scans counts the adjacency entries looked at."""

    def __init__(self):
        self.scans = 0

    def run(self, graph, source):
        dist = {v: INF for v in graph}
        dist[source] = 0
        heap = [(0, source)]
        while heap:
            d, u = heapq.heappop(heap)
            for v, w in graph[u]:
                self.scans += 1
                if d + w < dist[v]:
                    dist[v] = d + w
                    heapq.heappush(heap, (dist[v], v))
        return dist
