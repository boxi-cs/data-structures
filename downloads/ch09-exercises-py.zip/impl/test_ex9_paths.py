import itertools
import random

from ex9_paths import count_shortest_paths, path_from_parents, shortest_path

EXAMPLE = {
    "A": ["B", "D"], "B": ["A", "C", "D", "E"], "C": ["B", "E"], "D": ["A", "B", "E", "F"],
    "E": ["B", "C", "D", "F", "G"], "F": ["D", "E", "G"], "G": ["E", "F"],
}


def random_graph(rng, n, p):
    g = {v: [] for v in range(n)}
    for a, b in itertools.combinations(range(n), 2):
        if rng.random() < p:
            g[a].append(b)
            g[b].append(a)
    return g


def all_simple_paths(g, s, t):
    def walk(path):
        u = path[-1]
        if u == t:
            yield list(path)
            return
        for v in g[u]:
            if v not in path:
                path.append(v)
                yield from walk(path)
                path.pop()

    yield from walk([s])


def test_milestone_1_follow_the_parents_back():
    parent = {"A": None, "B": "A", "D": "A", "C": "B", "E": "B"}
    assert path_from_parents(parent, "C") == ["A", "B", "C"]
    assert path_from_parents(parent, "A") == ["A"]
    assert path_from_parents(parent, "Z") is None


def test_milestone_1_the_input_is_not_changed():
    parent = {"A": None, "B": "A", "C": "B"}
    path_from_parents(parent, "C")
    assert parent == {"A": None, "B": "A", "C": "B"}


def test_milestone_2_example_graph():
    route = shortest_path(EXAMPLE, "A", "G")
    assert route[0] == "A" and route[-1] == "G" and len(route) == 4  # three edges: A B E G or A D E G or A D F G
    for a, b in zip(route, route[1:]):
        assert b in EXAMPLE[a]
    assert shortest_path(EXAMPLE, "A", "A") == ["A"]


def test_milestone_2_unreachable_gives_none():
    g = {"A": ["B"], "B": ["A"], "C": []}
    assert shortest_path(g, "A", "C") is None


def test_milestone_2_length_matches_brute_force():
    rng = random.Random(2)
    for _ in range(100):
        n = rng.randrange(2, 8)
        g = random_graph(rng, n, 0.4)
        route = shortest_path(g, 0, n - 1)
        routes = list(all_simple_paths(g, 0, n - 1))
        if not routes:
            assert route is None
        else:
            assert len(route) == min(len(r) for r in routes)
            assert all(b in g[a] for a, b in zip(route, route[1:]))


def test_milestone_3_counts_on_the_example_graph():
    assert count_shortest_paths(EXAMPLE, "A") == {"A": 1, "B": 1, "D": 1, "C": 1, "E": 2, "F": 1, "G": 3}


def test_milestone_3_a_ladder_doubles_every_step():
    # 0-1-2-3 and 0-4-5-6 joined at the end: two routes of equal length to the last vertex
    g = {0: [1, 4], 1: [0, 2], 2: [1, 3], 3: [2, 7], 4: [0, 5], 5: [4, 6], 6: [5, 7], 7: [3, 6]}
    assert count_shortest_paths(g, 0)[7] == 2


def test_milestone_3_counts_match_brute_force():
    rng = random.Random(3)
    for _ in range(100):
        n = rng.randrange(2, 8)
        g = random_graph(rng, n, 0.5)
        ways = count_shortest_paths(g, 0)
        for t in range(n):
            routes = list(all_simple_paths(g, 0, t))
            if not routes:
                assert t not in ways
            else:
                best = min(len(r) for r in routes)
                assert ways[t] == sum(1 for r in routes if len(r) == best)
