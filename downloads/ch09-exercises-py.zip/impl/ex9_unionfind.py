"""Exercise 8 (implementation): union-find with union by size and path compression.

Milestone 1 -- UnionFind(items): find(x) returns the root of x's tree, union(a, b) merges the two sets and returns
    True, or returns False when a and b were already in the same set; connected(a, b); `sets` is the current number of sets.
Milestone 2 -- union by size: the root of the smaller tree becomes a child of the root of the bigger tree (on a tie the
    root of the FIRST argument's tree stays root); size[root] is the number of elements in that tree.
Milestone 3 -- path compression: after find(x) every vertex that was on the path from x to the root points straight at
    the root.  find_steps counts how many parent links find() has followed in total (the tests use it).

parent and size are plain dicts: `parent[x] == x` means x is a root.  `depth` is given.

Run:  pytest test_ex9_unionfind.py
"""


class UnionFind:
    def __init__(self, items):
        self.parent = {x: x for x in items}
        self.size = {x: 1 for x in items}
        self.sets = len(self.parent)
        self.find_steps = 0

    def find(self, x):
        raise NotImplementedError

    def union(self, a, b):
        raise NotImplementedError

    def connected(self, a, b):
        raise NotImplementedError

    def depth(self, x):
        """How many links lie between x and its root (does not compress)."""
        d = 0
        while self.parent[x] != x:
            x = self.parent[x]
            d += 1
        return d
