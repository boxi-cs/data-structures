"""Exercise 6 (implementation): breadth-first search with levels and parents.

graph: a dict that maps every vertex to the list of its neighbours (an undirected edge appears in both lists).
Visit the neighbours in the order of the list.

Three milestones, in order; run the tests after each one.
Milestone 1 -- bfs(graph, start) returns (order, level, parent) and order is the list of vertices in the order a
    queue-based search takes them out of the queue.  Only vertices reachable from start appear.
Milestone 2 -- level[v] is the number of edges on a route from start to v with the fewest edges (level[start] == 0).
Milestone 3 -- parent[v] is the vertex from which v was discovered (parent[start] is None); following parents from any
    v leads back to start along a route with level[v] edges.  And the cost must be right: the adjacency list of every
    reachable vertex is looked at exactly ONCE (the tests count the lookups), so a vertex must be marked the moment
    it is put into the queue, not when it is taken out.

Run:  pytest test_ex9_bfs.py
"""


def bfs(graph, start):
    raise NotImplementedError
