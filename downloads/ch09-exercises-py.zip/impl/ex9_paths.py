"""Exercise 7 (implementation): routes from BFS parents.

graph: dict vertex -> list of neighbours.  You may call your bfs from ex9_bfs.py (or write the search again).

Milestone 1 -- path_from_parents(parent, target): the route start -> target, found by following parents back from
    target and reversing.  [start] if target is the start, None if target is not in parent (unreachable).
Milestone 2 -- shortest_path(graph, source, target): a route with the fewest edges, or None when there is none.
Milestone 3 -- count_shortest_paths(graph, source): a dict from every reachable vertex to the NUMBER of different
    routes with the fewest edges from source (source itself: 1).  Hint: a vertex u at level d adds ways[u] to every
    neighbour v at level d + 1, and to nobody else.

Run:  pytest test_ex9_paths.py
"""


def path_from_parents(parent, target):
    raise NotImplementedError


def shortest_path(graph, source, target):
    raise NotImplementedError


def count_shortest_paths(graph, source):
    raise NotImplementedError
