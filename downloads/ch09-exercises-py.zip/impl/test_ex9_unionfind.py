import random

from ex9_unionfind import UnionFind


def test_milestone_1_union_and_find():
    uf = UnionFind("abcde")
    assert uf.sets == 5 and not uf.connected("a", "b")
    assert uf.union("a", "b") is True and uf.connected("a", "b") and uf.sets == 4
    assert uf.union("b", "a") is False and uf.sets == 4
    uf.union("c", "d")
    uf.union("b", "d")
    assert uf.connected("a", "c") and not uf.connected("a", "e") and uf.sets == 2
    assert uf.find("a") == uf.find("d")


def test_milestone_1_agrees_with_naive_labelling():
    rng = random.Random(1)
    for _ in range(50):
        n = rng.randrange(2, 30)
        uf = UnionFind(range(n))
        label = list(range(n))
        for _ in range(60):
            a, b = rng.randrange(n), rng.randrange(n)
            changed = uf.union(a, b)
            assert changed == (label[a] != label[b])
            if label[a] != label[b]:
                old = label[b]
                label = [label[a] if x == old else x for x in label]
            assert len(set(label)) == uf.sets
        for a in range(n):
            for b in range(n):
                assert uf.connected(a, b) == (label[a] == label[b])


def test_milestone_2_the_smaller_tree_hangs_under_the_bigger_one():
    uf = UnionFind("abcdef")
    uf.union("a", "b")
    uf.union("c", "d")
    uf.union("a", "c")  # two trees of size 2: the first argument's root stays root
    root = uf.find("a")
    assert uf.size[root] == 4 and root == "a"
    uf.union("e", "a")  # a single vertex joins a tree of 4: the big root stays
    assert uf.find("e") == root and uf.size[root] == 5
    uf.union("f", "e")
    assert uf.find("f") == root and uf.size[root] == 6


def test_milestone_2_union_by_size_keeps_trees_logarithmically_deep():
    n = 1024
    uf = UnionFind(range(n))
    step = 1
    while step < n:
        for i in range(0, n, 2 * step):
            uf.union(i, i + step)
        step *= 2
    assert max(uf.depth(x) for x in range(n)) == 10  # log2(1024)
    assert uf.sets == 1


def test_milestone_3_path_compression_flattens_a_path():
    uf = UnionFind(range(10))
    for i in range(9):
        uf.parent[i] = i + 1  # a chain 0 -> 1 -> ... -> 9
    assert uf.depth(0) == 9
    assert uf.find(0) == 9
    assert max(uf.depth(x) for x in range(10)) == 1  # every vertex of the path now points at the root
    steps = uf.find_steps
    uf.find(0)
    assert uf.find_steps - steps == 1  # a second find follows one link


def test_milestone_3_find_does_not_change_the_answer():
    rng = random.Random(2)
    n = 200
    uf = UnionFind(range(n))
    for _ in range(300):
        uf.union(rng.randrange(n), rng.randrange(n))
    roots = {x: uf.find(x) for x in range(n)}
    assert {x: uf.find(x) for x in range(n)} == roots
    assert uf.sets == len(set(roots.values()))
