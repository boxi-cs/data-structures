import itertools
import random

from ex9_bfs import bfs

EXAMPLE = {
    "A": ["B", "D"], "B": ["A", "C", "D", "E"], "C": ["B", "E"], "D": ["A", "B", "E", "F"],
    "E": ["B", "C", "D", "F", "G"], "F": ["D", "E", "G"], "G": ["E", "F"],
}


class CountingGraph(dict):
    """A dict of adjacency lists that counts how often a vertex's list is fetched."""

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.lookups = 0

    def __getitem__(self, key):
        self.lookups += 1
        return super().__getitem__(key)


def distances(g, source):
    """Brute force (Floyd-Warshall) distances in edges, for the vertices reachable from source."""
    inf = float("inf")
    d = {(a, b): (0 if a == b else (1 if b in g[a] else inf)) for a in g for b in g}
    for k in g:
        for a in g:
            for b in g:
                d[a, b] = min(d[a, b], d[a, k] + d[k, b])
    return {b: d[source, b] for b in g if d[source, b] < inf}


def random_graph(rng, n, p):
    g = {v: [] for v in range(n)}
    for a, b in itertools.combinations(range(n), 2):
        if rng.random() < p:
            g[a].append(b)
            g[b].append(a)
    return g


def test_milestone_1_order_on_the_example_graph():
    order, _, _ = bfs(EXAMPLE, "A")
    assert order == list("ABDCEFG")


def test_milestone_1_only_reachable_vertices_appear():
    g = {"A": ["B"], "B": ["A"], "C": ["D"], "D": ["C"], "E": []}
    order, level, parent = bfs(g, "A")
    assert order == ["A", "B"] and set(level) == {"A", "B"} and set(parent) == {"A", "B"}


def test_milestone_2_levels_on_the_example_graph():
    _, level, _ = bfs(EXAMPLE, "A")
    assert level == {"A": 0, "B": 1, "D": 1, "C": 2, "E": 2, "F": 2, "G": 3}


def test_milestone_2_levels_are_the_fewest_edges_on_random_graphs():
    rng = random.Random(1)
    for _ in range(100):
        g = random_graph(rng, rng.randrange(1, 9), rng.random())
        _, level, _ = bfs(g, 0)
        assert level == distances(g, 0)


def test_milestone_2_a_triangle_needs_one_edge_to_every_vertex():
    triangle = {0: [1, 2], 1: [0, 2], 2: [0, 1]}
    assert bfs(triangle, 0)[1] == {0: 0, 1: 1, 2: 1}


def test_milestone_3_parents():
    _, level, parent = bfs(EXAMPLE, "A")
    assert parent == {"A": None, "B": "A", "D": "A", "C": "B", "E": "B", "F": "D", "G": "E"}
    for v, p in parent.items():
        if p is not None:
            assert v in EXAMPLE[p] and level[p] == level[v] - 1


def test_milestone_3_every_adjacency_list_is_read_exactly_once():
    g = CountingGraph(EXAMPLE)
    bfs(g, "A")
    assert g.lookups == 7


def test_milestone_3_a_complete_graph_does_not_blow_up_the_queue():
    n = 40
    g = CountingGraph({v: [u for u in range(n) if u != v] for v in range(n)})
    order, level, _ = bfs(g, 0)
    assert len(order) == n and set(level.values()) == {0, 1}
    assert g.lookups == n
