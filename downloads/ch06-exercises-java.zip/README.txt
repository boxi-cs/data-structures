Chapter 6 exercises (Java 21)

Templates for the implementation exercises are in impl/, the read-the-code snippets in read/.
Every test in impl/ fails until you finish the milestones.

    curl -LO https://repo1.maven.org/maven2/org/junit/platform/junit-platform-console-standalone/1.14.4/junit-platform-console-standalone-1.14.4.jar
    cd impl
    javac -cp ../junit-platform-console-standalone-1.14.4.jar -d /tmp/ex *.java
    java -jar ../junit-platform-console-standalone-1.14.4.jar execute --class-path /tmp/ex --scan-class-path
