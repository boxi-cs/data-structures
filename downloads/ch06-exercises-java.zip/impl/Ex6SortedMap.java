import java.util.List;

/**
 * Exercise 8 (implementation): the order queries of a sorted map, on a plain binary search tree.
 *
 * Node and insert are given. Write the five queries; the node queries return the Node, or null when there is no such
 * entry. Three milestones, in order; run the tests after each one.
 *
 * Milestone 1 -- first(root) and last(root): the node with the smallest / the largest key.
 * Milestone 2 -- floor(root, key) and ceiling(root, key): the node with the GREATEST key <= key, and the node with
 *     the SMALLEST key >= key. A loop from the root that goes down ONE path is enough: whenever the current key is a
 *     candidate, remember it and keep looking for a closer one on the correct side. O(height), no recursion needed.
 * Milestone 3 -- subMap(root, lo, hi): the list of the nodes with lo <= key < hi (half-open, as java.util.TreeMap.subMap
 *     does) in increasing key order. Do NOT visit the whole tree: skip a left subtree when every key in it is smaller
 *     than lo, and a right subtree when every key in it is >= hi. Add 1 to the static counter `visited` once for every
 *     node you look at; the test checks that you visit at most 2 * height + k nodes for a range with k results.
 */
public final class Ex6SortedMap {
    private Ex6SortedMap() {}

    public static long visited; // nodes examined by subMap

    public static final class Node {
        public final int key;
        public String value;
        public Node left;
        public Node right;

        public Node(int key, String value) {
            this.key = key;
            this.value = value;
        }
    }

    /** Given: the plain BST insertion; a key that is already there gets the new value. */
    public static Node insert(Node root, int key, String value) {
        if (root == null) {
            return new Node(key, value);
        }
        Node cur = root;
        while (true) {
            if (key == cur.key) {
                cur.value = value;
                return root;
            }
            if (key < cur.key) {
                if (cur.left == null) {
                    cur.left = new Node(key, value);
                    return root;
                }
                cur = cur.left;
            } else {
                if (cur.right == null) {
                    cur.right = new Node(key, value);
                    return root;
                }
                cur = cur.right;
            }
        }
    }

    public static Node first(Node root) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static Node last(Node root) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static Node floor(Node root, int key) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static Node ceiling(Node root, int key) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static List<Node> subMap(Node root, int lo, int hi) {
        throw new UnsupportedOperationException("not implemented");
    }
}
