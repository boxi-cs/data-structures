import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.junit.jupiter.api.Test;

class Ex6RotateTest {
    static Ex6Rotate.Node t(int key, Ex6Rotate.Node left, Ex6Rotate.Node right) {
        return new Ex6Rotate.Node(key, left, right);
    }

    static Ex6Rotate.Node t(int key) {
        return new Ex6Rotate.Node(key);
    }

    static String shape(Ex6Rotate.Node n) {
        if (n == null) {
            return "-";
        }
        if (n.left == null && n.right == null) {
            return Integer.toString(n.key);
        }
        return n.key + "(" + shape(n.left) + "," + shape(n.right) + ")";
    }

    static void inorder(Ex6Rotate.Node n, List<Integer> out) {
        if (n != null) {
            inorder(n.left, out);
            out.add(n.key);
            inorder(n.right, out);
        }
    }

    static int height(Ex6Rotate.Node n) {
        return n == null ? 0 : 1 + Math.max(height(n.left), height(n.right));
    }

    static void checkLinks(Ex6Rotate.Node n, Ex6Rotate.Node parent) {
        if (n == null) {
            return;
        }
        assertSame(parent, n.parent, "wrong parent link at " + n.key);
        checkLinks(n.left, n);
        checkLinks(n.right, n);
    }

    @Test
    void rightRotationOfTheRoot() {
        Ex6Rotate.Node root = t(30, t(20, t(10), t(25)), t(40));
        Ex6Rotate.Node y = Ex6Rotate.rotateRight(root);
        assertEquals(20, y.key);
        assertEquals("20(10,30(25,40))", shape(y));
        assertNull(y.parent);
        checkLinks(y, null);
    }

    @Test
    void leftRotationOfTheRoot() {
        Ex6Rotate.Node root = t(10, t(5), t(20, t(15), t(30)));
        Ex6Rotate.Node y = Ex6Rotate.rotateLeft(root);
        assertEquals("20(10(5,15),30)", shape(y));
        checkLinks(y, null);
    }

    @Test
    void theMiddleSubtreeChangesSides() {
        Ex6Rotate.Node root = t(30, t(20, null, t(25)), null);
        Ex6Rotate.Node y = Ex6Rotate.rotateRight(root);
        assertEquals("20(-,30(25,-))", shape(y));
        assertEquals(25, y.right.left.key);
        checkLinks(y, null);
    }

    @Test
    void rotationInsideATreeKeepsTheParentLinkOnTheSameSide() {
        Ex6Rotate.Node p = t(50, t(30, t(20, t(10), null), t(40)), t(60)); // x hangs on the LEFT of p
        Ex6Rotate.Node y = Ex6Rotate.rotateRight(p.left);
        assertSame(y, p.left);
        assertEquals(20, y.key);
        assertEquals("50(20(10,30(-,40)),60)", shape(p));
        checkLinks(p, null);
        Ex6Rotate.Node q = t(10, null, t(30, t(20, null, t(25)), t(40))); // x hangs on the RIGHT of q
        y = Ex6Rotate.rotateRight(q.right);
        assertSame(y, q.right);
        assertEquals("10(-,20(-,30(25,40)))", shape(q));
        checkLinks(q, null);
    }

    @Test
    void leftRotationInsideATreeOnBothSides() {
        Ex6Rotate.Node p = t(50, t(10, null, t(30, t(20), t(40))), null);
        Ex6Rotate.Node y = Ex6Rotate.rotateLeft(p.left);
        assertSame(y, p.left);
        assertEquals("50(30(10(-,20),40),-)", shape(p));
        checkLinks(p, null);
        Ex6Rotate.Node q = t(5, null, t(10, null, t(30, t(20), t(40))));
        y = Ex6Rotate.rotateLeft(q.right);
        assertSame(y, q.right);
        assertEquals("5(-,30(10(-,20),40))", shape(q));
        checkLinks(q, null);
    }

    @Test
    void aChainBecomesBalanced() {
        Ex6Rotate.Node root = t(30, t(20, t(10), null), null);
        assertEquals(3, height(root));
        Ex6Rotate.Node y = Ex6Rotate.rotateRight(root);
        assertEquals("20(10,30)", shape(y));
        assertEquals(2, height(y));
        checkLinks(y, null);
    }

    @Test
    void aZigZagNeedsTwoRotations() {
        Ex6Rotate.Node root = t(30, t(10, null, t(20)), null); // left-right case
        Ex6Rotate.rotateLeft(root.left); // first rotate the CHILD...
        Ex6Rotate.Node y = Ex6Rotate.rotateRight(root); // ...then the node
        assertEquals("20(10,30)", shape(y));
        checkLinks(y, null);
    }

    @Test
    void aRotationCanBeUndone() {
        Ex6Rotate.Node root = t(30, t(20, t(10), t(25)), t(40, t(35), t(50)));
        String before = shape(root);
        Ex6Rotate.Node y = Ex6Rotate.rotateRight(root);
        Ex6Rotate.Node back = Ex6Rotate.rotateLeft(y);
        assertEquals(before, shape(back));
        checkLinks(back, null);
    }

    @Test
    void missingChildThrows() {
        assertThrows(IllegalArgumentException.class, () -> Ex6Rotate.rotateRight(t(1, null, t(2))));
        assertThrows(IllegalArgumentException.class, () -> Ex6Rotate.rotateLeft(t(2, t(1), null)));
    }

    static Ex6Rotate.Node randomTree(Random rng, int n, List<Ex6Rotate.Node> all) {
        List<Integer> keys = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            keys.add(i);
        }
        java.util.Collections.shuffle(keys, rng);
        Ex6Rotate.Node root = null;
        for (int i = 0; i < n; i++) {
            Ex6Rotate.Node node = new Ex6Rotate.Node(keys.get(i));
            all.add(node);
            if (root == null) {
                root = node;
                continue;
            }
            Ex6Rotate.Node cur = root;
            while (true) {
                if (node.key < cur.key) {
                    if (cur.left == null) {
                        cur.left = node;
                        node.parent = cur;
                        break;
                    }
                    cur = cur.left;
                } else {
                    if (cur.right == null) {
                        cur.right = node;
                        node.parent = cur;
                        break;
                    }
                    cur = cur.right;
                }
            }
        }
        return root;
    }

    @Test
    void randomRotationsKeepTheOrderAndTheLinks() {
        Random rng = new Random(6);
        for (int round = 0; round < 300; round++) {
            List<Ex6Rotate.Node> all = new ArrayList<>();
            Ex6Rotate.Node root = randomTree(rng, 2 + rng.nextInt(38), all);
            List<Integer> keys = new ArrayList<>();
            inorder(root, keys);
            for (int i = 0; i < 8; i++) {
                Ex6Rotate.Node x = all.get(rng.nextInt(all.size()));
                if (rng.nextBoolean() && x.left != null) {
                    Ex6Rotate.rotateRight(x);
                } else if (x.right != null) {
                    Ex6Rotate.rotateLeft(x);
                }
                while (root.parent != null) {
                    root = root.parent;
                }
                List<Integer> now = new ArrayList<>();
                inorder(root, now);
                assertEquals(keys, now);
                checkLinks(root, null);
            }
        }
    }
}
