import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.TreeSet;
import org.junit.jupiter.api.Test;

class Ex6AvlTest {
    /** A node with the correct height field, computed here (not with your update). */
    static Ex6Avl.Node mk(int key, Ex6Avl.Node left, Ex6Avl.Node right) {
        Ex6Avl.Node n = new Ex6Avl.Node(key);
        n.left = left;
        n.right = right;
        n.height = 1 + Math.max(left == null ? 0 : left.height, right == null ? 0 : right.height);
        return n;
    }

    static Ex6Avl.Node mk(int key) {
        return mk(key, null, null);
    }

    static String shape(Ex6Avl.Node n) {
        if (n == null) {
            return "-";
        }
        if (n.left == null && n.right == null) {
            return Integer.toString(n.key);
        }
        return n.key + "(" + shape(n.left) + "," + shape(n.right) + ")";
    }

    static int trueHeight(Ex6Avl.Node n) {
        return n == null ? 0 : 1 + Math.max(trueHeight(n.left), trueHeight(n.right));
    }

    static void inorder(Ex6Avl.Node n, List<Integer> out) {
        if (n != null) {
            inorder(n.left, out);
            out.add(n.key);
            inorder(n.right, out);
        }
    }

    static void checkAvl(Ex6Avl.Node n) {
        if (n == null) {
            return;
        }
        assertEquals(trueHeight(n), n.height, "stored height of " + n.key + " is wrong");
        assertTrue(Math.abs(trueHeight(n.right) - trueHeight(n.left)) <= 1, "unbalanced at " + n.key);
        checkAvl(n.left);
        checkAvl(n.right);
    }

    static Ex6Avl.Node build(int... keys) {
        Ex6Avl.Node root = null;
        for (int k : keys) {
            root = Ex6Avl.insert(root, k);
        }
        return root;
    }

    @Test
    void heightAndBalance() {
        assertEquals(0, Ex6Avl.height(null));
        Ex6Avl.Node leaf = mk(5);
        assertEquals(1, Ex6Avl.height(leaf));
        assertEquals(0, Ex6Avl.balance(leaf));
        Ex6Avl.Node n = mk(10, mk(5), mk(20, null, mk(30)));
        assertEquals(3, Ex6Avl.height(n));
        assertEquals(1, Ex6Avl.balance(n)); // right (2) minus left (1)
        assertEquals(-2, Ex6Avl.balance(mk(10, mk(5, mk(2), null), null)));
    }

    @Test
    void updateRecomputesTheHeightFromTheChildren() {
        Ex6Avl.Node n = new Ex6Avl.Node(10);
        n.left = mk(5, mk(2), null);
        n.right = mk(20);
        Ex6Avl.update(n);
        assertEquals(3, n.height);
        n.left = null;
        Ex6Avl.update(n);
        assertEquals(2, n.height);
    }

    @Test
    void rebalanceLeavesABalancedNodeAlone() {
        Ex6Avl.Node n = mk(10, mk(5), mk(20));
        assertSame(n, Ex6Avl.rebalance(n));
        assertEquals("10(5,20)", shape(n));
    }

    @Test
    void theFourCases() {
        int[][] orders = {{30, 20, 10}, {10, 20, 30}, {30, 10, 20}, {10, 30, 20}};
        long[] rotations = {1, 1, 2, 2};
        for (int i = 0; i < 4; i++) {
            Ex6Avl.rotations = 0;
            Ex6Avl.Node root = build(orders[i]);
            assertEquals("20(10,30)", shape(root));
            assertEquals(rotations[i], Ex6Avl.rotations);
            checkAvl(root);
        }
    }

    @Test
    void rebalanceDirectlyOnTheFourShapes() {
        assertEquals("20(10,30)", shape(Ex6Avl.rebalance(mk(30, mk(20, mk(10), null), null))));
        assertEquals("20(10,30)", shape(Ex6Avl.rebalance(mk(30, mk(10, null, mk(20)), null))));
        assertEquals("20(10,30)", shape(Ex6Avl.rebalance(mk(10, null, mk(20, null, mk(30))))));
        assertEquals("20(10,30)", shape(Ex6Avl.rebalance(mk(10, null, mk(30, mk(20), null)))));
    }

    @Test
    void inserting1To7CountsTheRotationsOfVideo1() {
        Ex6Avl.rotations = 0;
        Ex6Avl.Node root = null;
        long[] expected = {0, 0, 1, 1, 2, 3, 4};
        for (int k = 1; k <= 7; k++) {
            root = Ex6Avl.insert(root, k);
            assertEquals(expected[k - 1], Ex6Avl.rotations);
        }
        assertEquals("4(2(1,3),6(5,7))", shape(root));
        assertEquals(3, root.height);
    }

    @Test
    void sortedInsertionStaysLogarithmic() {
        int[][] cases = {{1000, 10}, {1023, 10}, {2000, 11}};
        for (int[] c : cases) {
            Ex6Avl.Node root = null;
            for (int k = 1; k <= c[0]; k++) {
                root = Ex6Avl.insert(root, k);
            }
            assertEquals(c[1], root.height);
            List<Integer> keys = new ArrayList<>();
            inorder(root, keys);
            assertEquals(c[0], keys.size());
        }
        Ex6Avl.rotations = 0;
        Ex6Avl.Node root = null;
        for (int k = 1; k <= 1023; k++) {
            root = Ex6Avl.insert(root, k);
        }
        assertEquals(1013, Ex6Avl.rotations);
    }

    @Test
    void duplicatesAreIgnored() {
        Ex6Avl.Node root = build(5, 3, 8, 3, 5, 8, 1);
        List<Integer> keys = new ArrayList<>();
        inorder(root, keys);
        assertEquals(List.of(1, 3, 5, 8), keys);
        checkAvl(root);
    }

    @Test
    void randomInsertionsKeepEveryInvariant() {
        Random rng = new Random(7);
        double phi = (1 + Math.sqrt(5)) / 2;
        for (int round = 0; round < 200; round++) {
            int count = 1 + rng.nextInt(119);
            TreeSet<Integer> set = new TreeSet<>();
            Ex6Avl.Node root = null;
            for (int i = 0; i < count; i++) {
                int k = rng.nextInt(500);
                set.add(k);
                root = Ex6Avl.insert(root, k);
                checkAvl(root);
            }
            List<Integer> keys = new ArrayList<>();
            inorder(root, keys);
            assertEquals(new ArrayList<>(set), keys);
            assertTrue(root.height <= Math.log(set.size() + 1) / Math.log(phi) + 1e-9); // h <= log_phi(n + 1)
        }
    }

    @Test
    void oneInsertionNeedsAtMostTwoSingleRotations() {
        Random rng = new Random(8);
        List<Integer> keys = new ArrayList<>();
        for (int i = 0; i < 10_000; i++) {
            keys.add(i);
        }
        java.util.Collections.shuffle(keys, rng);
        Ex6Avl.Node root = null;
        for (int i = 0; i < 600; i++) {
            long before = Ex6Avl.rotations;
            root = Ex6Avl.insert(root, keys.get(i));
            assertTrue(Ex6Avl.rotations - before <= 2);
        }
    }
}
