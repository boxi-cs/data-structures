import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.TreeMap;
import org.junit.jupiter.api.Test;

class Ex6SortedMapTest {
    static final int[] SCORE_KEYS = {72, 88, 95, 61, 79, 84};
    static final String[] SCORE_NAMES = {"Ana", "Ben", "Cai", "Dee", "Eli", "Fay"};

    static Ex6SortedMap.Node scores() {
        Ex6SortedMap.Node root = null;
        for (int i = 0; i < SCORE_KEYS.length; i++) {
            root = Ex6SortedMap.insert(root, SCORE_KEYS[i], SCORE_NAMES[i]);
        }
        return root;
    }

    /** A perfectly balanced tree of the sorted keys (insert the middle first). */
    static Ex6SortedMap.Node balanced(int[] keys) {
        Ex6SortedMap.Node[] root = {null};
        List<int[]> stack = new ArrayList<>();
        stack.add(new int[] {0, keys.length - 1});
        while (!stack.isEmpty()) {
            int[] range = stack.remove(stack.size() - 1);
            if (range[0] > range[1]) {
                continue;
            }
            int mid = (range[0] + range[1]) / 2;
            root[0] = Ex6SortedMap.insert(root[0], keys[mid], Integer.toString(keys[mid]));
            stack.add(new int[] {range[0], mid - 1});
            stack.add(new int[] {mid + 1, range[1]});
        }
        return root[0];
    }

    static int height(Ex6SortedMap.Node n) {
        return n == null ? 0 : 1 + Math.max(height(n.left), height(n.right));
    }

    static List<Integer> keysOf(List<Ex6SortedMap.Node> nodes) {
        List<Integer> out = new ArrayList<>();
        for (Ex6SortedMap.Node n : nodes) {
            out.add(n.key);
        }
        return out;
    }

    @Test
    void firstAndLast() {
        Ex6SortedMap.Node root = scores();
        assertEquals(61, Ex6SortedMap.first(root).key);
        assertEquals("Dee", Ex6SortedMap.first(root).value);
        assertEquals(95, Ex6SortedMap.last(root).key);
        assertNull(Ex6SortedMap.first(null));
        assertNull(Ex6SortedMap.last(null));
    }

    @Test
    void floorAndCeilingOfVideo4() {
        Ex6SortedMap.Node root = scores();
        assertEquals("Eli", Ex6SortedMap.floor(root, 80).value);
        assertEquals("Fay", Ex6SortedMap.ceiling(root, 80).value);
        assertEquals(79, Ex6SortedMap.floor(root, 79).key); // an exact hit is its own floor and ceiling
        assertEquals(79, Ex6SortedMap.ceiling(root, 79).key);
    }

    @Test
    void floorAndCeilingOutsideTheKeys() {
        Ex6SortedMap.Node root = scores();
        assertNull(Ex6SortedMap.floor(root, 60));
        assertNull(Ex6SortedMap.ceiling(root, 96));
        assertEquals(95, Ex6SortedMap.floor(root, 1000).key);
        assertEquals(61, Ex6SortedMap.ceiling(root, -5).key);
        assertNull(Ex6SortedMap.floor(null, 5));
        assertNull(Ex6SortedMap.ceiling(null, 5));
    }

    @Test
    void subMapIsHalfOpenAndInOrder() {
        Ex6SortedMap.Node root = scores();
        assertEquals(List.of(72, 79, 84, 88), keysOf(Ex6SortedMap.subMap(root, 70, 90)));
        assertEquals(List.of(72, 79, 84), keysOf(Ex6SortedMap.subMap(root, 72, 88))); // lo included, hi excluded
        assertTrue(Ex6SortedMap.subMap(root, 89, 94).isEmpty());
        assertTrue(Ex6SortedMap.subMap(null, 0, 10).isEmpty());
        assertEquals(List.of(61, 72, 79, 84, 88, 95), keysOf(Ex6SortedMap.subMap(root, 0, 1000)));
    }

    @Test
    void theQueriesAgreeWithTheJdkTreeMapOnRandomTrees() {
        Random rng = new Random(8);
        for (int round = 0; round < 200; round++) {
            TreeMap<Integer, String> ref = new TreeMap<>();
            Ex6SortedMap.Node root = null;
            int count = 1 + rng.nextInt(59);
            for (int i = 0; i < count; i++) {
                int k = rng.nextInt(300);
                ref.put(k, "v" + k);
                root = Ex6SortedMap.insert(root, k, "v" + k);
            }
            for (int i = 0; i < 20; i++) {
                int q = rng.nextInt(315) - 5;
                Integer f = ref.floorKey(q);
                Integer c = ref.ceilingKey(q);
                Ex6SortedMap.Node fn = Ex6SortedMap.floor(root, q);
                Ex6SortedMap.Node cn = Ex6SortedMap.ceiling(root, q);
                assertEquals(f, fn == null ? null : fn.key);
                assertEquals(c, cn == null ? null : cn.key);
                int hi = q + rng.nextInt(60);
                assertEquals(new ArrayList<>(ref.subMap(q, hi).keySet()), keysOf(Ex6SortedMap.subMap(root, q, hi)));
            }
        }
    }

    @Test
    void subMapLooksOnlyAtTheSubtreesThatCanHoldTheRange() {
        int[] keys = new int[1023];
        for (int i = 0; i < keys.length; i++) {
            keys[i] = 2 * i; // even numbers: a balanced tree of height 10
        }
        Ex6SortedMap.Node root = balanced(keys);
        int h = height(root);
        Random rng = new Random(9);
        for (int i = 0; i < 300; i++) {
            int lo = rng.nextInt(2065) - 5;
            int hi = lo + rng.nextInt(300);
            Ex6SortedMap.visited = 0;
            List<Ex6SortedMap.Node> out = Ex6SortedMap.subMap(root, lo, hi);
            assertTrue(Ex6SortedMap.visited <= 2L * h + out.size(), "range " + lo + ".." + hi + " visited " + Ex6SortedMap.visited);
        }
        Ex6SortedMap.visited = 0;
        Ex6SortedMap.subMap(root, 1000, 1000); // an empty range: just the two boundary paths
        assertTrue(Ex6SortedMap.visited <= 2L * h);
    }
}
