/**
 * Exercise 6 (implementation): rotations on a binary tree whose nodes know their parent.
 *
 * Three milestones, in order; run the tests after each one.
 *
 * Milestone 1 -- rotateRight(x) for a node x that is the root of the whole tree (x.parent == null).
 *     Let y = x.left. After the rotation y is the root of the subtree, x is the RIGHT child of y, and the subtree
 *     that used to be y.right (the middle subtree) becomes the LEFT child of x. The in-order sequence of the keys
 *     does not change. Return y, the new root of the subtree. Keep the parent links right: y.parent, x.parent and
 *     the parent of the middle subtree.
 * Milestone 2 -- the same when x has a parent p: y must hang from p on the SAME side where x used to hang
 *     (is p.left == x, or p.right == x?), and y.parent must become p.
 * Milestone 3 -- rotateLeft(x), the mirror image (y = x.right, the middle subtree is y.left), and both methods
 *     throw IllegalArgumentException when the child they need does not exist.
 */
public final class Ex6Rotate {
    private Ex6Rotate() {}

    public static final class Node {
        public int key;
        public Node left;
        public Node right;
        public Node parent;

        public Node(int key) {
            this(key, null, null);
        }

        public Node(int key, Node left, Node right) {
            this.key = key;
            this.left = left;
            this.right = right;
            if (left != null) {
                left.parent = this;
            }
            if (right != null) {
                right.parent = this;
            }
        }
    }

    public static Node rotateRight(Node x) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static Node rotateLeft(Node x) {
        throw new UnsupportedOperationException("not implemented");
    }
}
