/**
 * Exercise 7 (implementation): AVL insertion.
 *
 * The rotations are given (they call update, which you write). Three milestones, in order; run the tests after
 * each one.
 *
 * Milestone 1 -- the bookkeeping. A leaf has height 1 and an empty subtree (null) has height 0.
 *     height(n)   -> n.height, or 0 for null
 *     update(n)   -> set n.height = 1 + max(height(left), height(right))
 *     balance(n)  -> height(right) - height(left)   (the SAME convention as the videos: positive = leans right)
 * Milestone 2 -- rebalance(n): n has just been changed, its children are valid AVL trees but |balance(n)| may be 2.
 *     First update(n). If balance(n) < -1 the node is left-heavy: when its left child leans RIGHT (balance > 0)
 *     rotate that child left first (the left-right case), then rotate n right. The mirror image when balance(n) > 1.
 *     Return the new root of the subtree (n itself when nothing is wrong).
 * Milestone 3 -- insert(root, key): the ordinary BST insertion (smaller keys go left, larger go right, a key that
 *     is already there is ignored), and on the way back up call rebalance on every node of the path.
 *     Return the new root of the whole tree.
 */
public final class Ex6Avl {
    private Ex6Avl() {}

    public static long rotations; // counts single rotations; a double rotation counts as two

    public static final class Node {
        public final int key;
        public Node left;
        public Node right;
        public int height = 1; // a leaf has height 1; an empty subtree has height 0

        public Node(int key) {
            this.key = key;
        }
    }

    public static int height(Node n) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static void update(Node n) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static int balance(Node n) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static Node rotateRight(Node x) { // given
        rotations++;
        Node y = x.left;
        x.left = y.right;
        y.right = x;
        update(x); // x is now below y, so x first
        update(y);
        return y;
    }

    public static Node rotateLeft(Node x) { // given
        rotations++;
        Node y = x.right;
        x.right = y.left;
        y.left = x;
        update(x);
        update(y);
        return y;
    }

    public static Node rebalance(Node n) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static Node insert(Node root, int key) {
        throw new UnsupportedOperationException("not implemented");
    }
}
