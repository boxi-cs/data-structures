/**
 * Exercises 9 and 10 (read the code). Each class below came from an AI assistant together with a claim.
 *
 * In both exercises the claim is wrong because of a bug. For each: find a small input that shows the bug (insert the
 * keys and check the AVL property with the heights RECOMPUTED from the tree, not read from the height field), say
 * what exactly goes wrong and why small examples do not show it, and write the fix.
 *
 * Exercise 9:  Avl9  -- "an AVL tree: insert rebalances with the right rotation for a left-heavy node and the left
 *                        rotation for a right-heavy node, so every balance factor stays in -1, 0, 1".
 * Exercise 10: Avl10 -- "an AVL tree whose rotations keep the stored heights up to date, so insert is O(log n) and
 *                        the height stays logarithmic".
 */
public final class Ex6Read {
    private Ex6Read() {}

    public static final class Node {
        public final int key;
        public Node left;
        public Node right;
        public int height = 1;

        public Node(int key) {
            this.key = key;
        }
    }

    static int height(Node n) {
        return n == null ? 0 : n.height;
    }

    static void update(Node n) {
        n.height = 1 + Math.max(height(n.left), height(n.right));
    }

    static int balance(Node n) {
        return height(n.right) - height(n.left); // positive = leans right
    }

    /** An AVL tree. insert uses the right rotation for a left-heavy node and the left rotation for a right-heavy node. */
    public static class Avl9 {
        public Node root;

        public void insert(int key) {
            root = insert(root, key);
        }

        Node rotateRight(Node x) {
            Node y = x.left;
            x.left = y.right;
            y.right = x;
            update(x);
            update(y);
            return y;
        }

        Node rotateLeft(Node x) {
            Node y = x.right;
            x.right = y.left;
            y.left = x;
            update(x);
            update(y);
            return y;
        }

        Node rebalance(Node n) {
            update(n);
            int b = balance(n);
            if (b < -1) {
                return rotateRight(n);
            }
            if (b > 1) {
                return rotateLeft(n);
            }
            return n;
        }

        private Node insert(Node n, int key) {
            if (n == null) {
                return new Node(key);
            }
            if (key < n.key) {
                n.left = insert(n.left, key);
            } else if (key > n.key) {
                n.right = insert(n.right, key);
            } else {
                return n;
            }
            return rebalance(n);
        }
    }

    /** An AVL tree whose rotations keep the stored heights up to date, so insert is O(log n). */
    public static class Avl10 {
        public Node root;

        public void insert(int key) {
            root = insert(root, key);
        }

        Node rotateRight(Node x) {
            Node y = x.left;
            x.left = y.right;
            y.right = x;
            update(y);
            update(x);
            return y;
        }

        Node rotateLeft(Node x) {
            Node y = x.right;
            x.right = y.left;
            y.left = x;
            update(y);
            update(x);
            return y;
        }

        Node rebalance(Node n) {
            update(n);
            int b = balance(n);
            if (b < -1) {
                if (balance(n.left) > 0) {
                    n.left = rotateLeft(n.left);
                }
                return rotateRight(n);
            }
            if (b > 1) {
                if (balance(n.right) < 0) {
                    n.right = rotateRight(n.right);
                }
                return rotateLeft(n);
            }
            return n;
        }

        private Node insert(Node n, int key) {
            if (n == null) {
                return new Node(key);
            }
            if (key < n.key) {
                n.left = insert(n.left, key);
            } else if (key > n.key) {
                n.right = insert(n.right, key);
            } else {
                return n;
            }
            return rebalance(n);
        }
    }
}
