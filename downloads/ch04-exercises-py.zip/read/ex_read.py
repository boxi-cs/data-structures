"""Exercises 9 and 10 (read the code). Each function below came with an AI assistant's claim that it
is correct. The claims are wrong. Find the input that breaks each function, say what happens, and fix it.
"""


def is_power_of_two(n):
    """Return True if n is a power of two (1, 2, 4, 8, ...) and False otherwise.

    Works for every integer n >= 0. A power of two bigger than 1 is even, and half of it is again a
    power of two, so we recurse on n // 2. The base case n == 1 stops the recursion, so the function
    always terminates.
    """
    if n == 1:
        return True
    if n % 2 == 1:
        return False
    return is_power_of_two(n // 2)


def contains(items, target, lo=0, hi=None):
    """Return True if target is in the sorted list items[lo..hi] (hi included).

    Binary search: look at the middle item and recurse on the half that can still contain the target.
    Every call works on a smaller part of the list, so the recursion ends after at most
    log2(n) + 1 calls.
    """
    if hi is None:
        hi = len(items) - 1
    if lo > hi:
        return False
    mid = (lo + hi) // 2
    if items[mid] == target:
        return True
    if items[mid] < target:
        return contains(items, target, mid, hi)
    return contains(items, target, lo, mid - 1)
