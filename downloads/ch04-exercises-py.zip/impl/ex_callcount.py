"""Exercise 7 (implementation): count the calls of the naive Fibonacci function without making them.

The naive function

    def fib(n):
        if n <= 1:
            return n
        return fib(n - 1) + fib(n - 2)

makes 15 calls for fib(5) and 2,692,537 for fib(30). Write `fib_calls(n)`: the number of calls that
fib(n) would make (counting the first call), WITHOUT running fib. It must be fast for n = 80, where the
real count has 17 digits.

Milestone 1: the base cases (how many calls does fib(0) make? fib(1)?).
Milestone 2: the recurrence from Exercise 1(d): calls(n) = 1 + calls(n - 1) + calls(n - 2).
Milestone 3: make it fast. Remember answers you already computed (a dict, or an array filled once).

Run:  pytest test_ex_callcount.py
"""


def fib_calls(n):
    """Number of calls the naive recursive fib(n) makes, counting the first one. n >= 0."""
    raise NotImplementedError
