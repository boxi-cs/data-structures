"""Exercise 8 (implementation): partition, then quickselect (the k-th smallest item without sorting).

Milestone 1 -- partition(items, lo, hi): Lomuto partition of items[lo..hi] (both ends included) with the
    LAST item items[hi] as the pivot. Rearrange items[lo..hi] in place so that everything smaller than the
    pivot comes first, then the pivot, then everything else; return the pivot's final index. Compare each
    of the other items with the pivot exactly once, using only `<` between two items.

Milestone 2 -- quickselect(items, k, rng): return the item that would be at index k (0-based) if the list
    were sorted, WITHOUT sorting it and WITHOUT changing `items` (work on a copy). Recurse (or loop) on
    only the side that contains index k.

Milestone 3 -- choose the pivot at random so that already-sorted input is not a bad case: before each
    partition pick r = rng.randint(lo, hi) (both ends included) and swap items[r] with items[hi].

Run:  pytest test_ex_quickselect.py
"""


def partition(items, lo, hi):
    """Lomuto partition of items[lo..hi] around items[hi]; return the pivot's final index."""
    raise NotImplementedError


def quickselect(items, k, rng):
    """The k-th smallest item (0-based) of `items`; `items` itself is left unchanged."""
    raise NotImplementedError
