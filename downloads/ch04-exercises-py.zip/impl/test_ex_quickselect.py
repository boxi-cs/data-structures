import random

import ex_quickselect


class Counted:
    """An item that counts every comparison made with it (all comparison operators)."""

    count = 0

    def __init__(self, value):
        self.value = value

    def _tick(self):
        Counted.count += 1

    def __lt__(self, other):
        self._tick()
        return self.value < other.value

    def __le__(self, other):
        self._tick()
        return self.value <= other.value

    def __gt__(self, other):
        self._tick()
        return self.value > other.value

    def __ge__(self, other):
        self._tick()
        return self.value >= other.value

    def __eq__(self, other):
        self._tick()
        return self.value == other.value

    __hash__ = None


def test_partition_places_the_pivot_and_splits_the_rest():
    rng = random.Random(1)
    for _ in range(200):
        n = rng.randrange(1, 15)
        items = [rng.randrange(8) for _ in range(n)]
        lo = rng.randrange(0, n)
        hi = rng.randrange(lo, n)
        before = list(items)
        pivot = items[hi]
        p = ex_quickselect.partition(items, lo, hi)
        assert lo <= p <= hi
        assert items[p] == pivot
        assert all(x < pivot for x in items[lo:p])
        assert all(x >= pivot for x in items[p + 1:hi + 1])
        assert items[:lo] == before[:lo] and items[hi + 1:] == before[hi + 1:]  # outside the range untouched
        assert sorted(items) == sorted(before)  # only a rearrangement


def test_partition_makes_exactly_hi_minus_lo_comparisons():
    for n in (1, 2, 5, 20):
        items = [Counted(v) for v in random.Random(n).sample(range(100), n)]
        Counted.count = 0
        ex_quickselect.partition(items, 0, n - 1)
        assert Counted.count == n - 1


def test_quickselect_matches_sorting():
    rng = random.Random(7)
    for _ in range(100):
        n = rng.randrange(1, 40)
        items = [rng.randrange(20) for _ in range(n)]
        for k in range(n):
            assert ex_quickselect.quickselect(items, k, random.Random(k)) == sorted(items)[k]


def test_quickselect_leaves_the_input_unchanged():
    items = [5, 3, 9, 1, 7, 3]
    copy = list(items)
    ex_quickselect.quickselect(items, 2, random.Random(0))
    assert items == copy


def test_quickselect_is_linear_even_on_sorted_input():
    n = 4000
    for build in (lambda: list(range(n)), lambda: list(range(n, 0, -1)), lambda: random.Random(3).sample(range(10 * n), n)):
        items = [Counted(v) for v in build()]
        Counted.count = 0
        got = ex_quickselect.quickselect(items, n // 2, random.Random(5))
        assert got.value == sorted(i.value for i in items)[n // 2]
        assert Counted.count < 12 * n, f"{Counted.count} comparisons for n = {n}: is the pivot random?"
