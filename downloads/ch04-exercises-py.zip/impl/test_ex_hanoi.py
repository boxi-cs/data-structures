import ex_hanoi


def replay(n, moves):
    """Play the moves on three pegs; fail if a move is illegal. Return the final pegs."""
    pegs = {"A": list(range(n, 0, -1)), "B": [], "C": []}  # bottom ... top
    for src, dst in moves:
        assert pegs[src], f"move {src}->{dst}: peg {src} is empty"
        disk = pegs[src][-1]
        assert not pegs[dst] or pegs[dst][-1] > disk, f"move {src}->{dst}: disk {disk} on a smaller disk"
        pegs[dst].append(pegs[src].pop())
    return pegs


def test_no_disks_no_moves():
    assert ex_hanoi.hanoi(0) == []


def test_one_disk():
    assert ex_hanoi.hanoi(1) == [("A", "C")]


def test_two_disks_exact_moves():
    assert ex_hanoi.hanoi(2) == [("A", "B"), ("A", "C"), ("B", "C")]


def test_moves_are_legal_and_finish_on_the_target_peg():
    for n in range(0, 11):
        pegs = replay(n, ex_hanoi.hanoi(n))
        assert pegs["A"] == [] and pegs["B"] == []
        assert pegs["C"] == list(range(n, 0, -1))


def test_number_of_moves_is_two_to_the_n_minus_one():
    for n in range(0, 16):
        assert len(ex_hanoi.hanoi(n)) == 2**n - 1


def test_other_peg_names():
    moves = ex_hanoi.hanoi(3, "X", "Z", "Y")
    assert moves[0] in (("X", "Z"),) and len(moves) == 7
    assert all(a != b for a, b in moves)
    assert {p for move in moves for p in move} == {"X", "Y", "Z"}
