"""Exercise 6 (implementation): Towers of Hanoi.

Move n disks from peg `src` to peg `dst`, using peg `tmp` as a spare. Only one disk moves at a time,
only the top disk of a peg can move, and a disk may never sit on a smaller disk. The disks start on
`src` with the largest at the bottom.

Return the list of moves in order; a move is a pair (from_peg, to_peg), e.g. ("A", "C").

Milestone 1: the base case (what does n == 0 need?).
Milestone 2: the recursive structure from Exercise 4: move n - 1 disks out of the way, move the
             biggest disk, move the n - 1 disks back on top of it.
Milestone 3: check that the number of moves is the closed form you derived (2**n - 1).

Run:  pytest test_ex_hanoi.py
"""


def hanoi(n, src="A", dst="C", tmp="B"):
    """Return the list of (from_peg, to_peg) moves that solves Towers of Hanoi for n disks."""
    raise NotImplementedError
