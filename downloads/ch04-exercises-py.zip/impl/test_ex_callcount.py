import ex_callcount


def naive_fib_calls(n):
    """The honest way: run the naive recursion and count (only used for small n)."""
    calls = 0

    def fib(k):
        nonlocal calls
        calls += 1
        return k if k <= 1 else fib(k - 1) + fib(k - 2)

    fib(n)
    return calls


def test_base_cases():
    assert ex_callcount.fib_calls(0) == 1
    assert ex_callcount.fib_calls(1) == 1


def test_matches_the_real_counts_from_the_video():
    assert ex_callcount.fib_calls(5) == 15
    assert ex_callcount.fib_calls(10) == 177
    assert ex_callcount.fib_calls(20) == 21891
    assert ex_callcount.fib_calls(30) == 2692537


def test_matches_a_real_run_for_small_n():
    for n in range(0, 21):
        assert ex_callcount.fib_calls(n) == naive_fib_calls(n)


def test_fast_and_exact_for_n_80():
    a, b = 0, 1  # fib(0), fib(1)
    for _ in range(81):
        a, b = b, a + b
    fib_81 = a
    assert ex_callcount.fib_calls(80) == 2 * fib_81 - 1  # the closed form you prove in Exercise 1(d)
