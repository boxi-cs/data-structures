import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.Random;
import org.junit.jupiter.api.Test;

class Ex8HeapSortTest {
    static final int[] VIDEO = {20, 16, 9, 12, 5, 8, 3, 14, 6, 11};

    static boolean isMaxHeap(int[] a) {
        for (int j = 1; j < a.length; j++) {
            if (a[(j - 1) / 2] < a[j]) {
                return false;
            }
        }
        return true;
    }

    @Test
    void downHeapSinksOneEntry() {
        int[] a = {1, 9, 8, 7, 6};
        int comparisons = Ex8HeapSort.downHeap(a, 0, 5);
        assertArrayEquals(new int[] {9, 7, 8, 1, 6}, a);
        assertEquals(4, comparisons);
    }

    @Test
    void downHeapStopsAtTheEndOfTheHeapPart() {
        int[] a = {1, 9, 8, 7, 6};
        Ex8HeapSort.downHeap(a, 0, 3);
        assertArrayEquals(new int[] {9, 1, 8, 7, 6}, a);
        int[] b = {5, 9, 3};
        assertEquals(1, Ex8HeapSort.downHeap(b, 0, 2));
        assertArrayEquals(new int[] {9, 5, 3}, b);
    }

    @Test
    void tiesDoNotMove() {
        int[] a = {4, 4, 4};
        assertEquals(2, Ex8HeapSort.downHeap(a, 0, 3));
        assertArrayEquals(new int[] {4, 4, 4}, a);
    }

    @Test
    void buildMaxHeapOfVideo4() {
        int[] a = VIDEO.clone();
        assertEquals(9, Ex8HeapSort.buildMaxHeap(a));
        assertArrayEquals(new int[] {20, 16, 9, 14, 11, 8, 3, 12, 6, 5}, a);
    }

    @Test
    void buildMakesAHeapAndStaysBelow2nComparisons() {
        Random rng = new Random(1);
        for (int n = 0; n < 200; n++) {
            int[] a = new int[n];
            for (int i = 0; i < n; i++) {
                a[i] = rng.nextInt(50);
            }
            int comparisons = Ex8HeapSort.buildMaxHeap(a);
            assertTrue(isMaxHeap(a));
            assertTrue(comparisons <= 2 * n);
        }
    }

    @Test
    void heapSortOfVideo4() {
        int[] a = VIDEO.clone();
        assertEquals(35, Ex8HeapSort.heapSort(a));
        assertArrayEquals(new int[] {3, 5, 6, 8, 9, 11, 12, 14, 16, 20}, a);
    }

    @Test
    void heapSortSortsLikeArraysSort() {
        Random rng = new Random(42);
        for (int n : new int[] {0, 1, 2, 3, 4, 5, 10, 31, 32, 33, 100, 1000}) {
            for (int round = 0; round < 20; round++) {
                int[] a = new int[n];
                for (int i = 0; i < n; i++) {
                    a[i] = rng.nextInt(Math.max(1, n / 2));
                }
                int[] expected = a.clone();
                Arrays.sort(expected);
                int[] same = a;
                Ex8HeapSort.heapSort(a);
                assertSame(same, a);
                assertArrayEquals(expected, a);
            }
        }
        int[] backwards = new int[500];
        for (int i = 0; i < backwards.length; i++) {
            backwards[i] = 500 - i;
        }
        Ex8HeapSort.heapSort(backwards);
        for (int i = 0; i < backwards.length; i++) {
            assertEquals(i + 1, backwards[i]);
        }
    }
}
