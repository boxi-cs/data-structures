import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import org.junit.jupiter.api.Test;

class Ex8HeapTest {
    static boolean isHeap(List<Integer> data) {
        for (int j = 1; j < data.size(); j++) {
            if (data.get((j - 1) / 2) > data.get(j)) {
                return false;
            }
        }
        return true;
    }

    @Test
    void indexFormulas() {
        int[] parents = {0, 0, 1, 1, 2, 2};
        for (int j = 1; j <= 6; j++) {
            assertEquals(parents[j - 1], Ex8Heap.parent(j));
        }
        assertEquals(1, Ex8Heap.left(0));
        assertEquals(2, Ex8Heap.right(0));
        assertEquals(7, Ex8Heap.left(3));
        assertEquals(8, Ex8Heap.right(3));
    }

    @Test
    void theRootHasNoParent() {
        assertThrows(IllegalArgumentException.class, () -> Ex8Heap.parent(0));
    }

    @Test
    void theInsertsOfVideo2() {
        Ex8Heap heap = new Ex8Heap();
        int[] values = {15, 9, 20, 4, 12, 7, 2};
        List<List<Integer>> arrays = List.of(
            List.of(15), List.of(9, 15), List.of(9, 15, 20), List.of(4, 9, 20, 15), List.of(4, 9, 20, 15, 12),
            List.of(4, 9, 7, 15, 12, 20), List.of(2, 9, 4, 15, 12, 20, 7));
        int[] comparisons = {0, 1, 1, 2, 1, 2, 2};
        int[] swaps = {0, 1, 0, 2, 0, 1, 2};
        for (int i = 0; i < values.length; i++) {
            long c = heap.comparisons;
            long s = heap.swaps;
            heap.insert(values[i]);
            assertEquals(arrays.get(i), heap.toList());
            assertEquals(comparisons[i], heap.comparisons - c);
            assertEquals(swaps[i], heap.swaps - s);
        }
        assertEquals(9, heap.comparisons);
        assertEquals(6, heap.swaps);
    }

    @Test
    void theRemovalsOfVideo2() {
        Ex8Heap heap = new Ex8Heap();
        for (int x : new int[] {15, 9, 20, 4, 12, 7, 2}) {
            heap.insert(x);
        }
        int[] smallest = {2, 4, 7, 9, 12, 15, 20};
        List<List<Integer>> arrays = List.of(
            List.of(4, 9, 7, 15, 12, 20), List.of(7, 9, 20, 15, 12), List.of(9, 12, 20, 15), List.of(12, 15, 20),
            List.of(15, 20), List.of(20), List.of());
        int[] comparisons = {3, 2, 3, 2, 1, 0, 0};
        int[] swaps = {1, 1, 1, 1, 1, 0, 0};
        for (int i = 0; i < smallest.length; i++) {
            long c = heap.comparisons;
            long s = heap.swaps;
            assertEquals(smallest[i], heap.peek());
            assertEquals(smallest[i], heap.removeMin());
            assertEquals(arrays.get(i), heap.toList());
            assertEquals(comparisons[i], heap.comparisons - c);
            assertEquals(swaps[i], heap.swaps - s);
        }
    }

    @Test
    void emptyHeapThrows() {
        Ex8Heap heap = new Ex8Heap();
        heap.insert(1);
        heap.removeMin();
        assertThrows(IllegalStateException.class, heap::removeMin);
        assertThrows(IllegalStateException.class, heap::peek);
    }

    @Test
    void randomOperationsAgainstASortedList() {
        Random rng = new Random(2026);
        for (int round = 0; round < 200; round++) {
            Ex8Heap heap = new Ex8Heap();
            List<Integer> reference = new ArrayList<>();
            int steps = 1 + rng.nextInt(60);
            for (int i = 0; i < steps; i++) {
                if (!reference.isEmpty() && rng.nextDouble() < 0.4) {
                    int min = Collections.min(reference);
                    assertEquals(min, heap.removeMin());
                    reference.remove(Integer.valueOf(min));
                } else {
                    int x = rng.nextInt(20);
                    heap.insert(x);
                    reference.add(x);
                }
                assertTrue(isHeap(heap.toList()));
                assertEquals(reference.size(), heap.size());
            }
            List<Integer> out = new ArrayList<>();
            while (heap.size() > 0) {
                out.add(heap.removeMin());
            }
            Collections.sort(reference);
            assertEquals(reference, out);
        }
    }

    @Test
    void costOfIncreasingAndDecreasingInserts() {
        Ex8Heap up = new Ex8Heap();
        for (int x = 0; x < 1000; x++) {
            up.insert(x);
        }
        assertEquals(999, up.comparisons);
        assertEquals(0, up.swaps);
        Ex8Heap down = new Ex8Heap();
        for (int x = 1000; x > 0; x--) {
            down.insert(x);
        }
        assertEquals(7987, down.comparisons);
    }
}
