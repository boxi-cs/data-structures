import java.util.Comparator;

/**
 * Exercise 7 (implementation): a priority queue with a custom order and first-in-first-out ties.
 *
 * Three milestones, in order; run the tests after each one. You may build on java.util.PriorityQueue: the point
 * of this exercise is the interface, not another sift-down.
 *
 * Milestone 1 -- Ex8Pq(order): insert(priority, value), min() and removeMin() return an Entry, size().
 *     The entry whose priority is smallest according to `order` comes out first. Values are never compared
 *     (they may be maps or any other type). min() and removeMin() throw IllegalStateException when empty.
 * Milestone 2 -- the order is any Comparator<P>: Comparator.reverseOrder() hands out the LARGEST priority first.
 * Milestone 3 -- ties: entries that `order` considers equal come out in the order they were inserted (first in,
 *     first out). java.util.PriorityQueue does NOT promise this; give every entry a sequence number that breaks ties.
 */
public final class Ex8Pq<P, V> {
    public record Entry<P, V>(P priority, V value) {}

    public Ex8Pq(Comparator<? super P> order) {
        throw new UnsupportedOperationException("not implemented");
    }

    public int size() {
        throw new UnsupportedOperationException("not implemented");
    }

    public void insert(P priority, V value) {
        throw new UnsupportedOperationException("not implemented");
    }

    public Entry<P, V> min() {
        throw new UnsupportedOperationException("not implemented");
    }

    public Entry<P, V> removeMin() {
        throw new UnsupportedOperationException("not implemented");
    }
}
