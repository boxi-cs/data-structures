import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import org.junit.jupiter.api.Test;

class Ex8PqTest {
    static <P, V> List<Ex8Pq.Entry<P, V>> drain(Ex8Pq<P, V> pq) {
        List<Ex8Pq.Entry<P, V>> out = new ArrayList<>();
        while (pq.size() > 0) {
            out.add(pq.removeMin());
        }
        return out;
    }

    static <P, V> List<V> values(List<Ex8Pq.Entry<P, V>> entries) {
        List<V> out = new ArrayList<>();
        for (Ex8Pq.Entry<P, V> e : entries) {
            out.add(e.value());
        }
        return out;
    }

    @Test
    void smallestPriorityFirst() {
        Ex8Pq<Integer, String> pq = new Ex8Pq<>(Comparator.naturalOrder());
        pq.insert(3, "write report");
        pq.insert(1, "fix bug");
        pq.insert(2, "review code");
        assertEquals(3, pq.size());
        assertEquals(new Ex8Pq.Entry<>(1, "fix bug"), pq.min());
        assertEquals(3, pq.size());
        assertEquals(List.of("fix bug", "review code", "write report"), values(drain(pq)));
    }

    @Test
    void valuesAreNeverCompared() {
        Ex8Pq<Integer, Map<String, String>> pq = new Ex8Pq<>(Comparator.naturalOrder());
        pq.insert(1, Map.of("job", "a"));
        pq.insert(1, Map.of("job", "b"));
        pq.insert(0, Map.of("job", "c"));
        List<String> jobs = new ArrayList<>();
        for (Ex8Pq.Entry<Integer, Map<String, String>> e : drain(pq)) {
            jobs.add(e.value().get("job"));
        }
        assertEquals(List.of("c", "a", "b"), jobs);
    }

    @Test
    void emptyQueueThrows() {
        Ex8Pq<Integer, String> pq = new Ex8Pq<>(Comparator.naturalOrder());
        pq.insert(1, "x");
        pq.removeMin();
        assertThrows(IllegalStateException.class, pq::removeMin);
        assertThrows(IllegalStateException.class, pq::min);
    }

    @Test
    void reverseOrderGivesAMaxQueue() {
        Ex8Pq<Integer, String> pq = new Ex8Pq<>(Comparator.reverseOrder());
        for (int p : new int[] {3, 8, 1, 5}) {
            pq.insert(p, String.valueOf(p));
        }
        assertEquals(List.of("8", "5", "3", "1"), values(drain(pq)));
    }

    @Test
    void anyComparatorOrdersThePriorities() {
        Ex8Pq<String, String> pq = new Ex8Pq<>(Comparator.comparingInt(String::length).thenComparing(Comparator.naturalOrder()));
        for (String word : new String[] {"pear", "fig", "banana", "kiwi", "apple"}) {
            pq.insert(word, word.toUpperCase());
        }
        assertEquals(List.of("FIG", "KIWI", "PEAR", "APPLE", "BANANA"), values(drain(pq)));
    }

    @Test
    void equalPrioritiesComeOutFirstInFirstOut() {
        Ex8Pq<Integer, String> pq = new Ex8Pq<>(Comparator.naturalOrder());
        for (String name : new String[] {"a", "b", "c", "d", "e"}) {
            pq.insert(1, name);
        }
        assertEquals(List.of("a", "b", "c", "d", "e"), values(drain(pq)));
    }

    @Test
    void tiesWithInterleavedRemovals() {
        Ex8Pq<Integer, String> pq = new Ex8Pq<>(Comparator.naturalOrder());
        pq.insert(2, "a");
        pq.insert(1, "b");
        pq.insert(2, "c");
        assertEquals("b", pq.removeMin().value());
        pq.insert(2, "d");
        pq.insert(1, "e");
        assertEquals(List.of("e", "a", "c", "d"), values(drain(pq)));
    }

    @Test
    void tiesAlsoHoldUnderAReversedOrder() {
        Ex8Pq<Integer, String> pq = new Ex8Pq<>(Comparator.reverseOrder());
        for (String name : new String[] {"a", "b", "c"}) {
            pq.insert(7, name);
        }
        pq.insert(9, "z");
        assertEquals(List.of("z", "a", "b", "c"), values(drain(pq)));
    }

    @Test
    void randomOperationsAgainstAStableSort() {
        Random rng = new Random(7);
        for (int round = 0; round < 100; round++) {
            Ex8Pq<Integer, Integer> pq = new Ex8Pq<>(Comparator.naturalOrder());
            List<Ex8Pq.Entry<Integer, Integer>> entries = new ArrayList<>();
            int n = 1 + rng.nextInt(80);
            for (int i = 0; i < n; i++) {
                int p = rng.nextInt(6);
                pq.insert(p, i);
                entries.add(new Ex8Pq.Entry<>(p, i));
            }
            entries.sort(Comparator.comparingInt(Ex8Pq.Entry::priority)); // List.sort is stable
            assertEquals(entries, drain(pq));
        }
    }
}
