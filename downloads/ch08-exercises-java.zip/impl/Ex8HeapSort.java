/**
 * Exercise 8 (implementation): heap sort in place.
 *
 * Three milestones, in order; run the tests after each one. Everything works on a MAX-heap in a[0..n-1]
 * (0-based: the children of j are 2j+1 and 2j+2) and every method returns the number of comparisons it made,
 * counted exactly like the videos: one comparison between the two children (only when both are inside the heap),
 * then one comparison of the bigger child with a[j]; the bigger child moves up only if it is STRICTLY larger
 * than a[j].
 *
 * Milestone 1 -- downHeap(a, j, n): sink a[j] inside the heap a[0..n-1]; return the comparisons made.
 * Milestone 2 -- buildMaxHeap(a): bottom-up construction, in place: downHeap every internal node, the last one
 *     first (the last internal node is index (a.length - 2) / 2 for a.length >= 2). Return the total comparisons.
 * Milestone 3 -- heapSort(a): buildMaxHeap, then for end = a.length - 1 down to 1: swap a[0] and a[end], shrink
 *     the heap to a[0..end-1] and sink the new root. Sort in place, smallest first, with O(1) extra memory (no
 *     copy of the array, no Arrays.sort). Return the total comparisons, build phase included.
 */
public final class Ex8HeapSort {
    private Ex8HeapSort() {}

    public static int downHeap(int[] a, int j, int n) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static int buildMaxHeap(int[] a) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static int heapSort(int[] a) {
        throw new UnsupportedOperationException("not implemented");
    }
}
