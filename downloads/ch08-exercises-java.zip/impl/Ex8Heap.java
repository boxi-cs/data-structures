import java.util.List;

/**
 * Exercise 6 (implementation): a binary min-heap of ints stored in an array, 0-based like java.util.PriorityQueue.
 *
 * Three milestones, in order; run the tests after each one.
 *
 * Milestone 1 -- index arithmetic. For the entry at index j (the root is at index 0):
 *     parent(j) = (j - 1) / 2, left(j) = 2*j + 1, right(j) = 2*j + 2.
 *     The root has no parent: parent(0) must throw IllegalArgumentException (the formula would give
 *     (0 - 1) / 2 = 0 in Java because integer division rounds toward zero: the root would be its own parent).
 * Milestone 2 -- insert(x): add x at the end, then climb (up-heap): while x is not at the root and is smaller than
 *     its parent, swap them. Count ONE comparison for every "is x smaller than its parent?" test (also the one
 *     that stops the climb) in `comparisons`, and one swap for every swap in `swaps`.
 * Milestone 3 -- removeMin() and peek(). removeMin takes the last entry out of the array, puts it in the root
 *     (unless the heap is now empty) and sinks it (down-heap): at each step find the smaller child (ONE comparison
 *     between the two children, only when both exist), then ONE comparison of that child with x; if the child is
 *     smaller, swap and continue, otherwise stop. Return the old minimum. peek() returns the minimum without
 *     changing anything. Both throw IllegalStateException on an empty heap.
 *
 * size() and toList() (the entries in array order) are for the tests.
 */
public final class Ex8Heap {
    public long comparisons;
    public long swaps;

    public static int parent(int j) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static int left(int j) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static int right(int j) {
        throw new UnsupportedOperationException("not implemented");
    }

    public int size() {
        throw new UnsupportedOperationException("not implemented");
    }

    public List<Integer> toList() {
        throw new UnsupportedOperationException("not implemented");
    }

    public void insert(int x) {
        throw new UnsupportedOperationException("not implemented");
    }

    public int peek() {
        throw new UnsupportedOperationException("not implemented");
    }

    public int removeMin() {
        throw new UnsupportedOperationException("not implemented");
    }
}
