import java.util.ArrayList;

/**
 * Exercises 9 and 10 (read the code). Each class below came from an AI assistant together with a claim.
 *
 * In both exercises the claim is wrong because of a bug. For each: find a small input that shows the bug
 * (compare the output of repeated removeMin with the sorted input), say what exactly goes wrong and why small
 * examples do not show it, and write the fix.
 *
 * Exercise 9:  Heap9  -- "a min-heap in an ArrayList, 0-based like java.util.PriorityQueue; insert and removeMin are correct, O(log n)".
 * Exercise 10: Heap10 -- "removeMin sinks the new root along the smaller child, so the heap stays a heap".
 */
public final class Ex8Read {
    private Ex8Read() {}

    /** A min-heap in a list, 0-based like java.util.PriorityQueue. insert and removeMin are correct and take O(log n). */
    public static final class Heap9 {
        public final ArrayList<Integer> data = new ArrayList<>();

        public void insert(int x) {
            data.add(x);
            int j = data.size() - 1;
            while (j > 0 && data.get(j) < data.get((j - 1) / 2)) {
                int parent = (j - 1) / 2;
                swap(j, parent);
                j = parent;
            }
        }

        public int removeMin() {
            int smallest = data.get(0);
            int last = data.remove(data.size() - 1);
            if (!data.isEmpty()) {
                data.set(0, last);
                int n = data.size();
                int j = 0;
                while (2 * j < n) { // the children of j are 2j and 2j + 1
                    int small = 2 * j;
                    if (2 * j + 1 < n && data.get(2 * j + 1) < data.get(small)) {
                        small = 2 * j + 1;
                    }
                    if (data.get(small) >= data.get(j)) {
                        break;
                    }
                    swap(j, small);
                    j = small;
                }
            }
            return smallest;
        }

        private void swap(int i, int j) {
            int tmp = data.get(i);
            data.set(i, data.get(j));
            data.set(j, tmp);
        }
    }

    /**
     * A min-heap in a list, 0-based like java.util.PriorityQueue. removeMin sinks the new root along the
     * smaller child (it stops when the child is not smaller), so after every call the list is a heap again.
     */
    public static final class Heap10 {
        public final ArrayList<Integer> data = new ArrayList<>();

        public void insert(int x) {
            data.add(x);
            int j = data.size() - 1;
            while (j > 0 && data.get(j) < data.get((j - 1) / 2)) {
                int parent = (j - 1) / 2;
                swap(j, parent);
                j = parent;
            }
        }

        public int removeMin() {
            int smallest = data.get(0);
            int last = data.remove(data.size() - 1);
            if (!data.isEmpty()) {
                data.set(0, last);
                int n = data.size();
                int j = 0;
                while (2 * j + 1 < n) {
                    int child = 2 * j + 1;
                    if (data.get(child) >= data.get(j)) {
                        break;
                    }
                    swap(j, child);
                    j = child;
                }
            }
            return smallest;
        }

        private void swap(int i, int j) {
            int tmp = data.get(i);
            data.set(i, data.get(j));
            data.set(j, tmp);
        }
    }
}
