"""Exercises 9 and 10 (read the code). Each piece of code below was written by an AI assistant together with a
claim about how well it was tested.  The claims sound reasonable.  The code is NOT correct: find an input on which it
fails, say which line is wrong and what happens, fix it, and say what test would have caught it.
"""


class RingQueue:
    """A FIFO queue of fixed capacity stored in a circular array.

    Tested: enqueue three items into a RingQueue(3), dequeue them in order (they came out as 1, 2, 3), enqueue again.
    All of it works, and every operation takes constant time.
    """

    def __init__(self, capacity):
        self._data = [None] * capacity
        self._front = 0
        self._size = 0

    def __len__(self):
        return self._size

    def enqueue(self, x):
        if self._size == len(self._data):
            raise OverflowError("queue is full")
        self._data[(self._front + self._size) % len(self._data)] = x
        self._size += 1

    def dequeue(self):
        if self._size == 0:
            raise IndexError("queue is empty")
        x = self._data[self._front]
        self._data[self._front] = None
        self._front += 1
        self._size -= 1
        return x


def is_matched(expr):
    """Return True if the brackets ( ) [ ] { } in expr are properly nested, ignoring all other characters.

    Tested on "([]{})", "(a[b]c)" and "[(])": True, True, False, as expected.
    """
    stack = []
    for ch in expr:
        if ch in "([{":
            stack.append(ch)
        elif ch in ")]}":
            top = stack.pop()
            if "([{".index(top) != ")]}".index(ch):
                return False
    return True
