"""Exercise 8 (implementation): evaluate a postfix (reverse Polish) expression with a stack.

evaluate(tokens) takes a list of strings such as ["5", "1", "2", "+", "4", "*", "+", "3", "-"] (that is
5 + (1 + 2) * 4 - 3) and returns the value as an int.  Read the tokens left to right: a number is pushed; an operator
pops the right operand first and then the left operand, and pushes the result.  Use a plain Python list as the stack.

Milestone 1: integers (possibly negative, like "-3") and the operators + - *.  Mind the operand order for "-".
Milestone 2: "/" divides and TRUNCATES TOWARD ZERO, as Java and C do: -7 / 2 is -3 (Python's // would give -4).
Milestone 3: malformed input.  An operator with fewer than two operands on the stack, or more than one value left at the
             end, or an empty list, or a token that is neither an integer nor an operator, raises ValueError.
             Division by zero raises ZeroDivisionError.

Run:  pytest test_ex3_postfix.py
"""


def evaluate(tokens):
    raise NotImplementedError
