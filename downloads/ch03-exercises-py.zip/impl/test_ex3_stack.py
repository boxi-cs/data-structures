import random

import pytest
from ex3_stack import GrowStack


def test_m1_lifo_order():
    s = GrowStack()
    for x in (3, 7, 1):
        s.push(x)
    assert len(s) == 3 and s.top() == 1
    assert [s.pop(), s.pop(), s.pop()] == [1, 7, 3]
    assert s.is_empty() and len(s) == 0


def test_m1_top_does_not_remove():
    s = GrowStack()
    s.push(5)
    assert s.top() == 5 and s.top() == 5 and len(s) == 1


def test_m2_empty_stack_raises():
    s = GrowStack()
    with pytest.raises(IndexError):
        s.pop()
    with pytest.raises(IndexError):
        s.top()
    s.push(1)
    s.pop()
    with pytest.raises(IndexError):
        s.pop()


def test_m2_pop_clears_the_slot():
    s = GrowStack()
    s.push("a")
    s.push("b")
    assert s.pop() == "b"
    assert s._data[1] is None
    assert s._data[0] == "a"


def test_m3_capacity_sequence():
    s = GrowStack()
    caps = []
    for i in range(9):
        s.push(i)
        caps.append(s.capacity)
    assert caps == [2, 2, 4, 4, 8, 8, 8, 8, 16]


def test_m3_exact_copies():
    # the resizes copy 2, 4, 8, ... items; if the final capacity is C the total is C - 2
    s = GrowStack()
    for n in range(1, 300):
        s.push(n)
        assert s.copies == s.capacity - 2


def test_m3_copies_below_2n():
    for n in (1, 2, 3, 10, 100, 1000, 12345):
        s = GrowStack()
        for i in range(n):
            s.push(i)
        assert s.copies < 2 * n


def test_m3_values_survive_growth():
    s = GrowStack()
    for i in range(1000):
        s.push(i)
    assert [s.pop() for _ in range(1000)] == list(range(999, -1, -1))


def test_m3_random_operations_match_a_list():
    rng = random.Random(3)
    s, ref = GrowStack(), []
    for _ in range(5000):
        if ref and rng.random() < 0.45:
            assert s.pop() == ref.pop()
        else:
            x = rng.randrange(100)
            s.push(x)
            ref.append(x)
        assert len(s) == len(ref)
        if ref:
            assert s.top() == ref[-1]
