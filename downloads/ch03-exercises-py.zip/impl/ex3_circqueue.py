"""Exercise 7 (implementation): a queue in a circular array.

The queue keeps its items in the list `_data`, the index of the first item in `_front` and the number of items in
`_size`.  The items occupy the cells (front + k) mod capacity for k = 0 .. size - 1.

Milestone 1: enqueue, dequeue and first (FIFO order) while the list never fills up; dequeue and first raise IndexError
             on an empty queue; dequeue puts None back in the freed cell.
Milestone 2: wrap-around.  The next free cell is (front + size) mod capacity, and dequeue moves front to
             (front + 1) mod capacity.  No item is ever moved.
Milestone 3: when the list is full, enqueue first allocates a list of twice the length and copies the items over IN QUEUE
             ORDER starting at cell 0 (so the front becomes 0), then stores the new item.

describe() is given: the tests compare it with the picture from the video.

Run:  pytest test_ex3_circqueue.py
"""


class CircQueue:
    def __init__(self, capacity=4):
        self._data = [None] * capacity
        self._size = 0
        self._front = 0

    def __len__(self):
        return self._size

    def is_empty(self):
        return self._size == 0

    def first(self):
        raise NotImplementedError

    def dequeue(self):
        raise NotImplementedError

    def enqueue(self, x):
        raise NotImplementedError

    def describe(self):
        return f"data={self._data} front={self._front} size={self._size}"
