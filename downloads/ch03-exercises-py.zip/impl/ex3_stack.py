"""Exercise 6 (implementation): an array-based stack that grows by doubling.

The stack keeps its items in the list `_data` (capacity = len(_data), starting at 2) and the number of items in
`_size`; the top item lives at index _size - 1.  push(x) first makes room if the list is full: it allocates a list of
twice the length and copies the old items over ONE AT A TIME, adding 1 to `copies` for every item copied.  Then it
stores x.

Milestone 1: push, top and pop (LIFO order), while the list never fills up.
Milestone 2: pop and top on an empty stack raise IndexError; pop puts None back in the freed slot, so the
             stack does not keep an object alive that it no longer contains.
Milestone 3: growth by doubling with the copy counter; the tests check the capacities and the exact number of copies.

Run:  pytest test_ex3_stack.py
"""


class GrowStack:
    def __init__(self):
        self._data = [None] * 2
        self._size = 0
        self.copies = 0  # total number of item copies made by all resizes so far

    @property
    def capacity(self):
        return len(self._data)

    def __len__(self):
        return self._size

    def is_empty(self):
        return self._size == 0

    def push(self, x):
        raise NotImplementedError

    def top(self):
        raise NotImplementedError

    def pop(self):
        raise NotImplementedError
