import pytest
from ex3_postfix import evaluate


def ev(expr):
    return evaluate(expr.split())


def test_m1_numbers_and_plus_times():
    assert ev("3 4 + 2 *") == 14
    assert ev("42") == 42
    assert ev("2 3 4 * +") == 14


def test_m1_minus_operand_order():
    assert ev("10 3 -") == 7
    assert ev("3 10 -") == -7
    assert ev("5 1 2 + 4 * + 3 -") == 14


def test_m1_negative_literals():
    assert ev("-3 4 +") == 1
    assert ev("-3 -4 *") == 12


def test_m2_division_truncates_toward_zero():
    assert ev("7 2 /") == 3
    assert ev("-7 2 /") == -3
    assert ev("7 -2 /") == -3
    assert ev("-7 -2 /") == 3
    assert ev("1 2 /") == 0
    assert ev("-1 2 /") == 0


def test_m2_division_operand_order():
    assert ev("100 5 /") == 20
    assert ev("5 100 /") == 0


def test_m3_malformed_input_raises_value_error():
    for bad in ["", "+", "1 +", "1 2", "1 2 3 +", "1 x +", "1 2 ^"]:
        with pytest.raises(ValueError):
            ev(bad)


def test_m3_division_by_zero():
    with pytest.raises(ZeroDivisionError):
        ev("1 0 /")
    with pytest.raises(ZeroDivisionError):
        ev("5 2 2 - /")


def test_m3_long_expression():
    # 1 + 2 + ... + 100 written in postfix
    expr = ["1"] + [t for k in range(2, 101) for t in (str(k), "+")]
    assert evaluate(expr) == 5050
