import random
from collections import deque

import pytest
from ex3_circqueue import CircQueue


def test_m1_fifo_order():
    q = CircQueue()
    for x in "ABC":
        q.enqueue(x)
    assert len(q) == 3 and q.first() == "A"
    assert [q.dequeue(), q.dequeue(), q.dequeue()] == ["A", "B", "C"]
    assert q.is_empty()


def test_m1_empty_queue_raises():
    q = CircQueue()
    with pytest.raises(IndexError):
        q.dequeue()
    with pytest.raises(IndexError):
        q.first()
    q.enqueue(1)
    q.dequeue()
    with pytest.raises(IndexError):
        q.dequeue()


def test_m1_dequeue_clears_the_cell():
    q = CircQueue()
    q.enqueue("A")
    q.enqueue("B")
    assert q.dequeue() == "A"
    assert q.describe() == "data=[None, 'B', None, None] front=1 size=1"


def test_m2_wrap_around_as_in_the_video():
    q = CircQueue()
    for x in "ABCD":
        q.enqueue(x)
    assert q.describe() == "data=['A', 'B', 'C', 'D'] front=0 size=4"
    assert (q.dequeue(), q.dequeue()) == ("A", "B")
    assert q.describe() == "data=[None, None, 'C', 'D'] front=2 size=2"
    q.enqueue("E")
    q.enqueue("F")
    assert q.describe() == "data=['E', 'F', 'C', 'D'] front=2 size=4"


def test_m2_front_wraps_after_a_full_lap():
    q = CircQueue(3)
    for lap in range(10):
        q.enqueue(lap)
        assert q.dequeue() == lap
    assert q._front == 10 % 3 and len(q._data) == 3


def test_m3_resize_straightens_the_circle():
    q = CircQueue()
    for x in "ABCD":
        q.enqueue(x)
    q.dequeue()
    q.dequeue()
    q.enqueue("E")
    q.enqueue("F")
    q.enqueue("G")
    assert q.describe() == "data=['C', 'D', 'E', 'F', 'G', None, None, None] front=0 size=5"
    assert [q.dequeue() for _ in range(5)] == ["C", "D", "E", "F", "G"]


def test_m3_capacity_only_changes_when_full():
    q = CircQueue(4)
    for i in range(1000):
        q.enqueue(i)
        q.enqueue(i)
        q.dequeue()
        q.dequeue()
        assert len(q._data) == 4


@pytest.mark.parametrize("capacity", [1, 2, 4, 5])
def test_m3_random_operations_match_deque(capacity):
    rng = random.Random(capacity)
    q, ref = CircQueue(capacity), deque()
    for step in range(20000):
        if ref and rng.random() < 0.48:
            assert q.dequeue() == ref.popleft()
        else:
            q.enqueue(step)
            ref.append(step)
        assert len(q) == len(ref)
        if ref:
            assert q.first() == ref[0]
