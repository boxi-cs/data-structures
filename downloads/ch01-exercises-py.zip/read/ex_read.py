"""Exercises 9 and 10 (read the code). Each function below came with an AI assistant's complexity claim.
The code is correct; the claim is wrong. Say what is wrong and what the real complexity is.
"""


def has_duplicate(items):
    """Return True if some value appears twice in items.

    Complexity: O(n). The function makes a single pass over the list, remembers the items it has
    seen, and stops at the first repeat, exactly like the set-based version.
    """
    seen = []
    for x in items:
        if x in seen:
            return True
        seen.append(x)
    return False


def reversed_copy(items):
    """Return a new list with the items of `items` in reverse order.

    Complexity: O(n). One loop over the input, and list.insert is a constant-time operation, so the
    total is linear.
    """
    out = []
    for x in items:
        out.insert(0, x)
    return out
