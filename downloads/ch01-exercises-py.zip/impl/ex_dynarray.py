"""Exercise 7 (implementation): a dynamic array with a growth policy and a copy counter.

The array starts with capacity 1 and size 0.  append(x) first makes room if size == capacity:
it asks the growth policy for the new capacity, allocates a bigger list and copies the old elements
over ONE AT A TIME, adding 1 to `copies` for every element copied.  Then it stores x.

Milestone 1: append, so that values are kept and capacity grows.
Milestone 2: double (capacity -> 2 * capacity).
Milestone 3: plus_one (capacity -> capacity + 1), the policy that makes appending slow.
Then read the tests: they check the totals your analysis in Exercise 3 predicts.

Run:  pytest test_ex_dynarray.py
"""


def double(capacity):
    raise NotImplementedError


def plus_one(capacity):
    raise NotImplementedError


class DynArray:
    def __init__(self, growth):
        self.growth = growth
        self.capacity = 1
        self.size = 0
        self.copies = 0  # total number of element copies made by all resizes so far
        self._data = [None] * self.capacity

    def append(self, x):
        raise NotImplementedError

    def __len__(self):
        return self.size

    def __getitem__(self, i):
        if not 0 <= i < self.size:
            raise IndexError(i)
        return self._data[i]
