import ex_power


def test_values():
    for x in (0, 1, 2, 3, 10, -2):
        for n in range(0, 40):
            assert ex_power.fast_power(x, n) == x**n


def test_big_integers():
    assert ex_power.fast_power(7, 1000) == 7**1000


def test_invariant_holds_every_time_the_hook_is_called():
    seen = []

    def hook(result, base, e):
        seen.append((result, base, e))

    for x, n in ((3, 0), (3, 1), (2, 10), (5, 37), (7, 1000)):
        seen.clear()
        ex_power.fast_power(x, n, hook)
        assert seen, "the hook was never called"
        for result, base, e in seen:
            assert result * base**e == x**n
        assert seen[-1][2] == 0, "the last call must see e == 0"


def test_number_of_hook_calls_is_logarithmic():
    for n in (0, 1, 2, 3, 8, 1000, 10**6):
        calls = []
        ex_power.fast_power(2, n, lambda *args: calls.append(args))
        assert len(calls) == n.bit_length() + 1
