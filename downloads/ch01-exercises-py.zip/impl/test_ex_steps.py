from itertools import combinations, combinations_with_replacement

import ex_steps


def test_count_pairs_small():
    assert [ex_steps.count_pairs(n) for n in range(6)] == [0, 0, 1, 3, 6, 10]


def test_count_pairs_matches_combinations():
    for n in range(30):
        assert ex_steps.count_pairs(n) == sum(1 for _ in combinations(range(n), 2))


def test_pairs_formula_matches_count():
    for n in range(80):
        assert ex_steps.pairs_formula(n) == ex_steps.count_pairs(n)


def test_halving_small():
    assert [ex_steps.count_halving(n) for n in (1, 2, 3, 4, 7, 8, 1000)] == [0, 1, 1, 2, 2, 3, 9]


def test_halving_formula_matches_count():
    for n in list(range(1, 300)) + [2**20, 2**20 + 1, 10**9]:
        assert ex_steps.halving_formula(n) == ex_steps.count_halving(n)


def test_count_triple_matches_combinations_with_replacement():
    for n in range(14):
        assert ex_steps.count_triple(n) == sum(1 for _ in combinations_with_replacement(range(n), 3))


def test_triple_formula_matches_count():
    for n in range(40):
        assert ex_steps.triple_formula(n) == ex_steps.count_triple(n)
