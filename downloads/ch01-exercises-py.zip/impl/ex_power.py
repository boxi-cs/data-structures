"""Exercise 8 (implementation): fast exponentiation with a checked loop invariant.

Compute x**n by repeated squaring.  Your loop must keep this invariant true at the top of every
iteration (it is the one you designed in Exercise 5):

        result * base ** e == x ** n

`on_iteration(result, base, e)` is a hook for the tests: call it, if it is not None, every time the
loop condition is about to be evaluated -- once before the first iteration, once after every iteration,
so (number of iterations + 1) times in total.

Milestone 1: initialise result, base, e so the invariant holds before the loop.
Milestone 2: the loop body keeps it true (think about e even and e odd separately).
Milestone 3: stop when e == 0 and return result.

Run:  pytest test_ex_power.py
"""


def fast_power(x, n, on_iteration=None):
    """x ** n for an integer n >= 0 using O(log n) multiplications.  Do not call ** or pow()."""
    raise NotImplementedError
