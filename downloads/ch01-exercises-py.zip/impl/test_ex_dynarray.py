import ex_dynarray
from ex_dynarray import DynArray


def filled(growth, n):
    a = DynArray(growth)
    for i in range(n):
        a.append(i)
    return a


def test_policies():
    assert [ex_dynarray.double(c) for c in (1, 2, 4, 10)] == [2, 4, 8, 20]
    assert [ex_dynarray.plus_one(c) for c in (1, 2, 4, 10)] == [2, 3, 5, 11]


def test_values_are_kept():
    for growth in (ex_dynarray.double, ex_dynarray.plus_one):
        a = filled(growth, 100)
        assert len(a) == 100
        assert [a[i] for i in range(100)] == list(range(100))


def test_capacity_sequence_with_doubling():
    a = DynArray(ex_dynarray.double)
    caps = []
    for i in range(9):
        a.append(i)
        caps.append(a.capacity)
    assert caps == [1, 2, 4, 4, 8, 8, 8, 8, 16]


def test_copies_with_doubling_are_less_than_2n():
    for n in (1, 2, 3, 5, 10, 100, 1000, 12345):
        assert filled(ex_dynarray.double, n).copies < 2 * n


def test_exact_copies_with_doubling():
    # resizes happen at append number 2^j + 1 and copy 2^j elements
    assert filled(ex_dynarray.double, 1).copies == 0
    assert filled(ex_dynarray.double, 2).copies == 1
    assert filled(ex_dynarray.double, 3).copies == 1 + 2
    assert filled(ex_dynarray.double, 5).copies == 1 + 2 + 4
    assert filled(ex_dynarray.double, 1025).copies == 2**11 - 1


def test_copies_with_plus_one_are_quadratic():
    for n in (1, 2, 10, 100, 500):
        assert filled(ex_dynarray.plus_one, n).copies == n * (n - 1) // 2


def test_amortized_cost_per_append_is_at_most_3_with_doubling():
    n = 10_000
    a = filled(ex_dynarray.double, n)
    assert (n + a.copies) / n <= 3
