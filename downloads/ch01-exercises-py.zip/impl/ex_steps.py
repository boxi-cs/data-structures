"""Exercise 6 (implementation): count the steps of a loop, then predict the count with a formula.

Milestone 1: count_pairs      -- run the two nested loops and count the inner iterations.
Milestone 2: pairs_formula    -- the closed form you derived in the lecture, n(n-1)/2.
Milestone 3: count_halving / halving_formula -- a loop whose variable halves each time.
Milestone 4: count_triple / triple_formula   -- three nested loops with i <= j <= k.

Run:  pytest test_ex_steps.py
"""


def count_pairs(n):
    """How many times does the inner body run in
        for i in range(n):
            for j in range(i + 1, n):
                ...
    Write the loops and count; do not use a formula here."""
    raise NotImplementedError


def pairs_formula(n):
    """The closed form for count_pairs(n), as an integer."""
    raise NotImplementedError


def count_halving(n):
    """How many times does the body run in
        while n > 1:
            n = n // 2
    for n >= 1?  Write the loop and count."""
    raise NotImplementedError


def halving_formula(n):
    """The closed form for count_halving(n), n >= 1: floor(log2 n).  Do not use floating point."""
    raise NotImplementedError


def count_triple(n):
    """How many times does the innermost body run in
        for i in range(n):
            for j in range(i, n):
                for k in range(j, n):
                    ...
    Write the loops and count."""
    raise NotImplementedError


def triple_formula(n):
    """The closed form for count_triple(n)."""
    raise NotImplementedError
