/**
 * Exercise 9 (read the code). An AI assistant wrote this method for a fixed-capacity int array.
 * Its Javadoc is exactly what we agreed on in the chapter; its test passed. The code has a bug.
 * Find a SMALL input that shows it, say what goes wrong, and fix it.
 */
public final class ExReadShift {
    private ExReadShift() {}

    /**
     * Inserts value at position index of the first size slots of a (the array length is the capacity).
     * The items from index on move one slot to the right, last one first, so nothing is overwritten before it
     * has moved. Throws IllegalStateException if the array is full and IndexOutOfBoundsException if index is
     * not in 0..size. The caller adds 1 to its own size afterwards. Cost: size - index moves.
     */
    public static void insert(int[] a, int size, int index, int value) {
        if (size == a.length) {
            throw new IllegalStateException("array is full");
        }
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("index out of range");
        }
        for (int k = size - 1; k > index; k--) {
            a[k] = a[k - 1];
        }
        a[index] = value;
    }

    // The AI's test, which passes:
    //     int[] a = {10, 20, 30, 0, 0};
    //     insert(a, 3, 2, 99);
    //     assert a[0] == 10 && a[1] == 20 && a[2] == 99;
}
