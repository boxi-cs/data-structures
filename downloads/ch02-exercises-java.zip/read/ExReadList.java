import java.util.ArrayList;
import java.util.List;

/**
 * Exercise 10 (read the code). An AI assistant wrote this singly linked list of ints. Its toList helper and its
 * two tests pass. There are TWO bugs, both about updating references. For each: find a short sequence of calls
 * that shows it, say exactly which nodes are lost or which reference is stale, and fix it.
 */
public final class ExReadList {
    public static final class Node {
        public int value;
        public Node next;

        public Node(int value) {
            this.value = value;
        }
    }

    public Node head = null;
    public Node tail = null;
    public int size = 0;

    public void addFirst(int value) {
        Node node = new Node(value);
        head = node;
        node.next = head.next;
        if (tail == null) {
            tail = node;
        }
        size++;
    }

    public void addLast(int value) {
        Node node = new Node(value);
        if (tail == null) {
            head = node;
        } else {
            tail.next = node;
        }
        tail = node;
        size++;
    }

    public void insertAfter(Node node, int value) {
        Node created = new Node(value);
        created.next = node.next;
        node.next = created;
        size++;
    }

    public List<Integer> toList() {
        List<Integer> out = new ArrayList<>();
        for (Node n = head; n != null; n = n.next) {
            out.add(n.value);
        }
        return out;
    }

    // The AI's tests, which pass:
    //   empty list: addFirst(1); addLast(2);                 toList() == [1, 2]
    //   addLast(1); addLast(2); addLast(3); insertAfter(head, 9);   toList() == [1, 9, 2, 3]
}
