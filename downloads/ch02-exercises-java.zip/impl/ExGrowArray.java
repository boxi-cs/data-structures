/**
 * Exercise 7 (implementation): a dynamic int array with insert, pop and a SHRINKING policy.
 *
 * The array starts with capacity 1 and size 0. copies() counts every element copied by a resize (one per
 * element), shifts() every single-item move made by insert.
 *
 * Milestone 1: resize(newCapacity): allocate an array of that length, copy the size items over ONE AT A TIME
 *              (copies += 1 for each), and use the new array.
 * Milestone 2: append(value): if the array is full, double the capacity first.
 * Milestone 3: insert(index, value), 0 <= index <= size: double if full, then shift the items from index on one
 *              slot to the right, last one first (shifts += 1 for each), then write.
 * Milestone 4: pop(): remove and return the last item; NoSuchElementException if empty. Afterwards, if
 *              capacity > 1 and 4 * size <= capacity, HALVE the capacity (a resize). Shrinking only when the
 *              array is a QUARTER full, not half full, is what keeps pop from undoing the work of append.
 */
import java.util.NoSuchElementException;

public final class ExGrowArray {
    private int[] items = new int[1]; // capacity 1
    private int size = 0;
    private long copies = 0;
    private long shifts = 0;

    public int size() {
        return size;
    }

    public int capacity() {
        return items.length;
    }

    public long copies() {
        return copies;
    }

    public long shifts() {
        return shifts;
    }

    public int get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException(index);
        }
        return items[index];
    }

    private void resize(int newCapacity) {
        throw new UnsupportedOperationException("not implemented");
    }

    public void append(int value) {
        throw new UnsupportedOperationException("not implemented");
    }

    public void insert(int index, int value) {
        throw new UnsupportedOperationException("not implemented");
    }

    public int pop() {
        throw new UnsupportedOperationException("not implemented");
    }
}
