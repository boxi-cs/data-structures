import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * Exercise 8, part B (implementation): a doubly linked list of ints with a header and a trailer sentinel
 * (the real items sit between them).
 *
 * Milestone 4: insertBetween(value, pred, succ) (returns the new node), addLast(value) (returns the new node),
 *              deleteNode(node) (returns its value), removeLast() (returns the value, NoSuchElementException if empty).
 *              Every operation is a fixed number of pointer changes: no loop over the list.
 *
 * toList() and check() are given; the tests call check() after every operation.
 */
public final class ExDoubly {
    public static final class DNode {
        public int value;
        public DNode prev;
        public DNode next;

        public DNode(int value, DNode prev, DNode next) {
            this.value = value;
            this.prev = prev;
            this.next = next;
        }
    }

    public final DNode header = new DNode(0, null, null);
    public final DNode trailer = new DNode(0, null, null);
    public int size = 0;

    public ExDoubly() {
        header.next = trailer;
        trailer.prev = header;
    }

    public List<Integer> toList() {
        List<Integer> out = new ArrayList<>();
        for (DNode node = header.next; node != trailer && out.size() <= size; node = node.next) {
            out.add(node.value);
        }
        return out;
    }

    public void check() {
        if (header.prev != null || trailer.next != null) {
            throw new AssertionError("sentinels must not point outwards");
        }
        int count = 0;
        for (DNode node = header; node != trailer; node = node.next) {
            if (node.next == null || node.next.prev != node) {
                throw new AssertionError("next/prev pointers disagree");
            }
            count++;
            if (count > size + 1) {
                throw new AssertionError("more nodes reachable than size (or a cycle)");
            }
        }
        if (count - 1 != size) {
            throw new AssertionError("size does not match the number of nodes between the sentinels");
        }
    }

    public DNode insertBetween(int value, DNode pred, DNode succ) {
        throw new UnsupportedOperationException("not implemented");
    }

    public DNode addLast(int value) {
        throw new UnsupportedOperationException("not implemented");
    }

    public int deleteNode(DNode node) {
        throw new UnsupportedOperationException("not implemented");
    }

    public int removeLast() {
        throw new UnsupportedOperationException("not implemented");
    }
}
