import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Random;
import org.junit.jupiter.api.Test;

class ExGrowArrayTest {
    static ExGrowArray appended(int n) {
        ExGrowArray a = new ExGrowArray();
        for (int i = 0; i < n; i++) {
            a.append(i);
        }
        return a;
    }

    @Test
    void capacitiesWhileAppending() {
        ExGrowArray a = new ExGrowArray();
        int[] expected = {1, 2, 4, 4, 8, 8, 8, 8, 16};
        for (int i = 0; i < 9; i++) {
            a.append(i);
            assertEquals(expected[i], a.capacity());
        }
        assertEquals(15, a.copies());
        for (int i = 0; i < 9; i++) {
            assertEquals(i, a.get(i));
        }
    }

    @Test
    void copiesOfAppending17Items() {
        ExGrowArray a = appended(17);
        assertEquals(32, a.capacity());
        assertEquals(31, a.copies());
    }

    @Test
    void insertInTheMiddleShiftsTheTail() {
        ExGrowArray a = new ExGrowArray();
        for (int v : new int[] {10, 20, 30, 40, 50}) {
            a.append(v);
        }
        a.insert(2, 99);
        int[] expected = {10, 20, 99, 30, 40, 50};
        for (int i = 0; i < 6; i++) {
            assertEquals(expected[i], a.get(i));
        }
        assertEquals(6, a.size());
        assertEquals(3, a.shifts());
    }

    @Test
    void insertingAtTheFrontCostsNSquaredOverTwoShifts() {
        ExGrowArray a = new ExGrowArray();
        for (int i = 0; i < 100; i++) {
            a.insert(0, i);
        }
        for (int i = 0; i < 100; i++) {
            assertEquals(99 - i, a.get(i));
        }
        assertEquals(100L * 99 / 2, a.shifts()); // 0 + 1 + ... + 99
        assertEquals(127, a.copies()); // the same doubling copies as appending: 1 + 2 + ... + 64
    }

    @Test
    void insertIndexErrors() {
        ExGrowArray a = appended(3);
        for (int bad : new int[] {4, -1}) {
            assertThrows(IndexOutOfBoundsException.class, () -> a.insert(bad, 99));
        }
        a.insert(3, 99); // index == size is an append
        assertEquals(99, a.get(3));
    }

    @Test
    void popReturnsTheLastItemAndShrinksAtAQuarter() {
        ExGrowArray a = appended(9);
        int[] caps = {16, 16, 16, 16, 8, 8, 4, 2, 1};
        for (int k = 0; k < 9; k++) {
            assertEquals(8 - k, a.pop());
            assertEquals(caps[k], a.capacity());
        }
        assertEquals(15 + 4 + 2 + 1, a.copies());
    }

    @Test
    void popFromAnEmptyArray() {
        assertThrows(NoSuchElementException.class, () -> new ExGrowArray().pop());
    }

    @Test
    void alternatingAtTheGrowthBoundaryDoesNotThrash() {
        ExGrowArray a = appended(8); // full: capacity 8
        long before = a.copies();
        for (int k = 0; k < 1000; k++) {
            a.append(0);
            a.pop();
        }
        assertTrue(a.copies() - before <= 8); // one growth, then no further copying
    }

    @Test
    void capacityInvariantsUnderRandomOperations() {
        Random rng = new Random(7);
        ExGrowArray a = new ExGrowArray();
        List<Integer> ref = new ArrayList<>();
        for (int step = 0; step < 3000; step++) {
            double r = rng.nextDouble();
            if (!ref.isEmpty() && r < 0.45) {
                assertEquals(ref.remove(ref.size() - 1), a.pop());
            } else if (r < 0.75) {
                a.append(step);
                ref.add(step);
            } else {
                int i = rng.nextInt(ref.size() + 1);
                a.insert(i, step);
                ref.add(i, step);
            }
            assertEquals(ref.size(), a.size());
            assertTrue(a.size() <= a.capacity());
            assertTrue(a.capacity() == 1 || a.capacity() < 4 * a.size()); // never more than 4 slots per item
        }
        for (int i = 0; i < ref.size(); i++) {
            assertEquals(ref.get(i), a.get(i));
        }
    }
}
