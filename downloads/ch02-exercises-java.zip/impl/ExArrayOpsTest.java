import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.junit.jupiter.api.Test;

class ExArrayOpsTest {
    /** The array holding 10, 20, ... (n items) in capacity 8, built by appending (no shifts). */
    static ExArrayOps tens(int n) {
        ExArrayOps a = new ExArrayOps(8);
        for (int i = 0; i < n; i++) {
            a.insert(i, 10 * (i + 1));
        }
        return a;
    }

    @Test
    void get() {
        ExArrayOps a = tens(5);
        for (int i = 0; i < 5; i++) {
            assertEquals(10 * (i + 1), a.get(i));
        }
        for (int bad : new int[] {5, -1, 8}) {
            assertThrows(IndexOutOfBoundsException.class, () -> a.get(bad));
        }
    }

    @Test
    void insertInTheMiddleShiftsTheTail() {
        ExArrayOps a = tens(5);
        assertEquals(0, a.shifts()); // appending moves nothing
        a.insert(2, 99);
        assertArrayEquals(new int[] {10, 20, 99, 30, 40, 50, 0, 0}, a.storage());
        assertEquals(6, a.size());
        assertEquals(3, a.shifts()); // 50, then 40, then 30
    }

    @Test
    void insertAtTheFrontAndAtTheEnd() {
        ExArrayOps front = tens(5);
        front.insert(0, 99);
        assertArrayEquals(new int[] {99, 10, 20, 30, 40, 50, 0, 0}, front.storage());
        assertEquals(5, front.shifts()); // every item moves
        ExArrayOps end = tens(5);
        end.insert(5, 99);
        assertArrayEquals(new int[] {10, 20, 30, 40, 50, 99, 0, 0}, end.storage());
        assertEquals(0, end.shifts()); // nothing moves
    }

    @Test
    void insertErrorsLeaveTheArrayUnchanged() {
        ExArrayOps full = tens(8);
        assertThrows(IllegalStateException.class, () -> full.insert(3, 99));
        assertArrayEquals(new int[] {10, 20, 30, 40, 50, 60, 70, 80}, full.storage());
        assertEquals(8, full.size());
        assertEquals(0, full.shifts());
        ExArrayOps a = tens(5);
        for (int bad : new int[] {6, -1}) {
            assertThrows(IndexOutOfBoundsException.class, () -> a.insert(bad, 99));
        }
        assertArrayEquals(new int[] {10, 20, 30, 40, 50, 0, 0, 0}, a.storage());
        assertEquals(5, a.size());
        assertEquals(0, a.shifts());
    }

    @Test
    void removeClosesTheGap() {
        ExArrayOps a = tens(5);
        a.insert(2, 99);
        assertEquals(10, a.remove(0));
        assertArrayEquals(new int[] {20, 99, 30, 40, 50, 0, 0, 0}, a.storage());
        assertEquals(5, a.size());
        assertEquals(3 + 5, a.shifts()); // the insert moved 3, the remove moves the 5 items after position 0
    }

    @Test
    void removeTheLastItemMovesNothingAndClearsItsSlot() {
        ExArrayOps a = tens(5);
        assertEquals(50, a.remove(4));
        assertEquals(0, a.storage()[4]);
        assertEquals(4, a.size());
        assertEquals(0, a.shifts());
    }

    @Test
    void removeErrors() {
        ExArrayOps a = tens(5);
        assertThrows(IndexOutOfBoundsException.class, () -> a.remove(5));
        assertThrows(IndexOutOfBoundsException.class, () -> new ExArrayOps(3).remove(0));
    }

    @Test
    void randomOperationsMatchAList() {
        Random rng = new Random(1);
        ExArrayOps a = new ExArrayOps(50);
        List<Integer> ref = new ArrayList<>();
        long shifts = 0;
        for (int step = 0; step < 2000; step++) {
            if (!ref.isEmpty() && (ref.size() == 50 || rng.nextDouble() < 0.5)) {
                int i = rng.nextInt(ref.size());
                assertEquals(ref.remove(i), a.remove(i));
                shifts += ref.size() - i;
            } else {
                int i = rng.nextInt(ref.size() + 1);
                a.insert(i, step + 1);
                shifts += ref.size() - i;
                ref.add(i, step + 1);
            }
            int[] expected = new int[50];
            for (int k = 0; k < ref.size(); k++) {
                expected[k] = ref.get(k);
            }
            assertArrayEquals(expected, a.storage());
            assertEquals(ref.size(), a.size());
            assertEquals(shifts, a.shifts());
        }
    }
}
