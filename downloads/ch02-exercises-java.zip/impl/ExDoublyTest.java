import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Random;
import org.junit.jupiter.api.Test;

class ExDoublyTest {
    static ExDoubly of(int... values) {
        ExDoubly lst = new ExDoubly();
        for (int v : values) {
            lst.addLast(v);
            lst.check();
        }
        return lst;
    }

    static List<Integer> list(int... values) {
        List<Integer> out = new ArrayList<>();
        for (int v : values) {
            out.add(v);
        }
        return out;
    }

    @Test
    void addLastAndInsertBetween() {
        ExDoubly lst = of(1, 3);
        assertEquals(list(1, 3), lst.toList());
        ExDoubly.DNode first = lst.header.next;
        ExDoubly.DNode node = lst.insertBetween(2, first, first.next);
        lst.check();
        assertEquals(2, node.value);
        assertEquals(list(1, 2, 3), lst.toList());
        assertEquals(3, lst.size);
        lst.insertBetween(0, lst.header, lst.header.next);
        lst.check();
        assertEquals(list(0, 1, 2, 3), lst.toList());
    }

    @Test
    void deleteNode() {
        ExDoubly lst = new ExDoubly();
        ExDoubly.DNode[] nodes = new ExDoubly.DNode[4];
        for (int i = 0; i < 4; i++) {
            nodes[i] = lst.addLast(10 * (i + 1));
        }
        assertEquals(30, lst.deleteNode(nodes[2]));
        lst.check();
        assertEquals(list(10, 20, 40), lst.toList());
        assertEquals(10, lst.deleteNode(nodes[0]));
        lst.check();
        assertEquals(40, lst.deleteNode(nodes[3]));
        lst.check();
        assertEquals(list(20), lst.toList());
        assertEquals(20, lst.deleteNode(nodes[1]));
        lst.check();
        assertEquals(list(), lst.toList());
        assertEquals(0, lst.size);
    }

    @Test
    void removeLast() {
        ExDoubly lst = of(1, 2, 3);
        assertEquals(3, lst.removeLast());
        assertEquals(2, lst.removeLast());
        assertEquals(1, lst.removeLast());
        lst.check();
        assertThrows(NoSuchElementException.class, lst::removeLast);
    }

    @Test
    void randomOperationsMatchAList() {
        Random rng = new Random(5);
        ExDoubly lst = new ExDoubly();
        List<ExDoubly.DNode> nodes = new ArrayList<>();
        List<Integer> ref = new ArrayList<>();
        for (int step = 0; step < 1500; step++) {
            double r = rng.nextDouble();
            if (r < 0.5 || ref.isEmpty()) {
                nodes.add(lst.addLast(step));
                ref.add(step);
            } else if (r < 0.75) {
                assertEquals(ref.remove(ref.size() - 1), lst.removeLast());
                nodes.remove(nodes.size() - 1);
            } else {
                int i = rng.nextInt(ref.size());
                assertEquals(ref.remove(i), lst.deleteNode(nodes.remove(i)));
            }
            lst.check();
            assertEquals(ref, lst.toList());
        }
    }
}
