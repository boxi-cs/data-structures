/**
 * Exercise 6 (implementation): a fixed-capacity int array whose insert and remove shift items.
 *
 * State: the first size() slots of the storage hold the items, the others hold 0. shifts() counts every
 * single-item move made so far: one a[k] = a[j] between two used slots is one shift. Writing the new item and
 * clearing a slot are not shifts.
 *
 * Milestone 1: get(index).
 * Milestone 2: insert(index, value): move the items from index on one slot to the right, LAST ONE FIRST, then write.
 * Milestone 3: remove(index): move the later items one slot to the left, clear the last used slot, return the value.
 * Milestone 4: make shifts() come out right (insert at i moves size - i items, remove at i moves size - 1 - i).
 *
 * Errors: IllegalStateException when inserting into a full array; IndexOutOfBoundsException for an index out of
 * range (insert: 0..size, get and remove: 0..size-1).
 */
public final class ExArrayOps {
    private final int[] items;
    private int size = 0;
    private long shifts = 0;

    public ExArrayOps(int capacity) {
        items = new int[capacity];
    }

    public int get(int index) {
        throw new UnsupportedOperationException("not implemented");
    }

    public void insert(int index, int value) {
        throw new UnsupportedOperationException("not implemented");
    }

    public int remove(int index) {
        throw new UnsupportedOperationException("not implemented");
    }

    public int size() {
        return size;
    }

    public long shifts() {
        return shifts;
    }

    /** A copy of the whole storage, capacity slots long (unused slots are 0). */
    public int[] storage() {
        return items.clone();
    }
}
