import java.util.ArrayList;
import java.util.List;

/**
 * Exercise 8, part A (implementation): a singly linked list of ints, with the pointer updates in the right order.
 *
 * Milestone 1: addFirst(value) and addLast(value). addFirst: the new node must point at the old head BEFORE head
 *              is moved. Do not forget tail when the list was empty.
 * Milestone 2: remove(value): remove the FIRST node holding value and return true; return false if there is none.
 *              Cases: empty list, the head, a middle node, the tail (tail must move back!), the only node.
 * Milestone 3: reverse(): reverse the list IN PLACE by turning every next pointer around (no new nodes, O(1) extra
 *              space). Save a node's next before you overwrite it. head and tail swap roles.
 *
 * toList() and check() are given. check() verifies the structure (size, tail, every pointer) and the tests call it
 * after every operation; use it while you work. Part B is in ExDoubly.java.
 */
public final class ExLinked {
    public static final class Node {
        public int value;
        public Node next;

        public Node(int value, Node next) {
            this.value = value;
            this.next = next;
        }
    }

    public Node head = null;
    public Node tail = null;
    public int size = 0;

    public List<Integer> toList() {
        List<Integer> out = new ArrayList<>();
        for (Node node = head; node != null && out.size() <= size; node = node.next) {
            out.add(node.value);
        }
        return out;
    }

    public void check() {
        int count = 0;
        Node last = null;
        for (Node node = head; node != null; node = node.next) {
            count++;
            if (count > size) {
                throw new AssertionError("more nodes reachable than size (or a cycle)");
            }
            last = node;
        }
        if (count != size) {
            throw new AssertionError("size does not match the number of reachable nodes");
        }
        if (tail != last) {
            throw new AssertionError("tail is not the last node");
        }
        if ((head == null) != (size == 0)) {
            throw new AssertionError("head and size disagree");
        }
    }

    public void addFirst(int value) {
        throw new UnsupportedOperationException("not implemented");
    }

    public void addLast(int value) {
        throw new UnsupportedOperationException("not implemented");
    }

    public boolean remove(int value) {
        throw new UnsupportedOperationException("not implemented");
    }

    public void reverse() {
        throw new UnsupportedOperationException("not implemented");
    }
}
