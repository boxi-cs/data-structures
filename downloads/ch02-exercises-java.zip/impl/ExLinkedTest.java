import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Random;
import java.util.Set;
import org.junit.jupiter.api.Test;

class ExLinkedTest {
    static ExLinked of(int... values) {
        ExLinked lst = new ExLinked();
        for (int v : values) {
            lst.addLast(v);
            lst.check();
        }
        return lst;
    }

    static List<Integer> list(int... values) {
        List<Integer> out = new ArrayList<>();
        for (int v : values) {
            out.add(v);
        }
        return out;
    }

    static Set<ExLinked.Node> nodes(ExLinked lst) {
        Set<ExLinked.Node> out = Collections.newSetFromMap(new IdentityHashMap<>());
        for (ExLinked.Node n = lst.head; n != null; n = n.next) {
            out.add(n);
        }
        return out;
    }

    @Test
    void addFirstKeepsTheOldList() {
        ExLinked lst = new ExLinked();
        for (int v : new int[] {3, 2, 1}) {
            lst.addFirst(v);
            lst.check();
        }
        assertEquals(list(1, 2, 3), lst.toList());
        assertEquals(1, lst.head.value);
        assertEquals(3, lst.tail.value);
    }

    @Test
    void addLastAndMixingBothEnds() {
        ExLinked lst = new ExLinked();
        lst.addLast(20);
        lst.check();
        lst.addFirst(10);
        lst.check();
        lst.addLast(30);
        lst.check();
        assertEquals(list(10, 20, 30), lst.toList());
        assertEquals(10, lst.head.value);
        assertEquals(30, lst.tail.value);
        assertEquals(3, lst.size);
    }

    @Test
    void removeCases() {
        ExLinked lst = of(1, 2, 3, 4);
        assertFalse(lst.remove(9));
        lst.check();
        assertTrue(lst.remove(1)); // the head
        lst.check();
        assertEquals(list(2, 3, 4), lst.toList());
        assertEquals(2, lst.head.value);
        assertTrue(lst.remove(3)); // a middle node
        lst.check();
        assertEquals(list(2, 4), lst.toList());
        assertTrue(lst.remove(4)); // the tail: tail must move back
        lst.check();
        assertEquals(list(2), lst.toList());
        assertEquals(2, lst.tail.value);
        assertNull(lst.tail.next);
        assertTrue(lst.remove(2)); // the only node
        lst.check();
        assertNull(lst.head);
        assertNull(lst.tail);
        assertEquals(0, lst.size);
        assertFalse(lst.remove(2)); // empty list
        lst.check();
        lst.addLast(7); // the list is usable afterwards
        lst.check();
        assertEquals(list(7), lst.toList());
    }

    @Test
    void removeTakesOutOnlyTheFirstOccurrence() {
        ExLinked lst = of(5, 7, 5, 7);
        assertTrue(lst.remove(7));
        lst.check();
        assertEquals(list(5, 5, 7), lst.toList());
    }

    @Test
    void reverseInPlace() {
        int[][] cases = {{}, {1}, {1, 2}, {1, 2, 3, 4}};
        for (int[] values : cases) {
            ExLinked lst = of(values);
            Set<ExLinked.Node> before = nodes(lst);
            lst.reverse();
            lst.check();
            List<Integer> reversed = list(values);
            Collections.reverse(reversed);
            assertEquals(reversed, lst.toList());
            assertEquals(before, nodes(lst)); // the same node objects, no new ones
            lst.reverse();
            lst.check();
            assertEquals(list(values), lst.toList());
        }
        ExLinked lst = of(1, 2, 3, 4);
        lst.reverse();
        assertEquals(4, lst.head.value);
        assertEquals(1, lst.tail.value);
        assertNull(lst.tail.next);
        assertSame(lst.tail, lst.head.next.next.next);
    }

    @Test
    void randomOperationsMatchAList() {
        Random rng = new Random(3);
        ExLinked lst = new ExLinked();
        List<Integer> ref = new ArrayList<>();
        for (int step = 0; step < 1500; step++) {
            double r = rng.nextDouble();
            if (r < 0.3) {
                lst.addFirst(step);
                ref.add(0, step);
            } else if (r < 0.6) {
                lst.addLast(step);
                ref.add(step);
            } else if (r < 0.9) {
                int v = !ref.isEmpty() && rng.nextDouble() < 0.8 ? ref.get(rng.nextInt(ref.size())) : -1;
                assertEquals(ref.contains(v), lst.remove(v));
                ref.remove((Integer) v);
            } else {
                lst.reverse();
                Collections.reverse(ref);
            }
            lst.check();
            assertEquals(ref, lst.toList());
        }
    }
}
