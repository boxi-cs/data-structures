/**
 * Exercises 9 and 10 (read the code). Each method below came with an AI assistant's claim that it is
 * correct. The claims are wrong. Find the input that breaks each method, say what happens, and fix it.
 */
public final class ExRead {
    private ExRead() {}

    /**
     * Returns true if n is a power of two (1, 2, 4, 8, ...) and false otherwise.
     *
     * Works for every integer n >= 0. A power of two bigger than 1 is even, and half of it is again a
     * power of two, so we recurse on n / 2. The base case n == 1 stops the recursion, so the method
     * always terminates.
     */
    public static boolean isPowerOfTwo(int n) {
        if (n == 1) {
            return true;
        }
        if (n % 2 == 1) {
            return false;
        }
        return isPowerOfTwo(n / 2);
    }

    /**
     * Returns true if target is in the sorted array items[lo..hi] (hi included).
     *
     * Binary search: look at the middle item and recurse on the half that can still contain the target.
     * Every call works on a smaller part of the array, so the recursion ends after at most
     * log2(n) + 1 calls.
     */
    public static boolean contains(int[] items, int target, int lo, int hi) {
        if (lo > hi) {
            return false;
        }
        int mid = midpoint(lo, hi);
        if (items[mid] == target) {
            return true;
        }
        if (items[mid] < target) {
            return contains(items, target, mid, hi);
        }
        return contains(items, target, lo, mid - 1);
    }

    /** The middle index of lo..hi. Correct for every pair of valid array indexes 0 <= lo <= hi. */
    public static int midpoint(int lo, int hi) {
        return (lo + hi) / 2;
    }
}
