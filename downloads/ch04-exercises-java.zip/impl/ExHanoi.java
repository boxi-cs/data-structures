import java.util.List;

/**
 * Exercise 6 (implementation): Towers of Hanoi.
 *
 * Move n disks from peg src to peg dst, using peg tmp as a spare. Only one disk moves at a time, only the
 * top disk of a peg can move, and a disk may never sit on a smaller disk. The disks start on src with the
 * largest at the bottom.
 *
 * Return the moves in order; a move is a two-character string "FT": from peg F to peg T, e.g. "AC".
 *
 * Milestone 1: the base case (what does n == 0 need?).
 * Milestone 2: the recursive structure from Exercise 4: move n - 1 disks out of the way, move the biggest
 *              disk, move the n - 1 disks back on top of it.
 * Milestone 3: check that the number of moves is the closed form you derived (2^n - 1).
 */
public final class ExHanoi {
    private ExHanoi() {}

    /** The moves ("AC", "AB", ...) that solve Towers of Hanoi for n disks. */
    public static List<String> hanoi(int n, char src, char dst, char tmp) {
        throw new UnsupportedOperationException("not implemented");
    }
}
