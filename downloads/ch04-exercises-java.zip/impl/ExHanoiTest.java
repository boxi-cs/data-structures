import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Test;

class ExHanoiTest {
    /** Plays the moves on three pegs; fails on an illegal move. Returns the pegs 'A', 'B', 'C' at the end. */
    static Deque<Integer>[] replay(int n, List<String> moves) {
        @SuppressWarnings("unchecked")
        Deque<Integer>[] pegs = new Deque[3];
        for (int i = 0; i < 3; i++) {
            pegs[i] = new ArrayDeque<>();
        }
        for (int d = n; d >= 1; d--) {
            pegs[0].push(d); // top of the deque = top of the peg
        }
        for (String move : moves) {
            Deque<Integer> from = pegs[move.charAt(0) - 'A'];
            Deque<Integer> to = pegs[move.charAt(1) - 'A'];
            assertFalse(from.isEmpty(), "move " + move + ": the source peg is empty");
            int disk = from.peek();
            assertTrue(to.isEmpty() || to.peek() > disk, "move " + move + ": disk " + disk + " on a smaller disk");
            to.push(from.pop());
        }
        return pegs;
    }

    @Test
    void noDisksNoMoves() {
        assertEquals(List.of(), ExHanoi.hanoi(0, 'A', 'C', 'B'));
    }

    @Test
    void oneDisk() {
        assertEquals(List.of("AC"), ExHanoi.hanoi(1, 'A', 'C', 'B'));
    }

    @Test
    void twoDisksExactMoves() {
        assertEquals(List.of("AB", "AC", "BC"), ExHanoi.hanoi(2, 'A', 'C', 'B'));
    }

    @Test
    void movesAreLegalAndFinishOnTheTargetPeg() {
        for (int n = 0; n <= 10; n++) {
            Deque<Integer>[] pegs = replay(n, ExHanoi.hanoi(n, 'A', 'C', 'B'));
            assertTrue(pegs[0].isEmpty() && pegs[1].isEmpty(), "n=" + n);
            assertEquals(n, pegs[2].size(), "n=" + n);
            int expected = 1; // from the top: 1, 2, ..., n
            for (int disk : pegs[2]) {
                assertEquals(expected++, disk);
            }
        }
    }

    @Test
    void numberOfMovesIsTwoToTheNMinusOne() {
        for (int n = 0; n <= 15; n++) {
            assertEquals((1 << n) - 1, ExHanoi.hanoi(n, 'A', 'C', 'B').size(), "n=" + n);
        }
    }

    @Test
    void otherPegNames() {
        List<String> moves = ExHanoi.hanoi(3, 'X', 'Z', 'Y');
        assertEquals(7, moves.size());
        assertEquals("XZ", moves.get(0));
        Set<Character> pegs = new HashSet<>();
        for (String m : moves) {
            assertTrue(m.charAt(0) != m.charAt(1));
            pegs.add(m.charAt(0));
            pegs.add(m.charAt(1));
        }
        assertEquals(Set.of('X', 'Y', 'Z'), pegs);
    }
}
