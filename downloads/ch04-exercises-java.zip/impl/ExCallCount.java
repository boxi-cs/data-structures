/**
 * Exercise 7 (implementation): count the calls of the naive Fibonacci method without making them.
 *
 * The naive method
 *
 *     static long fib(int n) { return n <= 1 ? n : fib(n - 1) + fib(n - 2); }
 *
 * makes 15 calls for fib(5) and 2,692,537 for fib(30). Write fibCalls(n): the number of calls fib(n)
 * would make (counting the first call), WITHOUT running fib. It must be fast for n = 80, where the real
 * count has 17 digits (it still fits in a long).
 *
 * Milestone 1: the base cases (how many calls does fib(0) make? fib(1)?).
 * Milestone 2: the recurrence from Exercise 1(d): calls(n) = 1 + calls(n - 1) + calls(n - 2).
 * Milestone 3: make it fast. Remember answers you already computed (an array filled once).
 */
public final class ExCallCount {
    private ExCallCount() {}

    /** Number of calls the naive recursive fib(n) makes, counting the first one. n >= 0. */
    public static long fibCalls(int n) {
        throw new UnsupportedOperationException("not implemented");
    }
}
