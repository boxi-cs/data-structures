import java.util.Comparator;
import java.util.Random;

/**
 * Exercise 8 (implementation): partition, then quickselect (the k-th smallest item without sorting).
 *
 * Milestone 1 -- partition(a, lo, hi, cmp): Lomuto partition of a[lo..hi] (both ends included) with the
 *     LAST item a[hi] as the pivot. Rearrange a[lo..hi] in place so that everything smaller than the pivot
 *     comes first, then the pivot, then everything else; return the pivot's final index. Compare each of
 *     the other items with the pivot exactly once, and only through cmp.compare.
 *
 * Milestone 2 -- quickselect(items, k, rng, cmp): return the item that would be at index k (0-based) if the
 *     array were sorted, WITHOUT sorting it and WITHOUT changing items (work on a copy). Recurse (or loop)
 *     on only the side that contains index k.
 *
 * Milestone 3 -- choose the pivot at random so that already-sorted input is not a bad case: before each
 *     partition pick r = lo + rng.nextInt(hi - lo + 1) and swap a[r] with a[hi].
 */
public final class ExQuickselect {
    private ExQuickselect() {}

    /** Lomuto partition of a[lo..hi] around a[hi]; returns the pivot's final index. */
    public static int partition(Integer[] a, int lo, int hi, Comparator<Integer> cmp) {
        throw new UnsupportedOperationException("not implemented");
    }

    /** The k-th smallest item (0-based); the array items itself is left unchanged. */
    public static Integer quickselect(Integer[] items, int k, Random rng, Comparator<Integer> cmp) {
        throw new UnsupportedOperationException("not implemented");
    }
}
