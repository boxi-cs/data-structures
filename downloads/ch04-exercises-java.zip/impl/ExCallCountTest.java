import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class ExCallCountTest {
    static long calls;

    static long naiveFib(int n) {
        calls++;
        return n <= 1 ? n : naiveFib(n - 1) + naiveFib(n - 2);
    }

    @Test
    void baseCases() {
        assertEquals(1, ExCallCount.fibCalls(0));
        assertEquals(1, ExCallCount.fibCalls(1));
    }

    @Test
    void matchesTheRealCountsFromTheVideo() {
        assertEquals(15, ExCallCount.fibCalls(5));
        assertEquals(177, ExCallCount.fibCalls(10));
        assertEquals(21891, ExCallCount.fibCalls(20));
        assertEquals(2692537, ExCallCount.fibCalls(30));
    }

    @Test
    void matchesARealRunForSmallN() {
        for (int n = 0; n <= 20; n++) {
            calls = 0;
            naiveFib(n);
            assertEquals(calls, ExCallCount.fibCalls(n), "n=" + n);
        }
    }

    @Test
    void fastAndExactForN80() {
        long a = 0;
        long b = 1; // fib(0), fib(1)
        for (int i = 0; i < 81; i++) {
            long next = a + b;
            a = b;
            b = next;
        }
        assertEquals(2 * a - 1, ExCallCount.fibCalls(80)); // the closed form you prove in Exercise 1(d)
    }
}
