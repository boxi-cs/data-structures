import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import org.junit.jupiter.api.Test;

class ExQuickselectTest {
    static long comparisons;

    static final Comparator<Integer> COUNTING = (x, y) -> {
        comparisons++;
        return Integer.compare(x, y);
    };

    @Test
    void partitionPlacesThePivotAndSplitsTheRest() {
        Random rng = new Random(1);
        for (int t = 0; t < 200; t++) {
            int n = 1 + rng.nextInt(14);
            Integer[] a = new Integer[n];
            for (int i = 0; i < n; i++) {
                a[i] = rng.nextInt(8);
            }
            int lo = rng.nextInt(n);
            int hi = lo + rng.nextInt(n - lo);
            Integer[] before = a.clone();
            int pivot = a[hi];
            int p = ExQuickselect.partition(a, lo, hi, Integer::compare);
            assertTrue(lo <= p && p <= hi);
            assertEquals(pivot, a[p]);
            for (int i = lo; i < p; i++) {
                assertTrue(a[i] < pivot);
            }
            for (int i = p + 1; i <= hi; i++) {
                assertTrue(a[i] >= pivot);
            }
            for (int i = 0; i < n; i++) {
                if (i < lo || i > hi) {
                    assertEquals(before[i], a[i], "outside the range must be untouched");
                }
            }
            Integer[] x = a.clone();
            Integer[] y = before.clone();
            Arrays.sort(x);
            Arrays.sort(y);
            assertArrayEquals(y, x, "only a rearrangement");
        }
    }

    @Test
    void partitionMakesExactlyHiMinusLoComparisons() {
        for (int n : new int[] {1, 2, 5, 20}) {
            List<Integer> values = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                values.add(i * 7 % 101);
            }
            Collections.shuffle(values, new Random(n));
            Integer[] a = values.toArray(new Integer[0]);
            comparisons = 0;
            ExQuickselect.partition(a, 0, n - 1, COUNTING);
            assertEquals(n - 1, comparisons, "n=" + n);
        }
    }

    @Test
    void quickselectMatchesSorting() {
        Random rng = new Random(7);
        for (int t = 0; t < 100; t++) {
            int n = 1 + rng.nextInt(39);
            Integer[] a = new Integer[n];
            for (int i = 0; i < n; i++) {
                a[i] = rng.nextInt(20);
            }
            Integer[] sorted = a.clone();
            Arrays.sort(sorted);
            for (int k = 0; k < n; k++) {
                assertEquals(sorted[k], ExQuickselect.quickselect(a, k, new Random(k), Integer::compare), "k=" + k);
            }
        }
    }

    @Test
    void quickselectLeavesTheInputUnchanged() {
        Integer[] a = {5, 3, 9, 1, 7, 3};
        Integer[] copy = a.clone();
        ExQuickselect.quickselect(a, 2, new Random(0), Integer::compare);
        assertArrayEquals(copy, a);
    }

    @Test
    void quickselectIsLinearEvenOnSortedInput() {
        int n = 4000;
        List<Integer> perm = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            perm.add(i * 10 + 3);
        }
        Collections.shuffle(perm, new Random(3));
        Integer[][] inputs = new Integer[3][n];
        for (int i = 0; i < n; i++) {
            inputs[0][i] = i;
            inputs[1][i] = n - i;
            inputs[2][i] = perm.get(i);
        }
        for (Integer[] a : inputs) {
            Integer[] sorted = a.clone();
            Arrays.sort(sorted);
            comparisons = 0;
            Integer got = ExQuickselect.quickselect(a, n / 2, new Random(5), COUNTING);
            assertEquals(sorted[n / 2], got);
            assertTrue(comparisons < 12L * n, comparisons + " comparisons for n = " + n + ": is the pivot random?");
        }
    }
}
