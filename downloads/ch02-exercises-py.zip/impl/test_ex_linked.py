import random

import pytest

from ex_linked import DoublyLinked, SinglyLinked


def singly(values):
    lst = SinglyLinked()
    for v in values:
        lst.add_last(v)
        lst.check()
    return lst


def test_add_first_keeps_the_old_list():
    lst = SinglyLinked()
    for v in (3, 2, 1):
        lst.add_first(v)
        lst.check()
    assert lst.to_list() == [1, 2, 3]
    assert lst.head.value == 1 and lst.tail.value == 3


def test_add_last_and_mixing_both_ends():
    lst = SinglyLinked()
    lst.add_last("b")
    lst.check()
    lst.add_first("a")
    lst.check()
    lst.add_last("c")
    lst.check()
    assert lst.to_list() == ["a", "b", "c"]
    assert lst.head.value == "a" and lst.tail.value == "c" and lst.size == 3


def test_remove_cases():
    lst = singly([1, 2, 3, 4])
    assert lst.remove(9) is False
    lst.check()
    assert lst.remove(1) is True  # the head
    lst.check()
    assert lst.to_list() == [2, 3, 4] and lst.head.value == 2
    assert lst.remove(3) is True  # a middle node
    lst.check()
    assert lst.to_list() == [2, 4]
    assert lst.remove(4) is True  # the tail: tail must move back
    lst.check()
    assert lst.to_list() == [2] and lst.tail.value == 2 and lst.tail.next is None
    assert lst.remove(2) is True  # the only node
    lst.check()
    assert lst.head is None and lst.tail is None and lst.size == 0
    assert lst.remove(2) is False  # empty list
    lst.check()
    lst.add_last("again")  # the list is usable afterwards
    lst.check()
    assert lst.to_list() == ["again"]


def test_remove_takes_out_only_the_first_occurrence():
    lst = singly([5, 7, 5, 7])
    assert lst.remove(7) is True
    lst.check()
    assert lst.to_list() == [5, 5, 7]


def test_reverse_in_place():
    for values in ([], [1], [1, 2], [1, 2, 3, 4]):
        lst = singly(values)
        nodes = {id(n) for n in iter_nodes(lst)}
        lst.reverse()
        lst.check()
        assert lst.to_list() == values[::-1]
        assert {id(n) for n in iter_nodes(lst)} == nodes  # the same nodes, no new ones
        lst.reverse()
        lst.check()
        assert lst.to_list() == values
    lst = singly([1, 2, 3, 4])
    lst.reverse()
    assert lst.head.value == 4 and lst.tail.value == 1 and lst.tail.next is None


def iter_nodes(lst):
    node = lst.head
    while node is not None:
        yield node
        node = node.next


def test_singly_random_operations_match_a_list():
    rng = random.Random(3)
    lst, ref = SinglyLinked(), []
    for step in range(1500):
        r = rng.random()
        if r < 0.3:
            lst.add_first(step)
            ref.insert(0, step)
        elif r < 0.6:
            lst.add_last(step)
            ref.append(step)
        elif r < 0.9:
            v = rng.choice(ref) if ref and rng.random() < 0.8 else -1
            assert lst.remove(v) is (v in ref)
            if v in ref:
                ref.remove(v)
        else:
            lst.reverse()
            ref.reverse()
        lst.check()
        assert lst.to_list() == ref


def doubly(values):
    lst = DoublyLinked()
    for v in values:
        lst.add_last(v)
        lst.check()
    return lst


def test_doubly_add_last_and_insert_between():
    lst = doubly([1, 3])
    assert lst.to_list() == [1, 3]
    first = lst.header.next
    node = lst.insert_between(2, first, first.next)
    lst.check()
    assert node.value == 2 and lst.to_list() == [1, 2, 3] and lst.size == 3
    lst.insert_between(0, lst.header, lst.header.next)
    lst.check()
    assert lst.to_list() == [0, 1, 2, 3]


def test_doubly_delete_node():
    lst = DoublyLinked()
    nodes = [lst.add_last(v) for v in "ABCD"]
    assert lst.delete_node(nodes[2]) == "C"
    lst.check()
    assert lst.to_list() == list("ABD")
    assert lst.delete_node(nodes[0]) == "A"
    lst.check()
    assert lst.delete_node(nodes[3]) == "D"
    lst.check()
    assert lst.to_list() == ["B"]
    assert lst.delete_node(nodes[1]) == "B"
    lst.check()
    assert lst.to_list() == [] and lst.size == 0


def test_doubly_remove_last():
    lst = doubly([1, 2, 3])
    assert [lst.remove_last() for _ in range(3)] == [3, 2, 1]
    lst.check()
    with pytest.raises(IndexError):
        lst.remove_last()


def test_doubly_random_operations_match_a_list():
    rng = random.Random(5)
    lst, nodes, ref = DoublyLinked(), [], []
    for step in range(1500):
        r = rng.random()
        if r < 0.5 or not ref:
            nodes.append(lst.add_last(step))
            ref.append(step)
        elif r < 0.75:
            assert lst.remove_last() == ref.pop()
            nodes.pop()
        else:
            i = rng.randrange(len(ref))
            assert lst.delete_node(nodes.pop(i)) == ref.pop(i)
        lst.check()
        assert lst.to_list() == ref
