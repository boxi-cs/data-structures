import random

import pytest

from ex_growarray import GrowArray


def appended(n):
    a = GrowArray()
    for i in range(n):
        a.append(i)
    return a


def test_capacities_while_appending():
    a = GrowArray()
    caps = []
    for i in range(9):
        a.append(i)
        caps.append(a.capacity)
    assert caps == [1, 2, 4, 4, 8, 8, 8, 8, 16]
    assert a.copies == 15
    assert [a.get(i) for i in range(9)] == list(range(9))


def test_copies_of_appending_17_items():
    a = appended(17)
    assert a.capacity == 32 and a.copies == 31


def test_insert_in_the_middle_shifts_the_tail():
    a = GrowArray()
    for ch in "ABCDE":
        a.append(ch)
    a.insert(2, "X")
    assert [a.get(i) for i in range(6)] == list("ABXCDE")
    assert a.size == 6 and a.shifts == 3


def test_inserting_at_the_front_costs_n_squared_over_two_shifts():
    a = GrowArray()
    for i in range(100):
        a.insert(0, i)
    assert [a.get(i) for i in range(100)] == list(range(99, -1, -1))
    assert a.shifts == 100 * 99 // 2  # 0 + 1 + ... + 99
    assert a.copies == 127  # the same doubling copies as appending: 1 + 2 + 4 + ... + 64


def test_insert_index_errors():
    a = appended(3)
    for bad in (4, -1):
        with pytest.raises(IndexError):
            a.insert(bad, "X")
    a.insert(3, "X")  # index == size is an append
    assert a.get(3) == "X"


def test_pop_returns_the_last_item_and_shrinks_at_a_quarter():
    a = appended(9)
    caps, popped = [], []
    for _ in range(9):
        popped.append(a.pop())
        caps.append(a.capacity)
    assert popped == list(range(8, -1, -1))
    assert caps == [16, 16, 16, 16, 8, 8, 4, 2, 1]
    assert a.copies == 15 + 4 + 2 + 1


def test_pop_from_an_empty_array():
    with pytest.raises(IndexError):
        GrowArray().pop()


def test_alternating_at_the_growth_boundary_does_not_thrash():
    a = appended(8)  # full: capacity 8
    before = a.copies
    for _ in range(1000):
        a.append(0)
        a.pop()
    assert a.copies - before <= 8  # one growth, then no further copying


def test_capacity_invariants_under_random_operations():
    rng = random.Random(7)
    a, ref = GrowArray(), []
    for step in range(3000):
        r = rng.random()
        if ref and r < 0.45:
            assert a.pop() == ref.pop()
        elif r < 0.75:
            a.append(step)
            ref.append(step)
        else:
            i = rng.randrange(len(ref) + 1)
            a.insert(i, step)
            ref.insert(i, step)
        assert a.size == len(ref)
        assert a.size <= a.capacity
        assert a.capacity == 1 or a.capacity < 4 * a.size  # never more than 4 slots per item
    assert [a.get(i) for i in range(a.size)] == ref
