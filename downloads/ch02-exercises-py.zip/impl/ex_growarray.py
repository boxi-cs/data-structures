"""Exercise 7 (implementation): a dynamic array with insert, pop and a SHRINKING policy.

The array starts with capacity 1 and size 0. `copies` counts every element copied by a resize (one per
element), `shifts` every single-item move made by insert.

Milestone 1: _resize(new_capacity): allocate a list of that length, copy the `size` items over ONE AT A
             TIME (copies += 1 for each), and use the new list.
Milestone 2: append(value): if the array is full, double the capacity first.
Milestone 3: insert(index, value), 0 <= index <= size: double if full, then shift the items from `index` on
             one slot to the right, last one first (shifts += 1 for each), then write.
Milestone 4: pop(): remove and return the last item; IndexError if empty. Afterwards, if capacity > 1 and
             4 * size <= capacity, HALVE the capacity (a resize). Shrinking only when the array is a QUARTER
             full, not half full, is what keeps pop from undoing the work of append (see the thrash test).

Run:  pytest test_ex_growarray.py
"""


class GrowArray:
    def __init__(self):
        self.items = [None]  # capacity 1
        self.size = 0
        self.copies = 0
        self.shifts = 0

    @property
    def capacity(self):
        return len(self.items)

    def get(self, index):
        if not 0 <= index < self.size:
            raise IndexError("index out of range")
        return self.items[index]

    def _resize(self, new_capacity):
        raise NotImplementedError

    def append(self, value):
        raise NotImplementedError

    def insert(self, index, value):
        raise NotImplementedError

    def pop(self):
        raise NotImplementedError
