"""Exercise 6 (implementation): a fixed-capacity array whose insert and remove shift items.

State: `items` is a list of length `capacity`; the first `size` slots hold the items, the others hold None.
`shifts` counts every single-item move made so far: one `items[k] = items[j]` between two used slots is one
shift. Writing the new item and clearing a slot are not shifts.

Milestone 1: get(index).
Milestone 2: insert(index, value): move the items from `index` on one slot to the right, LAST ONE FIRST,
             then write the value.
Milestone 3: remove(index): move the later items one slot to the left, clear the last used slot, return the value.
Milestone 4: make `shifts` come out right (insert at i moves size - i items, remove at i moves size - 1 - i).

Errors: OverflowError when inserting into a full array; IndexError for an index out of range
(insert: 0..size, get and remove: 0..size-1).

Run:  pytest test_ex_arrayops.py
"""


class ShiftArray:
    def __init__(self, capacity):
        self.items = [None] * capacity
        self.size = 0
        self.shifts = 0

    def get(self, index):
        raise NotImplementedError

    def insert(self, index, value):
        raise NotImplementedError

    def remove(self, index):
        raise NotImplementedError
