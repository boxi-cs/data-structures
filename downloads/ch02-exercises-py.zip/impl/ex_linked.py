"""Exercise 8 (implementation): linked lists, with the pointer updates in the right order.

Part A: SinglyLinked (head, tail, size).
  Milestone 1: add_first(value) and add_last(value). add_first: the new node must point at the old head BEFORE
               head is moved. Do not forget `tail` when the list was empty.
  Milestone 2: remove(value): remove the FIRST node holding value and return True; return False if there is none.
               Cases: empty list, the head, a middle node, the tail (tail must move back!), the only node.
  Milestone 3: reverse(): reverse the list IN PLACE by turning every `next` pointer around (no new nodes, O(1)
               extra space). Save a node's `next` before you overwrite it. head and tail swap roles.
Part B: DoublyLinked with a header and a trailer sentinel (the real items sit between them).
  Milestone 4: insert_between(value, pred, succ) (returns the new node), add_last(value) (returns the new node),
               delete_node(node) (returns its value), remove_last() (returns the value, IndexError if empty).
               Every operation is a fixed number of pointer changes: no loop over the list.

`to_list()` and `check()` are given. check() verifies the structure (size, tail, every pointer) and the tests call it
after every operation; use it while you work.

Run:  pytest test_ex_linked.py
"""


class Node:
    def __init__(self, value, next=None):
        self.value = value
        self.next = next


class SinglyLinked:
    def __init__(self):
        self.head = None
        self.tail = None
        self.size = 0

    def to_list(self):
        out, node = [], self.head
        while node is not None and len(out) <= self.size:
            out.append(node.value)
            node = node.next
        return out

    def check(self):
        count, node, last = 0, self.head, None
        while node is not None:
            count += 1
            assert count <= self.size, "more nodes reachable than size (or a cycle)"
            last, node = node, node.next
        assert count == self.size, "size does not match the number of reachable nodes"
        assert self.tail is last, "tail is not the last node"
        assert (self.head is None) == (self.size == 0)

    def add_first(self, value):
        raise NotImplementedError

    def add_last(self, value):
        raise NotImplementedError

    def remove(self, value):
        raise NotImplementedError

    def reverse(self):
        raise NotImplementedError


class DNode:
    def __init__(self, value, prev=None, next=None):
        self.value = value
        self.prev = prev
        self.next = next


class DoublyLinked:
    def __init__(self):
        self.header = DNode(None)
        self.trailer = DNode(None)
        self.header.next = self.trailer
        self.trailer.prev = self.header
        self.size = 0

    def to_list(self):
        out, node = [], self.header.next
        while node is not self.trailer and len(out) <= self.size:
            out.append(node.value)
            node = node.next
        return out

    def check(self):
        count, node = 0, self.header
        assert node.prev is None and self.trailer.next is None
        while node is not self.trailer:
            assert node.next is not None and node.next.prev is node, "next/prev pointers disagree"
            node = node.next
            count += 1
            assert count <= self.size + 1, "more nodes reachable than size (or a cycle)"
        assert count - 1 == self.size, "size does not match the number of nodes between the sentinels"

    def insert_between(self, value, pred, succ):
        raise NotImplementedError

    def add_last(self, value):
        raise NotImplementedError

    def delete_node(self, node):
        raise NotImplementedError

    def remove_last(self):
        raise NotImplementedError
