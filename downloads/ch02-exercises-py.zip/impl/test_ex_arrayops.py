import random

import pytest

from ex_arrayops import ShiftArray


def letters(n, capacity=8):
    """An array holding the first n letters of ABCDEFGH, built by appending (no shifts)."""
    a = ShiftArray(capacity)
    for i, ch in enumerate("ABCDEFGH"[:n]):
        a.insert(i, ch)
    return a


def test_get():
    a = letters(5)
    assert [a.get(i) for i in range(5)] == list("ABCDE")
    for bad in (5, -1, 8):
        with pytest.raises(IndexError):
            a.get(bad)


def test_insert_in_the_middle_shifts_the_tail():
    a = letters(5)
    assert a.shifts == 0  # appending moves nothing
    a.insert(2, "X")
    assert a.items == list("ABXCDE") + [None, None]
    assert a.size == 6
    assert a.shifts == 3  # E, then D, then C


def test_insert_at_the_front_and_at_the_end():
    a = letters(5)
    a.insert(0, "X")
    assert a.items == list("XABCDE") + [None, None]
    assert a.shifts == 5  # every item moves
    b = letters(5)
    b.insert(5, "X")
    assert b.items == list("ABCDEX") + [None, None]
    assert b.shifts == 0  # nothing moves


def test_insert_errors_leave_the_array_unchanged():
    full = letters(8)
    with pytest.raises(OverflowError):
        full.insert(3, "X")
    assert full.items == list("ABCDEFGH") and full.size == 8 and full.shifts == 0
    a = letters(5)
    for bad in (6, -1):
        with pytest.raises(IndexError):
            a.insert(bad, "X")
    assert a.items == list("ABCDE") + [None] * 3 and a.size == 5 and a.shifts == 0


def test_remove_closes_the_gap():
    a = letters(5)
    a.insert(2, "X")
    assert a.remove(0) == "A"
    assert a.items == list("BXCDE") + [None] * 3
    assert a.size == 5
    assert a.shifts == 3 + 5  # the insert moved 3, the remove moves the 5 items after position 0


def test_remove_the_last_item_moves_nothing_and_clears_its_slot():
    a = letters(5)
    assert a.remove(4) == "E"
    assert a.items[4] is None and a.size == 4 and a.shifts == 0


def test_remove_errors():
    a = letters(5)
    with pytest.raises(IndexError):
        a.remove(5)
    with pytest.raises(IndexError):
        ShiftArray(3).remove(0)


def test_random_operations_match_a_list():
    rng = random.Random(1)
    a, ref, shifts = ShiftArray(50), [], 0
    for step in range(2000):
        if ref and (len(ref) == 50 or rng.random() < 0.5):
            i = rng.randrange(len(ref))
            assert a.remove(i) == ref.pop(i)
            shifts += len(ref) - i  # size - 1 - i with the old size
        else:
            i = rng.randrange(len(ref) + 1)
            a.insert(i, step)
            shifts += len(ref) - i
            ref.insert(i, step)
        assert a.items == ref + [None] * (50 - len(ref))
        assert a.size == len(ref) and a.shifts == shifts
