"""Exercise 10 (read the code). An AI assistant wrote this singly linked list. Its `to_list` helper and two of its
tests pass. There are TWO bugs, both about updating references. For each: find a short sequence of calls that
shows it, say exactly which nodes are lost or which reference is stale, and fix it.
"""


class Node:
    def __init__(self, value, next=None):
        self.value = value
        self.next = next


class LinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        self.size = 0

    def add_first(self, value):
        node = Node(value)
        self.head = node
        node.next = self.head.next
        if self.tail is None:
            self.tail = node
        self.size += 1

    def add_last(self, value):
        node = Node(value)
        if self.tail is None:
            self.head = node
        else:
            self.tail.next = node
        self.tail = node
        self.size += 1

    def insert_after(self, node, value):
        new = Node(value)
        new.next = node.next
        node.next = new
        self.size += 1

    def to_list(self):
        out, node = [], self.head
        while node is not None:
            out.append(node.value)
            node = node.next
        return out


# The AI's tests, which pass:
def test_add_last_then_first_on_an_empty_list():
    lst = LinkedList()
    lst.add_first(1)
    lst.add_last(2)
    assert lst.to_list() == [1, 2]


def test_insert_after_a_middle_node():
    lst = LinkedList()
    lst.add_last(1)
    lst.add_last(2)
    lst.add_last(3)
    lst.insert_after(lst.head, 9)
    assert lst.to_list() == [1, 9, 2, 3]
