"""Exercise 9 (read the code). An AI assistant wrote this function for a fixed-capacity array.
Its docstring is exactly what we agreed on in the chapter; its test passed. The code has a bug.
Find a SMALL input that shows it, say what goes wrong, and fix it.
"""


def insert(items, size, index, value):
    """Insert value at position `index` of the first `size` slots of `items` (the list length is the capacity).

    The items from `index` on move one slot to the right, last one first, so nothing is overwritten before it
    has moved. Raises OverflowError if the array is full and IndexError if index is not in 0..size.
    The caller adds 1 to its own size afterwards. Cost: size - index moves.
    """
    if size == len(items):
        raise OverflowError("array is full")
    if not 0 <= index <= size:
        raise IndexError("index out of range")
    for k in range(size - 1, index, -1):
        items[k] = items[k - 1]
    items[index] = value


# The AI's test, which passes:
def test_insert_near_the_end():
    items = ["A", "B", "C", None, None]
    insert(items, 3, 2, "X")
    assert items[:3] == ["A", "B", "X"]
