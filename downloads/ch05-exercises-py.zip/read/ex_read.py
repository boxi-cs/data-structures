"""Exercises 9 and 10 (read the code).  Each function below came from an AI assistant together with a claim.

Exercise 9:  `delete` is claimed to be correct.  It is not.  Find the input that breaks it.
Exercise 10: `contains` is claimed to be O(h).  It returns the right answers.  Is the claim right?
"""


class Node:
    def __init__(self, key, left=None, right=None):
        self.key = key
        self.left = left
        self.right = right


def delete(node, key):
    """Delete key from the binary search tree rooted at node and return the root of the resulting tree.

    Correct and O(h): one walk down to the key (it never revisits a node), then the three cases --
    no child (the node simply disappears), one child (the child takes its place), two children (the key
    of the in-order successor moves up and the successor node is removed).  The tree is still a BST.
    """
    if node is None:
        return None
    if key < node.key:
        delete(node.left, key)
        return node
    if key > node.key:
        delete(node.right, key)
        return node
    if node.left is None:
        return node.right
    if node.right is None:
        return node.left
    successor = node.right
    while successor.left is not None:
        successor = successor.left
    node.key = successor.key
    node.right = delete(node.right, successor.key)
    return node


def contains(node, key):
    """True if key is stored in the binary search tree rooted at node.

    O(h): the search tree property tells us which subtree can hold the key, so the work is proportional
    to the height of the tree, which is log n for a balanced tree.
    """
    if node is None:
        return False
    if node.key == key:
        return True
    return contains(node.left, key) or contains(node.right, key)
