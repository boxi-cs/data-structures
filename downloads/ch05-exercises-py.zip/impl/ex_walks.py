"""Exercise 6 (implementation): walking a binary tree without recursion.

Three milestones, in order; run the tests after each one.

Milestone 1 -- InorderIterator: yield the keys of a tree in inorder using an explicit stack (no recursion).
    __init__ pushes the root and every left child below it (the "left spine").
    next() pops a node, pushes the left spine of its right child, and returns the popped key.
    has_next() is True while the stack is not empty.
Milestone 2 -- height(root): the height in EDGES (empty tree: -1, a single node: 0), computed level by level
    with no recursion, so that a chain of 50,000 nodes works.
Milestone 3 -- is_bst(root): True exactly when every node's key is larger than every key in its left subtree and
    smaller than every key in its right subtree (keys are distinct: a repeated key makes it False).
    Use your iterator; it is a one-line idea (what does an inorder walk of a BST look like?).

Run:  pytest test_ex_walks.py
"""


class Node:
    def __init__(self, key, left=None, right=None):
        self.key = key
        self.left = left
        self.right = right


class InorderIterator:
    def __init__(self, root):
        raise NotImplementedError

    def has_next(self):
        raise NotImplementedError

    def next(self):
        raise NotImplementedError

    def stack_size(self):
        """How many nodes are on the stack right now (the tests use it to check your memory use)."""
        raise NotImplementedError

    def __iter__(self):
        return self

    def __next__(self):
        if not self.has_next():
            raise StopIteration
        return self.next()


def height(root):
    raise NotImplementedError


def is_bst(root):
    raise NotImplementedError
