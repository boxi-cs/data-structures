import random

from ex_delete import Node, Tree


def keys_inorder(root):
    out, stack, node = [], [], root
    while stack or node is not None:
        while node is not None:
            stack.append(node)
            node = node.left
        node = stack.pop()
        out.append(node.key)
        node = node.right
    return out


def is_ordered(root):
    keys = keys_inorder(root)
    return all(a < b for a, b in zip(keys, keys[1:]))


def tree_of(keys):
    t = Tree()
    for k in keys:
        t.insert(k)
    return t


VIDEO_TREE = [50, 30, 70, 20, 40, 60, 80, 45, 65]  # inorder 20 30 40 45 50 60 65 70 80


def test_leaf():
    t = tree_of(VIDEO_TREE)
    assert t.delete(20) is True
    assert keys_inorder(t.root) == [30, 40, 45, 50, 60, 65, 70, 80]
    assert t.size == 8
    assert t.root.left.left is None


def test_missing_key_changes_nothing():
    t = tree_of(VIDEO_TREE)
    assert t.delete(99) is False
    assert t.delete(55) is False
    assert keys_inorder(t.root) == [20, 30, 40, 45, 50, 60, 65, 70, 80]
    assert t.size == 9
    assert Tree().delete(1) is False


def test_one_child():
    t = tree_of(VIDEO_TREE)
    assert t.delete(40) is True  # 45 takes its place
    assert keys_inorder(t.root) == [20, 30, 45, 50, 60, 65, 70, 80]
    assert t.root.left.right.key == 45
    assert t.size == 8
    assert t.delete(60) is True  # 65 takes its place
    assert t.root.right.left.key == 65


def test_one_child_at_the_root_re_points_the_root():
    t = tree_of([10, 20, 30])  # a right chain: the root has one child
    assert t.delete(10) is True
    assert t.root.key == 20
    assert keys_inorder(t.root) == [20, 30]
    t = tree_of([10])
    assert t.delete(10) is True
    assert t.root is None and t.size == 0


def test_two_children_uses_the_inorder_successor():
    t = tree_of(VIDEO_TREE)
    assert t.delete(50) is True
    assert t.root.key == 60  # the successor moved up
    assert t.root.right.left.key == 65  # and 65 took the successor's old place
    assert keys_inorder(t.root) == [20, 30, 40, 45, 60, 65, 70, 80]
    assert t.size == 8


def test_two_children_when_the_successor_is_the_right_child():
    t = tree_of([50, 30, 70, 80])  # 70 has one child; delete the root: successor 70 is its right child
    assert t.delete(50) is True
    assert t.root.key == 70
    assert keys_inorder(t.root) == [30, 70, 80]
    assert t.root.right.key == 80


def test_random_deletions_keep_a_bst_and_remove_exactly_that_key():
    rng = random.Random(2)
    for _ in range(40):
        keys = rng.sample(range(500), 60)
        t = tree_of(keys)
        present = sorted(keys)
        for k in rng.sample(range(500), 80):
            expect = k in present
            assert t.delete(k) is expect
            if expect:
                present.remove(k)
            assert keys_inorder(t.root) == present
            assert is_ordered(t.root)
            assert t.size == len(present)


def test_delete_everything():
    rng = random.Random(9)
    keys = rng.sample(range(1000), 200)
    t = tree_of(keys)
    for k in rng.sample(keys, len(keys)):
        assert t.delete(k) is True
    assert t.root is None and t.size == 0


def chain(n):
    t = Tree()
    nodes = [Node(k) for k in range(n)]
    for a, b in zip(nodes, nodes[1:]):
        a.right = b
    t.root, t.size = nodes[0], n
    return t


def test_deep_chain_needs_no_recursion():
    n = 5000
    t = chain(n)
    assert t.delete(n - 1) is True  # the leaf at the bottom
    assert t.delete(n // 2) is True  # one child, in the middle
    assert t.delete(0) is True  # the root
    assert t.size == n - 3
    keys = keys_inorder(t.root)
    assert len(keys) == n - 3 and is_ordered(t.root)
