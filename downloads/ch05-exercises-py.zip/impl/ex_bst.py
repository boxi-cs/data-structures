"""Exercise 7 (implementation): a binary search tree that counts its comparisons.

Do the milestones in order and run the tests after each one.  Use loops, not recursion: the tests build chains
of thousands of nodes (Python's default recursion limit is 1000).

Milestone 1 -- insert(key): add key as a new leaf and return True; if key is already in the tree do nothing and
    return False.  Keep `size` up to date.
Milestone 2 -- contains(key): True / False.
    COUNT COMPARISONS the way the course does: one comparison per node you VISIT (the equality test and the
    smaller/larger decision at that node together count as one), added to self.comparisons by both insert and
    contains.  Inserting into an empty tree makes no comparison.
Milestone 3 -- path(key): the list of keys visited from the root while looking for key (it ends at key if
    present, or at the last node before the empty spot if not).  Then height(): the height in EDGES (empty tree: -1).

Run:  pytest test_ex_bst.py
"""


class Node:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None
        self.size = 0
        self.comparisons = 0

    def insert(self, key):
        raise NotImplementedError

    def contains(self, key):
        raise NotImplementedError

    def path(self, key):
        raise NotImplementedError

    def height(self):
        raise NotImplementedError
