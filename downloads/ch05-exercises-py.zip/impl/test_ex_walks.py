import random

import ex_walks
from ex_walks import Node


def build(spec):
    """Nested tuples (key, left, right); None is the empty tree."""
    if spec is None:
        return None
    key, left, right = spec
    return Node(key, build(left), build(right))


def bst_from(keys):
    root = None
    for key in keys:
        if root is None:
            root = Node(key)
            continue
        node = root
        while True:
            side = "left" if key < node.key else "right"
            child = getattr(node, side)
            if child is None:
                setattr(node, side, Node(key))
                break
            node = child
    return root


def left_chain(n):
    root = None
    for key in range(1, n + 1):
        root = Node(key, left=root)
    return root


EXAMPLE = (50, (30, (20, None, None), (40, None, None)), (70, (60, None, None), (80, None, None)))


def test_iterator_walks_the_example_in_order():
    it = ex_walks.InorderIterator(build(EXAMPLE))
    keys = []
    while it.has_next():
        keys.append(it.next())
    assert keys == [20, 30, 40, 50, 60, 70, 80]


def test_iterator_on_empty_tree():
    it = ex_walks.InorderIterator(None)
    assert not it.has_next()
    assert list(ex_walks.InorderIterator(None)) == []


def test_iterator_yields_sorted_keys_of_random_trees():
    rng = random.Random(7)
    for _ in range(50):
        keys = rng.sample(range(1000), rng.randrange(1, 60))
        assert list(ex_walks.InorderIterator(bst_from(keys))) == sorted(keys)


def test_iterator_stack_never_holds_more_than_height_plus_one_nodes():
    rng = random.Random(11)
    for _ in range(20):
        root = bst_from(rng.sample(range(5000), 300))
        limit = ex_walks.height(root) + 1
        it = ex_walks.InorderIterator(root)
        most = it.stack_size()
        while it.has_next():
            it.next()
            most = max(most, it.stack_size())
        assert most <= limit
        assert it.stack_size() == 0


def test_iterator_does_not_recurse_on_a_very_deep_tree():
    keys = list(ex_walks.InorderIterator(left_chain(50_000)))
    assert keys == list(range(1, 50_001))


def test_height():
    assert ex_walks.height(None) == -1
    assert ex_walks.height(Node(1)) == 0
    assert ex_walks.height(build(EXAMPLE)) == 2
    assert ex_walks.height(build((1, None, (2, None, (3, None, None))))) == 2
    assert ex_walks.height(left_chain(50_000)) == 49_999


def test_is_bst_accepts_valid_trees():
    assert ex_walks.is_bst(None)
    assert ex_walks.is_bst(Node(7))
    assert ex_walks.is_bst(build(EXAMPLE))
    rng = random.Random(3)
    for _ in range(30):
        assert ex_walks.is_bst(bst_from(rng.sample(range(1000), 40)))


def test_is_bst_rejects_a_key_in_the_wrong_subtree():
    # every node is larger than its left child and smaller than its right child, yet 60 sits left of 50
    broken = build((50, (30, None, (60, None, None)), (70, None, None)))
    assert not ex_walks.is_bst(broken)
    # 40 is in the right subtree of 50
    assert not ex_walks.is_bst(build((50, (20, None, None), (70, (40, None, None), (80, None, None)))))


def test_is_bst_rejects_duplicates_and_wrong_order():
    assert not ex_walks.is_bst(build((5, (5, None, None), None)))
    assert not ex_walks.is_bst(build((5, None, (5, None, None))))
    assert not ex_walks.is_bst(build((5, (9, None, None), None)))
