import random

from ex_bst import BST

EXAMPLE_ORDER = [50, 30, 70, 20, 40, 60, 80]


def example():
    t = BST()
    for k in EXAMPLE_ORDER:
        assert t.insert(k) is True
    return t


def test_insert_counts_size_and_ignores_duplicates():
    t = example()
    assert t.size == 7
    assert t.insert(40) is False
    assert t.insert(50) is False
    assert t.size == 7
    assert t.insert(45) is True
    assert t.size == 8


def test_contains():
    t = example()
    for k in EXAMPLE_ORDER:
        assert t.contains(k) is True
    for k in (10, 25, 45, 55, 99):
        assert t.contains(k) is False
    assert BST().contains(1) is False


def test_path_follows_the_search():
    t = example()
    assert t.path(60) == [50, 70, 60]
    assert t.path(50) == [50]
    assert t.path(45) == [50, 30, 40]
    assert t.path(5) == [50, 30, 20]
    assert BST().path(1) == []


def test_comparisons_are_nodes_visited():
    t = example()
    t.comparisons = 0
    assert t.contains(60) is True
    assert t.comparisons == 3
    t.comparisons = 0
    assert t.contains(45) is False
    assert t.comparisons == 3
    t.comparisons = 0
    assert t.contains(50) is True
    assert t.comparisons == 1
    t.comparisons = 0
    assert t.insert(45) is True  # the same walk as the failed search for 45
    assert t.comparisons == 3
    assert t.path(45) == [50, 30, 40, 45]


def test_first_insert_makes_no_comparison():
    t = BST()
    t.insert(5)
    assert t.comparisons == 0


def test_height_in_edges():
    t = BST()
    assert t.height() == -1
    t.insert(1)
    assert t.height() == 0
    t = example()
    assert t.height() == 2
    t.insert(45)
    assert t.height() == 3


def test_random_trees_agree_with_a_set():
    rng = random.Random(5)
    keys = rng.sample(range(10_000), 500)
    t = BST()
    for k in keys:
        t.insert(k)
    assert t.size == 500
    present = set(keys)
    for k in rng.sample(range(10_000), 400):
        assert t.contains(k) is (k in present)
    for k in keys[:50]:
        t.comparisons = 0
        t.contains(k)
        assert t.comparisons == len(t.path(k))


def test_sorted_insertion_is_a_chain_with_n_choose_2_comparisons():
    for n in (1, 2, 10, 200, 3000):
        t = BST()
        for k in range(1, n + 1):
            t.insert(k)
        assert t.height() == n - 1
        assert t.comparisons == n * (n - 1) // 2
        t.comparisons = 0
        assert t.contains(n) is True
        assert t.comparisons == n
