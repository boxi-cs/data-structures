"""Exercise 8 (implementation): delete from a binary search tree.

`Tree.insert` is given.  You write `Tree.delete(key)`: remove key and return True, or return False (and change
nothing) if key is not in the tree.  Keep `size` up to date.  The tree must still be a BST afterwards.

Milestone 1 -- a leaf (and a key that is not there).
Milestone 2 -- a node with ONE child: the child takes its place (the parent's link, or the root, is re-pointed).
Milestone 3 -- a node with TWO children: copy the key of its IN-ORDER SUCCESSOR (the smallest key of its right
    subtree) into the node, then remove the successor node, which has no left child.  The tests expect the
    successor, not the predecessor: deleting 50 from the tree in the video makes 60 the new root.
Milestone 4 (challenge) -- no recursion: delete must work on a chain of 5,000 nodes (Python's recursion limit
    is 1000).  If you wrote a loop with a `parent` variable from the start, this one is free.

Run:  pytest test_ex_delete.py
"""


class Node:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None


class Tree:
    def __init__(self):
        self.root = None
        self.size = 0

    def insert(self, key):
        """Given: add key as a leaf; False if it is already there."""
        if self.root is None:
            self.root = Node(key)
            self.size = 1
            return True
        node = self.root
        while True:
            if key == node.key:
                return False
            side = "left" if key < node.key else "right"
            child = getattr(node, side)
            if child is None:
                setattr(node, side, Node(key))
                self.size += 1
                return True
            node = child

    def delete(self, key):
        raise NotImplementedError
