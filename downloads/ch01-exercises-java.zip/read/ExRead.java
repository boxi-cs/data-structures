import java.util.ArrayList;
import java.util.List;

/**
 * Exercises 9 and 10 (read the code). Each method below came with an AI assistant's complexity claim.
 * The code is correct; the claim is wrong. Say what is wrong and what the real complexity is.
 */
public final class ExRead {
    private ExRead() {}

    /**
     * Returns true if some value appears twice in items.
     *
     * Complexity: O(n). The method makes a single pass over the list, remembers the items it has seen,
     * and stops at the first repeat, exactly like the HashSet-based version.
     */
    public static <T> boolean hasDuplicate(List<T> items) {
        List<T> seen = new ArrayList<>();
        for (T x : items) {
            if (seen.contains(x)) {
                return true;
            }
            seen.add(x);
        }
        return false;
    }

    /**
     * Returns a new list with the items of items in reverse order.
     *
     * Complexity: O(n). One loop over the input, and ArrayList.add is a constant-time operation, so the
     * total is linear.
     */
    public static <T> List<T> reversedCopy(List<T> items) {
        List<T> out = new ArrayList<>();
        for (T x : items) {
            out.add(0, x);
        }
        return out;
    }
}
