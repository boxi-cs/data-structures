import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class ExStepsTest {
    @Test
    void countPairsSmall() {
        long[] expected = {0, 0, 1, 3, 6, 10};
        for (int n = 0; n < expected.length; n++) {
            assertEquals(expected[n], ExSteps.countPairs(n), "n=" + n);
        }
    }

    @Test
    void countPairsMatchesBruteForce() {
        for (int n = 0; n < 30; n++) {
            long brute = 0;
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (i < j) {
                        brute++;
                    }
                }
            }
            assertEquals(brute, ExSteps.countPairs(n), "n=" + n);
        }
    }

    @Test
    void pairsFormulaMatchesCount() {
        for (int n = 0; n < 80; n++) {
            assertEquals(ExSteps.countPairs(n), ExSteps.pairsFormula(n), "n=" + n);
        }
    }

    @Test
    void pairsFormulaDoesNotOverflow() {
        assertEquals(499_999_500_000L, ExSteps.pairsFormula(1_000_000));
    }

    @Test
    void halvingSmall() {
        int[] ns = {1, 2, 3, 4, 7, 8, 1000};
        int[] expected = {0, 1, 1, 2, 2, 3, 9};
        for (int k = 0; k < ns.length; k++) {
            assertEquals(expected[k], ExSteps.countHalving(ns[k]), "n=" + ns[k]);
        }
    }

    @Test
    void halvingFormulaMatchesCount() {
        for (int n = 1; n < 300; n++) {
            assertEquals(ExSteps.countHalving(n), ExSteps.halvingFormula(n), "n=" + n);
        }
        for (int n : new int[] {1 << 20, (1 << 20) + 1, 1_000_000_000, Integer.MAX_VALUE}) {
            assertEquals(ExSteps.countHalving(n), ExSteps.halvingFormula(n), "n=" + n);
        }
    }

    @Test
    void countTripleMatchesBruteForce() {
        for (int n = 0; n < 14; n++) {
            long brute = 0;
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    for (int k = 0; k < n; k++) {
                        if (i <= j && j <= k) {
                            brute++;
                        }
                    }
                }
            }
            assertEquals(brute, ExSteps.countTriple(n), "n=" + n);
        }
    }

    @Test
    void tripleFormulaMatchesCount() {
        for (int n = 0; n < 40; n++) {
            assertEquals(ExSteps.countTriple(n), ExSteps.tripleFormula(n), "n=" + n);
        }
    }
}
