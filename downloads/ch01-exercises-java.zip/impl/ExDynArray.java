import java.util.function.IntUnaryOperator;

/**
 * Exercise 7 (implementation): a dynamic array of ints with a growth policy and a copy counter.
 *
 * The array starts with capacity 1 and size 0. append(x) first makes room if size == capacity: it asks the
 * growth policy for the new capacity, allocates a bigger array and copies the old elements over ONE AT A TIME,
 * adding 1 to copies for every element copied. Then it stores x.
 *
 * Milestone 1: append, so that values are kept and capacity grows.
 * Milestone 2: doubleCap (capacity -> 2 * capacity).
 * Milestone 3: plusOne (capacity -> capacity + 1), the policy that makes appending slow.
 */
public final class ExDynArray {
    private final IntUnaryOperator growth;
    private int[] data = new int[1];
    private int size = 0;
    private long copies = 0; // total number of element copies made by all resizes so far

    public ExDynArray(IntUnaryOperator growth) {
        this.growth = growth;
    }

    public static int doubleCap(int capacity) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static int plusOne(int capacity) {
        throw new UnsupportedOperationException("not implemented");
    }

    public void append(int x) {
        throw new UnsupportedOperationException("not implemented");
    }

    public int size() {
        return size;
    }

    public int capacity() {
        return data.length;
    }

    public long copies() {
        return copies;
    }

    public int get(int i) {
        if (i < 0 || i >= size) {
            throw new IndexOutOfBoundsException(i);
        }
        return data[i];
    }
}
