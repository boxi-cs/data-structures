/**
 * Exercise 6 (implementation): count the steps of a loop, then predict the count with a formula.
 *
 * Milestone 1: countPairs    -- run the two nested loops and count the inner iterations.
 * Milestone 2: pairsFormula  -- the closed form you derived in the lecture, n(n-1)/2.
 * Milestone 3: countHalving / halvingFormula -- a loop whose variable halves each time.
 * Milestone 4: countTriple / tripleFormula   -- three nested loops with i <= j <= k.
 *
 * Counts are long: for n = 1,000,000 the pair count does not fit in an int.
 */
public final class ExSteps {
    private ExSteps() {}

    /** How many times does the inner body run in: for i in 0..n-1, for j in i+1..n-1 ? Write the loops and count. */
    public static long countPairs(int n) {
        throw new UnsupportedOperationException("not implemented");
    }

    /** The closed form for countPairs(n). Mind the overflow: n * (n - 1) overflows an int for large n. */
    public static long pairsFormula(int n) {
        throw new UnsupportedOperationException("not implemented");
    }

    /** How many times does the body of  while (n > 1) { n = n / 2; }  run, for n >= 1? Write the loop and count. */
    public static int countHalving(int n) {
        throw new UnsupportedOperationException("not implemented");
    }

    /** The closed form for countHalving(n), n >= 1: floor(log2 n). Do not use floating point. */
    public static int halvingFormula(int n) {
        throw new UnsupportedOperationException("not implemented");
    }

    /** How many times does the innermost body run in: for i in 0..n-1, for j in i..n-1, for k in j..n-1 ? */
    public static long countTriple(int n) {
        throw new UnsupportedOperationException("not implemented");
    }

    /** The closed form for countTriple(n). */
    public static long tripleFormula(int n) {
        throw new UnsupportedOperationException("not implemented");
    }
}
