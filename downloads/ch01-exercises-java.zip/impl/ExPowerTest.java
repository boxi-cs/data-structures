import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

class ExPowerTest {
    @Test
    void values() {
        for (long x : new long[] {0, 1, 2, 3, 10, -2}) {
            for (int n = 0; n < 40; n++) {
                BigInteger bx = BigInteger.valueOf(x);
                assertEquals(bx.pow(n), ExPower.fastPower(bx, n, null), "x=" + x + " n=" + n);
            }
        }
    }

    @Test
    void bigIntegers() {
        BigInteger seven = BigInteger.valueOf(7);
        assertEquals(seven.pow(1000), ExPower.fastPower(seven, 1000, null));
    }

    @Test
    void invariantHoldsEveryTimeTheHookIsCalled() {
        long[][] cases = {{3, 0}, {3, 1}, {2, 10}, {5, 37}, {7, 1000}};
        for (long[] c : cases) {
            BigInteger x = BigInteger.valueOf(c[0]);
            int n = (int) c[1];
            List<Integer> es = new ArrayList<>();
            ExPower.fastPower(x, n, (result, base, e) -> {
                assertEquals(x.pow(n), result.multiply(base.pow(e)));
                es.add(e);
            });
            assertFalse(es.isEmpty(), "the hook was never called");
            assertEquals(0, es.get(es.size() - 1), "the last call must see e == 0");
        }
    }

    @Test
    void numberOfHookCallsIsLogarithmic() {
        for (int n : new int[] {0, 1, 2, 3, 8, 1000, 1_000_000}) {
            int[] calls = {0};
            ExPower.fastPower(BigInteger.TWO, n, (r, b, e) -> calls[0]++);
            assertEquals(32 - Integer.numberOfLeadingZeros(n) + 1, calls[0], "n=" + n);
        }
    }
}
