import java.math.BigInteger;

/**
 * Exercise 8 (implementation): fast exponentiation with a checked loop invariant.
 *
 * Compute x^n by repeated squaring. Your loop must keep this invariant true every time the loop
 * condition is about to be evaluated (it is the one you designed in Exercise 5):
 *
 *     result * base^e == x^n
 *
 * hook.at(result, base, e) is for the tests: call it (if hook is not null) every time the loop condition
 * is about to be evaluated -- once before the first iteration and once after every iteration, so
 * (number of iterations + 1) times in total.
 *
 * Milestone 1: initialise result, base and e so the invariant holds before the loop.
 * Milestone 2: the loop body keeps it true (think about e even and e odd separately).
 * Milestone 3: stop when e == 0 and return result.
 */
public final class ExPower {
    private ExPower() {}

    public interface Hook {
        void at(BigInteger result, BigInteger base, int e);
    }

    /** x^n for n >= 0 using O(log n) multiplications. Do not call BigInteger.pow. */
    public static BigInteger fastPower(BigInteger x, int n, Hook hook) {
        throw new UnsupportedOperationException("not implemented");
    }
}
