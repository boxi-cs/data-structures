import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.function.IntUnaryOperator;
import org.junit.jupiter.api.Test;

class ExDynArrayTest {
    static ExDynArray filled(IntUnaryOperator growth, int n) {
        ExDynArray a = new ExDynArray(growth);
        for (int i = 0; i < n; i++) {
            a.append(i);
        }
        return a;
    }

    @Test
    void policies() {
        int[] caps = {1, 2, 4, 10};
        int[] doubled = {2, 4, 8, 20};
        int[] plusOne = {2, 3, 5, 11};
        for (int k = 0; k < caps.length; k++) {
            assertEquals(doubled[k], ExDynArray.doubleCap(caps[k]));
            assertEquals(plusOne[k], ExDynArray.plusOne(caps[k]));
        }
    }

    @Test
    void valuesAreKept() {
        for (IntUnaryOperator growth : new IntUnaryOperator[] {ExDynArray::doubleCap, ExDynArray::plusOne}) {
            ExDynArray a = filled(growth, 100);
            assertEquals(100, a.size());
            for (int i = 0; i < 100; i++) {
                assertEquals(i, a.get(i));
            }
        }
    }

    @Test
    void capacitySequenceWithDoubling() {
        ExDynArray a = new ExDynArray(ExDynArray::doubleCap);
        int[] expected = {1, 2, 4, 4, 8, 8, 8, 8, 16};
        for (int i = 0; i < expected.length; i++) {
            a.append(i);
            assertEquals(expected[i], a.capacity(), "after " + (i + 1) + " appends");
        }
    }

    @Test
    void copiesWithDoublingAreLessThan2n() {
        for (int n : new int[] {1, 2, 3, 5, 10, 100, 1000, 12345}) {
            assertTrue(filled(ExDynArray::doubleCap, n).copies() < 2L * n, "n=" + n);
        }
    }

    @Test
    void exactCopiesWithDoubling() {
        // resizes happen at append number 2^j + 1 and copy 2^j elements
        assertEquals(0, filled(ExDynArray::doubleCap, 1).copies());
        assertEquals(1, filled(ExDynArray::doubleCap, 2).copies());
        assertEquals(1 + 2, filled(ExDynArray::doubleCap, 3).copies());
        assertEquals(1 + 2 + 4, filled(ExDynArray::doubleCap, 5).copies());
        assertEquals((1 << 11) - 1, filled(ExDynArray::doubleCap, 1025).copies());
    }

    @Test
    void copiesWithPlusOneAreQuadratic() {
        for (int n : new int[] {1, 2, 10, 100, 500}) {
            assertEquals((long) n * (n - 1) / 2, filled(ExDynArray::plusOne, n).copies(), "n=" + n);
        }
    }

    @Test
    void amortizedCostPerAppendIsAtMost3WithDoubling() {
        int n = 10_000;
        ExDynArray a = filled(ExDynArray::doubleCap, n);
        assertTrue((double) (n + a.copies()) / n <= 3);
    }
}
