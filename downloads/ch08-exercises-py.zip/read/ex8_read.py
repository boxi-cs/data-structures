"""Exercises 9 and 10 (read the code).  Each class below came from an AI assistant together with a claim.

In both exercises the claim is wrong because of a bug.  For each: find a small input that shows the
bug (compare the output of repeated remove_min with sorted()), say what exactly goes wrong and why
small examples do not show it, and write the fix.

Exercise 9:  Heap9  -- "a min-heap in a list, 0-based like heapq; insert and remove_min are correct, O(log n)".
Exercise 10: Heap10 -- "remove_min sinks the new root along the smaller child, so the heap stays a heap".
"""


class Heap9:
    """A min-heap in a Python list, 0-based like heapq.  insert and remove_min are correct and take O(log n)."""

    def __init__(self):
        self.data = []

    def insert(self, x):
        self.data.append(x)
        j = len(self.data) - 1
        while j > 0 and self.data[j] < self.data[(j - 1) // 2]:
            parent = (j - 1) // 2
            self.data[j], self.data[parent] = self.data[parent], self.data[j]
            j = parent

    def remove_min(self):
        smallest = self.data[0]
        last = self.data.pop()
        if self.data:
            self.data[0] = last
            n = len(self.data)
            j = 0
            while 2 * j < n:  # the children of j are 2j and 2j + 1
                small = 2 * j
                if 2 * j + 1 < n and self.data[2 * j + 1] < self.data[small]:
                    small = 2 * j + 1
                if not self.data[small] < self.data[j]:
                    break
                self.data[j], self.data[small] = self.data[small], self.data[j]
                j = small
        return smallest


class Heap10:
    """A min-heap in a Python list, 0-based like heapq.  remove_min sinks the new root along the smaller
    child (it stops when the child is not smaller), so after every call the list is a heap again."""

    def __init__(self):
        self.data = []

    def insert(self, x):
        self.data.append(x)
        j = len(self.data) - 1
        while j > 0 and self.data[j] < self.data[(j - 1) // 2]:
            parent = (j - 1) // 2
            self.data[j], self.data[parent] = self.data[parent], self.data[j]
            j = parent

    def remove_min(self):
        smallest = self.data[0]
        last = self.data.pop()
        if self.data:
            self.data[0] = last
            n = len(self.data)
            j = 0
            while 2 * j + 1 < n:
                child = 2 * j + 1
                if not self.data[child] < self.data[j]:
                    break
                self.data[j], self.data[child] = self.data[child], self.data[j]
                j = child
        return smallest
