"""Exercise 7 (implementation): a priority queue with a custom order and first-in-first-out ties.

Three milestones, in order; run the tests after each one.  You may build on `heapq`: the point of this
exercise is the interface, not another sift-down.

Milestone 1 -- HeapPQ(): insert(priority, value), min() -> (priority, value), remove_min() -> (priority, value),
    len().  The smallest priority comes out first.  Values are never compared (they may be dicts, which
    cannot be compared with <).  min() and remove_min() raise IndexError on an empty queue.
Milestone 2 -- HeapPQ(key=f): the order is given by f(priority) instead of the priority itself, so
    HeapPQ(key=lambda p: -p) hands out the LARGEST priority first (heapq itself only has a min-heap).
Milestone 3 -- ties: entries with equal priority (equal f(priority)) come out in the order they were inserted
    (first in, first out).  heapq does NOT do this for you: with equal priorities it falls through to
    comparing the values, and with a class that only compares priorities the order is arbitrary.
    (Hint: give every entry a counter that breaks ties.)

Run:  pytest test_ex8_pq.py
"""


class HeapPQ:
    def __init__(self, key=None):
        raise NotImplementedError

    def __len__(self):
        raise NotImplementedError

    def insert(self, priority, value):
        raise NotImplementedError

    def min(self):
        raise NotImplementedError

    def remove_min(self):
        raise NotImplementedError
