import random

import pytest

import ex8_heap
from ex8_heap import MinHeap


def is_heap(data):
    return all(data[(j - 1) // 2] <= data[j] for j in range(1, len(data)))


def test_index_formulas():
    assert [ex8_heap.parent(j) for j in range(1, 7)] == [0, 0, 1, 1, 2, 2]
    assert [ex8_heap.left(j) for j in range(4)] == [1, 3, 5, 7]
    assert [ex8_heap.right(j) for j in range(4)] == [2, 4, 6, 8]


def test_the_root_has_no_parent():
    with pytest.raises(ValueError):
        ex8_heap.parent(0)


def test_the_inserts_of_video_2():
    heap = MinHeap()
    expected = [
        (15, [15], 0, 0),
        (9, [9, 15], 1, 1),
        (20, [9, 15, 20], 1, 0),
        (4, [4, 9, 20, 15], 2, 2),
        (12, [4, 9, 20, 15, 12], 1, 0),
        (7, [4, 9, 7, 15, 12, 20], 2, 1),
        (2, [2, 9, 4, 15, 12, 20, 7], 2, 2),
    ]
    for x, data, comparisons, swaps in expected:
        before = (heap.comparisons, heap.swaps)
        heap.insert(x)
        assert heap.data == data
        assert (heap.comparisons - before[0], heap.swaps - before[1]) == (comparisons, swaps)
    assert (heap.comparisons, heap.swaps) == (9, 6)


def test_the_removals_of_video_2():
    heap = MinHeap()
    for x in (15, 9, 20, 4, 12, 7, 2):
        heap.insert(x)
    expected = [
        (2, [4, 9, 7, 15, 12, 20], 3, 1),
        (4, [7, 9, 20, 15, 12], 2, 1),
        (7, [9, 12, 20, 15], 3, 1),
        (9, [12, 15, 20], 2, 1),
        (12, [15, 20], 1, 1),
        (15, [20], 0, 0),
        (20, [], 0, 0),
    ]
    for smallest, data, comparisons, swaps in expected:
        before = (heap.comparisons, heap.swaps)
        assert heap.peek() == smallest
        assert heap.remove_min() == smallest
        assert heap.data == data
        assert (heap.comparisons - before[0], heap.swaps - before[1]) == (comparisons, swaps)


def test_empty_heap_raises():
    heap = MinHeap()
    heap.insert(1)
    heap.remove_min()
    with pytest.raises(IndexError):
        heap.remove_min()
    with pytest.raises(IndexError):
        heap.peek()


def test_random_operations_against_sorted():
    rng = random.Random(2026)
    for _ in range(200):
        heap, reference = MinHeap(), []
        for _ in range(rng.randrange(1, 60)):
            if reference and rng.random() < 0.4:
                assert heap.remove_min() == min(reference)
                reference.remove(min(reference))
            else:
                x = rng.randrange(20)  # many duplicates
                heap.insert(x)
                reference.append(x)
            assert is_heap(heap.data)
            assert len(heap) == len(reference)
        out = []
        while len(heap):
            out.append(heap.remove_min())
        assert out == sorted(reference)


def test_cost_of_increasing_and_decreasing_inserts():
    up = MinHeap()
    for x in range(1000):
        up.insert(x)
    assert (up.comparisons, up.swaps) == (999, 0)  # every new entry is larger than its parent: one comparison, no climb
    down = MinHeap()
    for x in range(1000, 0, -1):
        down.insert(x)
    assert down.comparisons == 7987  # every new entry climbs to the root (video 2, n = 1,000)
