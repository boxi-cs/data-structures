import random

import pytest

from ex8_pq import HeapPQ


def drain(pq):
    out = []
    while len(pq):
        out.append(pq.remove_min())
    return out


def test_smallest_priority_first():
    pq = HeapPQ()
    for priority, name in [(3, "write report"), (1, "fix bug"), (2, "review code")]:
        pq.insert(priority, name)
    assert len(pq) == 3
    assert pq.min() == (1, "fix bug")
    assert len(pq) == 3  # min does not remove
    assert drain(pq) == [(1, "fix bug"), (2, "review code"), (3, "write report")]


def test_values_are_never_compared():
    pq = HeapPQ()
    pq.insert(1, {"job": "a"})
    pq.insert(1, {"job": "b"})  # heapq.heappush(heap, (1, {...})) would raise TypeError here
    pq.insert(0, {"job": "c"})
    assert [value["job"] for _, value in drain(pq)] == ["c", "a", "b"]


def test_empty_queue_raises():
    pq = HeapPQ()
    pq.insert(1, "x")
    pq.remove_min()
    with pytest.raises(IndexError):
        pq.remove_min()
    with pytest.raises(IndexError):
        pq.min()


def test_key_function_gives_a_max_queue():
    pq = HeapPQ(key=lambda p: -p)
    for p in (3, 8, 1, 5):
        pq.insert(p, str(p))
    assert [p for p, _ in drain(pq)] == [8, 5, 3, 1]


def test_key_function_can_order_by_any_property_of_the_priority():
    pq = HeapPQ(key=lambda p: (len(p), p))  # shorter strings first, then alphabetical
    for word in ("pear", "fig", "banana", "kiwi", "apple"):
        pq.insert(word, word.upper())
    assert [p for p, _ in drain(pq)] == ["fig", "kiwi", "pear", "apple", "banana"]


def test_equal_priorities_come_out_first_in_first_out():
    pq = HeapPQ()
    for name in "abcde":
        pq.insert(1, name)
    assert [v for _, v in drain(pq)] == list("abcde")  # heapq with a bare class would give a c e b d


def test_ties_with_interleaved_removals():
    pq = HeapPQ()
    pq.insert(2, "a")
    pq.insert(1, "b")
    pq.insert(2, "c")
    assert pq.remove_min() == (1, "b")
    pq.insert(2, "d")
    pq.insert(1, "e")
    assert [v for _, v in drain(pq)] == ["e", "a", "c", "d"]


def test_ties_also_hold_under_a_key_function():
    pq = HeapPQ(key=lambda p: -p)
    for name in "abc":
        pq.insert(7, name)
    pq.insert(9, "z")
    assert [v for _, v in drain(pq)] == ["z", "a", "b", "c"]


def test_random_operations_against_a_stable_sort():
    rng = random.Random(7)
    for _ in range(100):
        pq, entries = HeapPQ(), []
        for i in range(rng.randrange(1, 80)):
            p = rng.randrange(6)
            pq.insert(p, i)
            entries.append((p, i))
        assert drain(pq) == sorted(entries, key=lambda e: e[0])  # sorted() is stable: ties keep insertion order
