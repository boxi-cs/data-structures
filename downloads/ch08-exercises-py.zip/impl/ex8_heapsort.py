"""Exercise 8 (implementation): heap sort in place.

Three milestones, in order; run the tests after each one.  Everything works on a MAX-heap in the list
a[0:n] (0-based: the children of j are 2j+1 and 2j+2) and every function returns the number of
comparisons it made, counted exactly like the videos:
one comparison between the two children (only when both are inside the heap), then one comparison of the
bigger child with a[j]; the bigger child moves up only if it is STRICTLY larger than a[j].

Milestone 1 -- down_heap(a, j, n): sink a[j] inside the heap a[0:n]; return the comparisons made.
Milestone 2 -- build_max_heap(a): bottom-up construction, in place: down_heap every internal node, the last
    one first (the last internal node is index (len(a) - 2) // 2).  Return the total number of comparisons.
Milestone 3 -- heap_sort(a): build_max_heap, then for end = len(a) - 1 down to 1: swap a[0] and a[end], shrink the
    heap to a[0:end] and sink the new root.  Sort in place, smallest first, with O(1) extra memory (no copy of the
    list, no sorted(), no list.sort()).  Return the total number of comparisons, build phase included.

Run:  pytest test_ex8_heapsort.py
"""


def down_heap(a, j, n):
    raise NotImplementedError


def build_max_heap(a):
    raise NotImplementedError


def heap_sort(a):
    raise NotImplementedError
