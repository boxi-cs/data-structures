"""Exercise 6 (implementation): a binary min-heap stored in a list, 0-based like heapq.

Three milestones, in order; run the tests after each one.

Milestone 1 -- index arithmetic.  For the entry at index j (0-based, the root is at index 0):
    parent(j) = (j - 1) // 2, left(j) = 2*j + 1, right(j) = 2*j + 2.
    The root has no parent: parent(0) must raise ValueError (the formula would give -1 in Python,
    and -1 is a valid list index that silently means "the LAST entry": a classic trap).
Milestone 2 -- insert(x): append x, then climb (up-heap): while x is not at the root and x is smaller
    than its parent, swap them.  Count ONE comparison for every "is x smaller than its parent?" test
    (also the one that stops the climb) in self.comparisons, and one swap for every swap in self.swaps.
Milestone 3 -- remove_min() and peek().  remove_min takes the last entry out of the list, puts it in
    the root (unless the heap is now empty) and sinks it (down-heap): at each step find the smaller
    child (ONE comparison between the two children, only when both exist), then ONE comparison of that
    child with x; if the child is smaller, swap and continue, otherwise stop.  Return the old minimum.
    peek() returns the minimum without changing anything.  Both raise IndexError on an empty heap.

Run:  pytest test_ex8_heap.py
"""


def parent(j):
    raise NotImplementedError


def left(j):
    raise NotImplementedError


def right(j):
    raise NotImplementedError


class MinHeap:
    def __init__(self):
        self.data = []
        self.comparisons = 0
        self.swaps = 0

    def __len__(self):
        return len(self.data)

    def insert(self, x):
        raise NotImplementedError

    def peek(self):
        raise NotImplementedError

    def remove_min(self):
        raise NotImplementedError
