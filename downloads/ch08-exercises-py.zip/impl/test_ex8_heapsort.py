import random
import tracemalloc

from ex8_heapsort import build_max_heap, down_heap, heap_sort

VIDEO = [20, 16, 9, 12, 5, 8, 3, 14, 6, 11]


def is_max_heap(a, n=None):
    n = len(a) if n is None else n
    return all(a[(j - 1) // 2] >= a[j] for j in range(1, n))


def test_down_heap_sinks_one_entry():
    a = [1, 9, 8, 7, 6]
    comparisons = down_heap(a, 0, 5)
    assert a == [9, 7, 8, 1, 6]
    assert comparisons == 4  # 8 vs 9, 9 vs 1, then 6 vs 7, 7 vs 1


def test_down_heap_stops_at_the_end_of_the_heap_part():
    a = [1, 9, 8, 7, 6]
    down_heap(a, 0, 3)  # only a[0:3] is the heap: 7 and 6 are not touched
    assert a == [9, 1, 8, 7, 6]
    b = [5, 9, 3]
    assert down_heap(b, 0, 2) == 1 and b == [9, 5, 3]  # one child only: no comparison between children


def test_ties_do_not_move():
    a = [4, 4, 4]
    assert down_heap(a, 0, 3) == 2
    assert a == [4, 4, 4]


def test_build_max_heap_of_video_4():
    a = list(VIDEO)
    assert build_max_heap(a) == 9
    assert a == [20, 16, 9, 14, 11, 8, 3, 12, 6, 5]


def test_build_makes_a_heap_and_stays_below_2n_comparisons():
    rng = random.Random(1)
    for n in range(0, 200):
        a = [rng.randrange(50) for _ in range(n)]
        comparisons = build_max_heap(a)
        assert is_max_heap(a)
        assert comparisons <= 2 * n


def test_heap_sort_of_video_4():
    a = list(VIDEO)
    assert heap_sort(a) == 35
    assert a == [3, 5, 6, 8, 9, 11, 12, 14, 16, 20]


def test_heap_sort_sorts_like_sorted():
    rng = random.Random(42)
    for n in [0, 1, 2, 3, 4, 5, 10, 31, 32, 33, 100, 1000]:
        for _ in range(20):
            a = [rng.randrange(max(1, n // 2)) for _ in range(n)]  # duplicates
            expected = sorted(a)
            heap_sort(a)
            assert a == expected
    already = list(range(500))
    heap_sort(already)
    assert already == list(range(500))
    backwards = list(range(500, 0, -1))
    heap_sort(backwards)
    assert backwards == list(range(1, 501))


def test_heap_sort_is_in_place():
    a = [random.Random(5).randrange(10**6) for _ in range(20000)]
    same_list = a
    tracemalloc.start()
    heap_sort(a)
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    assert a is same_list and a == sorted(a)
    assert peak < 20_000, f"heap sort allocated {peak} bytes: a copy of the list would take about 160,000"
