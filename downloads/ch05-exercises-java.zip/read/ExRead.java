/**
 * Exercises 9 and 10 (read the code). Each method below came from an AI assistant together with a claim.
 *
 * Exercise 9:  delete is claimed to be correct. It is not. Find the input that breaks it.
 * Exercise 10: contains is claimed to be O(h). It returns the right answers. Is the claim right?
 */
public final class ExRead {
    private ExRead() {}

    public static final class Node {
        public int key;
        public Node left;
        public Node right;

        public Node(int key, Node left, Node right) {
            this.key = key;
            this.left = left;
            this.right = right;
        }
    }

    /**
     * Delete key from the binary search tree rooted at node and return the root of the resulting tree.
     *
     * Correct and O(h): one walk down to the key (it never revisits a node), then the three cases -- no child
     * (the node simply disappears), one child (the child takes its place), two children (the key of the in-order
     * successor moves up and the successor node is removed). The tree is still a BST.
     */
    public static Node delete(Node node, int key) {
        if (node == null) {
            return null;
        }
        if (key < node.key) {
            delete(node.left, key);
            return node;
        }
        if (key > node.key) {
            delete(node.right, key);
            return node;
        }
        if (node.left == null) {
            return node.right;
        }
        if (node.right == null) {
            return node.left;
        }
        Node successor = node.right;
        while (successor.left != null) {
            successor = successor.left;
        }
        node.key = successor.key;
        node.right = delete(node.right, successor.key);
        return node;
    }

    /**
     * True if key is stored in the binary search tree rooted at node.
     *
     * O(h): the search tree property tells us which subtree can hold the key, so the work is proportional to
     * the height of the tree, which is log n for a balanced tree.
     */
    public static boolean contains(Node node, int key) {
        if (node == null) {
            return false;
        }
        if (node.key == key) {
            return true;
        }
        return contains(node.left, key) || contains(node.right, key);
    }
}
