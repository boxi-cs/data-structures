import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import org.junit.jupiter.api.Test;

class ExBstTest {
    static final int[] EXAMPLE_ORDER = {50, 30, 70, 20, 40, 60, 80};

    static ExBst example() {
        ExBst t = new ExBst();
        for (int k : EXAMPLE_ORDER) {
            assertTrue(t.insert(k));
        }
        return t;
    }

    @Test
    void insertCountsSizeAndIgnoresDuplicates() {
        ExBst t = example();
        assertEquals(7, t.size);
        assertFalse(t.insert(40));
        assertFalse(t.insert(50));
        assertEquals(7, t.size);
        assertTrue(t.insert(45));
        assertEquals(8, t.size);
    }

    @Test
    void containsFindsKeysAndOnlyKeys() {
        ExBst t = example();
        for (int k : EXAMPLE_ORDER) {
            assertTrue(t.contains(k));
        }
        for (int k : new int[] {10, 25, 45, 55, 99}) {
            assertFalse(t.contains(k));
        }
        assertFalse(new ExBst().contains(1));
    }

    @Test
    void pathFollowsTheSearch() {
        ExBst t = example();
        assertEquals(List.of(50, 70, 60), t.path(60));
        assertEquals(List.of(50), t.path(50));
        assertEquals(List.of(50, 30, 40), t.path(45));
        assertEquals(List.of(50, 30, 20), t.path(5));
        assertEquals(List.of(), new ExBst().path(1));
    }

    @Test
    void comparisonsAreNodesVisited() {
        ExBst t = example();
        t.comparisons = 0;
        assertTrue(t.contains(60));
        assertEquals(3, t.comparisons);
        t.comparisons = 0;
        assertFalse(t.contains(45));
        assertEquals(3, t.comparisons);
        t.comparisons = 0;
        assertTrue(t.contains(50));
        assertEquals(1, t.comparisons);
        t.comparisons = 0;
        assertTrue(t.insert(45)); // the same walk as the failed search for 45
        assertEquals(3, t.comparisons);
        assertEquals(List.of(50, 30, 40, 45), t.path(45));
    }

    @Test
    void firstInsertMakesNoComparison() {
        ExBst t = new ExBst();
        t.insert(5);
        assertEquals(0, t.comparisons);
    }

    @Test
    void heightInEdges() {
        ExBst t = new ExBst();
        assertEquals(-1, t.height());
        t.insert(1);
        assertEquals(0, t.height());
        t = example();
        assertEquals(2, t.height());
        t.insert(45);
        assertEquals(3, t.height());
    }

    @Test
    void randomTreesAgreeWithASet() {
        Random rng = new Random(5);
        List<Integer> all = new ArrayList<>();
        for (int i = 0; i < 10_000; i++) {
            all.add(i);
        }
        Collections.shuffle(all, rng);
        List<Integer> keys = all.subList(0, 500);
        ExBst t = new ExBst();
        for (int k : keys) {
            t.insert(k);
        }
        assertEquals(500, t.size);
        Set<Integer> present = new HashSet<>(keys);
        for (int i = 0; i < 400; i++) {
            int k = rng.nextInt(10_000);
            assertEquals(present.contains(k), t.contains(k));
        }
        for (int k : keys.subList(0, 50)) {
            t.comparisons = 0;
            t.contains(k);
            assertEquals(t.path(k).size(), t.comparisons);
        }
    }

    @Test
    void sortedInsertionIsAChainWithNChoose2Comparisons() {
        for (int n : new int[] {1, 2, 10, 200, 3000}) {
            ExBst t = new ExBst();
            for (int k = 1; k <= n; k++) {
                t.insert(k);
            }
            assertEquals(n - 1, t.height());
            assertEquals((long) n * (n - 1) / 2, t.comparisons);
            t.comparisons = 0;
            assertTrue(t.contains(n));
            assertEquals(n, t.comparisons);
        }
    }
}
