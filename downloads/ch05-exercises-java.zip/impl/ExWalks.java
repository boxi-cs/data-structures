/**
 * Exercise 6 (implementation): walking a binary tree without recursion.
 *
 * Three milestones, in order; run the tests after each one.
 *
 * Milestone 1 -- InorderIterator: yield the keys of a tree in inorder using an explicit stack (an ArrayDeque)
 *     and no recursion. The constructor pushes the root and every left child below it (the "left spine").
 *     next() pops a node, pushes the left spine of its right child, and returns the popped key.
 *     hasNext() is true while the stack is not empty.
 * Milestone 2 -- height(root): the height in EDGES (empty tree: -1, a single node: 0), computed level by level
 *     with no recursion, so that a chain of 50,000 nodes works.
 * Milestone 3 -- isBst(root): true exactly when every node's key is larger than every key in its left subtree and
 *     smaller than every key in its right subtree (keys are distinct: a repeated key makes it false).
 *     Use your iterator; it is a one-line idea (what does an inorder walk of a BST look like?).
 */
public final class ExWalks {
    private ExWalks() {}

    public static final class Node {
        public final int key;
        public Node left;
        public Node right;

        public Node(int key) {
            this.key = key;
        }

        public Node(int key, Node left, Node right) {
            this.key = key;
            this.left = left;
            this.right = right;
        }
    }

    public static final class InorderIterator {
        public InorderIterator(Node root) {
            throw new UnsupportedOperationException("not implemented");
        }

        public boolean hasNext() {
            throw new UnsupportedOperationException("not implemented");
        }

        public int next() {
            throw new UnsupportedOperationException("not implemented");
        }

        /** How many nodes are on the stack right now (the tests use it to check your memory use). */
        public int stackSize() {
            throw new UnsupportedOperationException("not implemented");
        }
    }

    public static int height(Node root) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static boolean isBst(Node root) {
        throw new UnsupportedOperationException("not implemented");
    }
}
