import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import org.junit.jupiter.api.Test;

class ExWalksTest {
    static ExWalks.Node n(int key, ExWalks.Node left, ExWalks.Node right) {
        return new ExWalks.Node(key, left, right);
    }

    static ExWalks.Node leaf(int key) {
        return new ExWalks.Node(key);
    }

    /** 50 / (30 / (20, 40), 70 / (60, 80)) */
    static ExWalks.Node example() {
        return n(50, n(30, leaf(20), leaf(40)), n(70, leaf(60), leaf(80)));
    }

    static ExWalks.Node bstFrom(List<Integer> keys) {
        ExWalks.Node root = null;
        for (int key : keys) {
            if (root == null) {
                root = leaf(key);
                continue;
            }
            ExWalks.Node node = root;
            while (true) {
                if (key < node.key) {
                    if (node.left == null) {
                        node.left = leaf(key);
                        break;
                    }
                    node = node.left;
                } else {
                    if (node.right == null) {
                        node.right = leaf(key);
                        break;
                    }
                    node = node.right;
                }
            }
        }
        return root;
    }

    static ExWalks.Node leftChain(int n) {
        ExWalks.Node root = null;
        for (int key = 1; key <= n; key++) {
            root = n(key, root, null);
        }
        return root;
    }

    static List<Integer> distinctKeys(Random rng, int bound, int count) {
        List<Integer> all = new ArrayList<>();
        for (int i = 0; i < bound; i++) {
            all.add(i);
        }
        Collections.shuffle(all, rng);
        return new ArrayList<>(all.subList(0, count));
    }

    @Test
    void iteratorWalksTheExampleInOrder() {
        ExWalks.InorderIterator it = new ExWalks.InorderIterator(example());
        List<Integer> keys = new ArrayList<>();
        while (it.hasNext()) {
            keys.add(it.next());
        }
        assertEquals(List.of(20, 30, 40, 50, 60, 70, 80), keys);
    }

    @Test
    void iteratorOnEmptyTree() {
        assertFalse(new ExWalks.InorderIterator(null).hasNext());
    }

    @Test
    void iteratorYieldsSortedKeysOfRandomTrees() {
        Random rng = new Random(7);
        for (int t = 0; t < 50; t++) {
            List<Integer> keys = distinctKeys(rng, 1000, 1 + rng.nextInt(59));
            ExWalks.InorderIterator it = new ExWalks.InorderIterator(bstFrom(keys));
            List<Integer> got = new ArrayList<>();
            while (it.hasNext()) {
                got.add(it.next());
            }
            List<Integer> sorted = new ArrayList<>(keys);
            Collections.sort(sorted);
            assertEquals(sorted, got);
        }
    }

    @Test
    void iteratorStackNeverHoldsMoreThanHeightPlusOneNodes() {
        Random rng = new Random(11);
        for (int t = 0; t < 20; t++) {
            ExWalks.Node root = bstFrom(distinctKeys(rng, 5000, 300));
            int limit = ExWalks.height(root) + 1;
            ExWalks.InorderIterator it = new ExWalks.InorderIterator(root);
            int most = it.stackSize();
            while (it.hasNext()) {
                it.next();
                most = Math.max(most, it.stackSize());
            }
            assertTrue(most <= limit);
            assertEquals(0, it.stackSize());
        }
    }

    @Test
    void iteratorDoesNotRecurseOnAVeryDeepTree() {
        ExWalks.InorderIterator it = new ExWalks.InorderIterator(leftChain(200_000));
        int expected = 1;
        while (it.hasNext()) {
            assertEquals(expected++, it.next());
        }
        assertEquals(200_001, expected);
    }

    @Test
    void heightInEdges() {
        assertEquals(-1, ExWalks.height(null));
        assertEquals(0, ExWalks.height(leaf(1)));
        assertEquals(2, ExWalks.height(example()));
        assertEquals(2, ExWalks.height(n(1, null, n(2, null, leaf(3)))));
        assertEquals(199_999, ExWalks.height(leftChain(200_000)));
    }

    @Test
    void isBstAcceptsValidTrees() {
        assertTrue(ExWalks.isBst(null));
        assertTrue(ExWalks.isBst(leaf(7)));
        assertTrue(ExWalks.isBst(example()));
        Random rng = new Random(3);
        for (int t = 0; t < 30; t++) {
            assertTrue(ExWalks.isBst(bstFrom(distinctKeys(rng, 1000, 40))));
        }
    }

    @Test
    void isBstRejectsAKeyInTheWrongSubtree() {
        // every node is larger than its left child and smaller than its right child, yet 60 sits left of 50
        assertFalse(ExWalks.isBst(n(50, n(30, null, leaf(60)), leaf(70))));
        // 40 is in the right subtree of 50
        assertFalse(ExWalks.isBst(n(50, leaf(20), n(70, leaf(40), leaf(80)))));
    }

    @Test
    void isBstRejectsDuplicatesAndWrongOrder() {
        assertFalse(ExWalks.isBst(n(5, leaf(5), null)));
        assertFalse(ExWalks.isBst(n(5, null, leaf(5))));
        assertFalse(ExWalks.isBst(n(5, leaf(9), null)));
    }
}
