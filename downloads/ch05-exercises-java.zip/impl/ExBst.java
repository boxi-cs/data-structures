import java.util.List;

/**
 * Exercise 7 (implementation): a binary search tree that counts its comparisons.
 *
 * Do the milestones in order and run the tests after each one. Use loops, not recursion: the tests build chains
 * of thousands of nodes.
 *
 * Milestone 1 -- insert(key): add key as a new leaf and return true; if key is already in the tree do nothing and
 *     return false. Keep `size` up to date.
 * Milestone 2 -- contains(key): true / false.
 *     COUNT COMPARISONS the way the course does: one comparison per node you VISIT (the equality test and the
 *     smaller/larger decision at that node together count as one), added to `comparisons` by both insert and
 *     contains. Inserting into an empty tree makes no comparison.
 * Milestone 3 -- path(key): the list of keys visited from the root while looking for key (it ends at key if
 *     present, or at the last node before the empty spot if not). Then height(): the height in EDGES (empty: -1).
 */
public final class ExBst {
    static final class Node {
        final int key;
        Node left;
        Node right;

        Node(int key) {
            this.key = key;
        }
    }

    Node root;
    public int size;
    public long comparisons;

    public boolean insert(int key) {
        throw new UnsupportedOperationException("not implemented");
    }

    public boolean contains(int key) {
        throw new UnsupportedOperationException("not implemented");
    }

    public List<Integer> path(int key) {
        throw new UnsupportedOperationException("not implemented");
    }

    public int height() {
        throw new UnsupportedOperationException("not implemented");
    }
}
