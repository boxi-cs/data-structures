import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.List;
import java.util.Random;
import org.junit.jupiter.api.Test;

class ExDeleteTest {
    static final int[] VIDEO_TREE = {50, 30, 70, 20, 40, 60, 80, 45, 65}; // inorder 20 30 40 45 50 60 65 70 80

    static List<Integer> keysInorder(ExDelete.Node root) {
        List<Integer> out = new ArrayList<>();
        Deque<ExDelete.Node> stack = new ArrayDeque<>();
        ExDelete.Node node = root;
        while (!stack.isEmpty() || node != null) {
            while (node != null) {
                stack.push(node);
                node = node.left;
            }
            node = stack.pop();
            out.add(node.key);
            node = node.right;
        }
        return out;
    }

    static boolean isOrdered(ExDelete.Node root) {
        List<Integer> keys = keysInorder(root);
        for (int i = 1; i < keys.size(); i++) {
            if (keys.get(i - 1) >= keys.get(i)) {
                return false;
            }
        }
        return true;
    }

    static ExDelete treeOf(int... keys) {
        ExDelete t = new ExDelete();
        for (int k : keys) {
            t.insert(k);
        }
        return t;
    }

    @Test
    void leaf() {
        ExDelete t = treeOf(VIDEO_TREE);
        assertTrue(t.delete(20));
        assertEquals(List.of(30, 40, 45, 50, 60, 65, 70, 80), keysInorder(t.root));
        assertEquals(8, t.size);
        assertNull(t.root.left.left);
    }

    @Test
    void missingKeyChangesNothing() {
        ExDelete t = treeOf(VIDEO_TREE);
        assertFalse(t.delete(99));
        assertFalse(t.delete(55));
        assertEquals(List.of(20, 30, 40, 45, 50, 60, 65, 70, 80), keysInorder(t.root));
        assertEquals(9, t.size);
        assertFalse(new ExDelete().delete(1));
    }

    @Test
    void oneChild() {
        ExDelete t = treeOf(VIDEO_TREE);
        assertTrue(t.delete(40)); // 45 takes its place
        assertEquals(List.of(20, 30, 45, 50, 60, 65, 70, 80), keysInorder(t.root));
        assertEquals(45, t.root.left.right.key);
        assertEquals(8, t.size);
        assertTrue(t.delete(60)); // 65 takes its place
        assertEquals(65, t.root.right.left.key);
    }

    @Test
    void oneChildAtTheRootRePointsTheRoot() {
        ExDelete t = treeOf(10, 20, 30); // a right chain: the root has one child
        assertTrue(t.delete(10));
        assertEquals(20, t.root.key);
        assertEquals(List.of(20, 30), keysInorder(t.root));
        t = treeOf(10);
        assertTrue(t.delete(10));
        assertNull(t.root);
        assertEquals(0, t.size);
    }

    @Test
    void twoChildrenUsesTheInorderSuccessor() {
        ExDelete t = treeOf(VIDEO_TREE);
        assertTrue(t.delete(50));
        assertEquals(60, t.root.key); // the successor moved up
        assertEquals(65, t.root.right.left.key); // and 65 took the successor's old place
        assertEquals(List.of(20, 30, 40, 45, 60, 65, 70, 80), keysInorder(t.root));
        assertEquals(8, t.size);
    }

    @Test
    void twoChildrenWhenTheSuccessorIsTheRightChild() {
        ExDelete t = treeOf(50, 30, 70, 80); // delete the root: the successor 70 is its right child
        assertTrue(t.delete(50));
        assertEquals(70, t.root.key);
        assertEquals(List.of(30, 70, 80), keysInorder(t.root));
        assertEquals(80, t.root.right.key);
    }

    @Test
    void randomDeletionsKeepABstAndRemoveExactlyThatKey() {
        Random rng = new Random(2);
        for (int round = 0; round < 40; round++) {
            List<Integer> pool = new ArrayList<>();
            for (int i = 0; i < 500; i++) {
                pool.add(i);
            }
            Collections.shuffle(pool, rng);
            ExDelete t = new ExDelete();
            List<Integer> present = new ArrayList<>(pool.subList(0, 60));
            for (int k : present) {
                t.insert(k);
            }
            Collections.sort(present);
            for (int i = 0; i < 80; i++) {
                int k = rng.nextInt(500);
                boolean expect = present.contains(k);
                assertEquals(expect, t.delete(k));
                if (expect) {
                    present.remove(Integer.valueOf(k));
                }
                assertEquals(present, keysInorder(t.root));
                assertTrue(isOrdered(t.root));
                assertEquals(present.size(), t.size);
            }
        }
    }

    @Test
    void deleteEverything() {
        Random rng = new Random(9);
        List<Integer> keys = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            keys.add(i);
        }
        Collections.shuffle(keys, rng);
        keys = new ArrayList<>(keys.subList(0, 200));
        ExDelete t = new ExDelete();
        for (int k : keys) {
            t.insert(k);
        }
        Collections.shuffle(keys, rng);
        for (int k : keys) {
            assertTrue(t.delete(k));
        }
        assertNull(t.root);
        assertEquals(0, t.size);
    }

    @Test
    void deepChainNeedsNoRecursion() {
        int n = 200_000;
        ExDelete.Node[] nodes = new ExDelete.Node[n];
        for (int i = 0; i < n; i++) {
            nodes[i] = new ExDelete.Node(i);
        }
        for (int i = 0; i + 1 < n; i++) {
            nodes[i].right = nodes[i + 1];
        }
        ExDelete t = new ExDelete();
        t.root = nodes[0];
        t.size = n;
        assertTrue(t.delete(n - 1)); // the leaf at the bottom
        assertTrue(t.delete(n / 2)); // one child, in the middle
        assertTrue(t.delete(0)); // the root
        assertEquals(n - 3, t.size);
        List<Integer> keys = keysInorder(t.root);
        assertEquals(n - 3, keys.size());
        assertTrue(isOrdered(t.root));
    }
}
