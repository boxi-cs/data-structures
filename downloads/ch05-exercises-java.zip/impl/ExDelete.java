/**
 * Exercise 8 (implementation): delete from a binary search tree.
 *
 * insert(key) is given. You write delete(key): remove key and return true, or return false (and change nothing)
 * if key is not in the tree. Keep `size` up to date. The tree must still be a BST afterwards.
 *
 * Milestone 1 -- a leaf (and a key that is not there).
 * Milestone 2 -- a node with ONE child: the child takes its place (the parent's link, or the root, is re-pointed).
 * Milestone 3 -- a node with TWO children: copy the key of its IN-ORDER SUCCESSOR (the smallest key of its right
 *     subtree) into the node, then remove the successor node, which has no left child. The tests expect the
 *     successor, not the predecessor: deleting 50 from the tree in the video makes 60 the new root.
 * Milestone 4 (challenge) -- no recursion: delete must work on a chain of 200,000 nodes (the Java call stack
 *     holds only a few thousand frames). If you wrote a loop with a `parent` variable from the start, this one is free.
 */
public final class ExDelete {
    public static final class Node {
        public int key;
        public Node left;
        public Node right;

        public Node(int key) {
            this.key = key;
        }
    }

    public Node root;
    public int size;

    /** Given: add key as a leaf; false if it is already there. */
    public boolean insert(int key) {
        if (root == null) {
            root = new Node(key);
            size = 1;
            return true;
        }
        Node node = root;
        while (true) {
            if (key == node.key) {
                return false;
            }
            if (key < node.key) {
                if (node.left == null) {
                    node.left = new Node(key);
                    size++;
                    return true;
                }
                node = node.left;
            } else {
                if (node.right == null) {
                    node.right = new Node(key);
                    size++;
                    return true;
                }
                node = node.right;
            }
        }
    }

    public boolean delete(int key) {
        throw new UnsupportedOperationException("not implemented");
    }
}
