"""Exercises 9 and 10 (read the code).  Each class below came from an AI assistant together with a claim.

In both exercises the claim is wrong because of a bug.  For each: find a small input that shows the bug, say what
exactly goes wrong and why the usual quick test does not show it, and write the fix.

Exercise 9:  Reading   -- "a sensor reading for use as a dictionary key; two readings with the same temperature
                            are equal and are the same key".
Exercise 10: Probe10   -- "open addressing with linear probing and tombstones; put, get and remove always
                            terminate and take O(1) on average".
"""


class Reading:
    """A sensor reading.  Two readings with the same temperature are equal and are the same dictionary key."""

    def __init__(self, number, temperature):
        self.number = number              # which reading it was: 1, 2, 3, ...
        self.temperature = temperature

    def __eq__(self, other):
        return isinstance(other, Reading) and self.temperature == other.temperature

    def __hash__(self):
        return hash((self.number, self.temperature))

    def __repr__(self):
        return f"Reading({self.number}, {self.temperature})"


EMPTY = object()
DELETED = object()   # tombstone


class Probe10:
    """Open addressing with linear probing and tombstones, int keys.  put, get and remove always terminate
    and take O(1) on average."""

    def __init__(self, capacity=13):
        self.keys = [EMPTY] * capacity
        self.values = [None] * capacity
        self.size = 0

    def _next(self, i):
        return (i + 1) % len(self.keys)

    def _find(self, key):
        """The slot where the key is, or the first EMPTY slot of its probe sequence."""
        i = key % len(self.keys)
        while self.keys[i] is not EMPTY and self.keys[i] != key:    # a tombstone is not equal to any key
            i = self._next(i)
        return i

    def get(self, key, default=None):
        i = self._find(key)
        return self.values[i] if self.keys[i] is not EMPTY else default

    def put(self, key, value):
        i = self._find(key)
        old = self.values[i] if self.keys[i] is not EMPTY else None
        if self.keys[i] is EMPTY:
            self.size += 1
        self.keys[i], self.values[i] = key, value
        return old

    def remove(self, key):
        i = self._find(key)
        if self.keys[i] is EMPTY:
            raise KeyError(key)
        value = self.values[i]
        self.keys[i], self.values[i] = DELETED, None
        self.size -= 1
        return value
