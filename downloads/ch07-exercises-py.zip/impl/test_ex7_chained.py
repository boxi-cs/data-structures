import random

import pytest

from ex7_chained import ChainedMap

VIDEO_KEYS = [12, 44, 13, 88, 23, 94, 11, 39, 20, 16]


def video_map():
    table = ChainedMap(7, max_load=None)
    for k in VIDEO_KEYS:
        table.put(k, str(k))
    return table


def test_the_chains_of_video_2():
    table = video_map()
    assert len(table) == 10
    assert [[e[0] for e in b] for b in table.buckets] == [[], [], [44, 23, 16], [94], [88, 11, 39], [12], [13, 20]]
    assert table.keys() == [44, 23, 16, 94, 88, 11, 39, 12, 13, 20]


def test_put_returns_the_old_value_and_does_not_grow():
    table = ChainedMap(7, max_load=None)
    assert table.put(5, "a") is None
    assert table.put(12, "b") is None          # 12 % 7 = 5, the same chain
    assert table.put(5, "c") == "a"
    assert len(table) == 2
    assert table.get(5) == "c" and table.get(12) == "b"
    assert [e[0] for e in table.buckets[5]] == [5, 12]   # the position of 5 did not change


def test_comparisons_of_video_2():
    table = video_map()
    assert table.get(12) == "12" and table.last_comparisons == 1
    assert table.get(16) == "16" and table.last_comparisons == 3
    assert table.get(9) is None and table.last_comparisons == 3
    assert table.get(9, "none") == "none"
    assert table.get(0) is None and table.last_comparisons == 0     # an empty chain: nothing to compare
    total = 0
    for k in VIDEO_KEYS:
        table.get(k)
        total += table.last_comparisons
    assert total == 17          # 1.70 on average, the number of video 2


def test_negative_keys_use_a_valid_bucket():
    table = ChainedMap(7, max_load=None)
    table.put(-3, "x")
    assert [e[0] for e in table.buckets[4]] == [-3]      # -3 % 7 is 4 in Python
    assert table.get(-3) == "x"


def test_remove():
    table = video_map()
    assert table.remove(23) == "23"
    assert len(table) == 9
    assert table.keys() == [44, 16, 94, 88, 11, 39, 12, 13, 20]
    assert table.last_comparisons == 2
    assert table.get(23) is None
    with pytest.raises(KeyError):
        table.remove(23)
    assert table.last_comparisons == 2          # the chain of bucket 2 now has two keys
    with pytest.raises(KeyError):
        table.remove(1)                          # an empty chain
    assert len(table) == 9


def test_rehashing_1000_puts_like_video_4():
    table = ChainedMap(7, max_load=0.75)
    for k in range(1000):
        table.put(k, k)
    assert table.capacities == [7, 17, 37, 79, 163, 331, 673, 1361]
    assert table.moves == 984
    assert len(table) == 1000
    assert round(len(table) / table.capacity, 2) == 0.73
    assert all(table.get(k) == k for k in range(1000))


def test_the_first_rehash_happens_when_the_sixth_entry_arrives():
    table = ChainedMap(7, max_load=0.75)
    for k in range(5):
        table.put(k, k)
    assert table.capacity == 7 and table.moves == 0     # 5 > 0.75 * 7 = 5.25 is false
    table.put(5, 5)
    assert table.capacity == 17 and table.moves == 6
    # the entries moved to the new buckets: 5 % 17 = 5, not 5 % 7
    assert [e[0] for e in table.buckets[5]] == [5]
    table.put(5, "again")                                 # an update must not rehash
    assert table.capacity == 17 and table.moves == 6


def test_no_rehash_without_max_load():
    table = ChainedMap(7, max_load=None)
    for k in range(100):
        table.put(k, k)
    assert table.capacity == 7 and table.moves == 0
    assert max(len(b) for b in table.buckets) in (14, 15)


def test_random_operations_match_a_dict():
    rng = random.Random(7)
    table, model = ChainedMap(7, max_load=0.75), {}
    for _ in range(4000):
        k = rng.randrange(-60, 60)
        op = rng.random()
        if op < 0.5:
            v = rng.randrange(1000)
            assert table.put(k, v) == model.get(k)
            model[k] = v
        elif op < 0.8:
            assert table.get(k) == model.get(k)
        elif k in model:
            assert table.remove(k) == model.pop(k)
        else:
            with pytest.raises(KeyError):
                table.remove(k)
        assert len(table) == len(model)
    assert sorted(table.keys()) == sorted(model)
