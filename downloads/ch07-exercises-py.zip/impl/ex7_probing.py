"""Exercise 8 (implementation): open addressing with linear probing and tombstones, integer keys, fixed capacity.

Three milestones, in order; run the tests after each one.

The hash code of an int key is the key itself.  The i-th slot probed for a key is  (key % capacity + i) % capacity
for i = 0, 1, 2, ...  (video 3).  A slot is EMPTY (never used), DELETED (a tombstone) or holds a [key, value] pair.
self.probes is the list of slots probed by the last operation, in order.

Milestone 1 -- put and get, no deletions yet.
    put(key, value): probe until the key is found (replace its value, return the old one) or an EMPTY slot is
    reached (store [key, value] there, size += 1, return None).  get(key, default=None) probes the same way and
    returns the value or default.  Probe at most `capacity` slots: when no slot is EMPTY and the key is not found,
    get returns default, and put raises RuntimeError("table full") if the key is new and no slot can take it.
    cells() returns the table as a list: '-' for an EMPTY slot, 'x' for a tombstone, the key otherwise.
    In the table of video 3 (13 slots, keys 18, 41, 22, 44, 59, 32, 31, 73 in this order) the probes are
    [5] [2] [9] [5, 6] [7] [6, 7, 8] [5, 6, 7, 8, 9, 10] [8, 9, 10, 11]  (19 probes for the eight puts).
Milestone 2 -- remove(key) with a TOMBSTONE: turn the slot of the key into DELETED (tombstones += 1, size -= 1) and
    return its value; raise KeyError if the key is missing.  The probe loops must now SKIP tombstones (a tombstone
    never stops a search and never equals a key): after removing 44, get(32) must still find 32 with probes
    [6, 7, 8].
Milestone 3 -- reuse tombstones.  A put of a NEW key still probes until an EMPTY slot (to be sure the key is not
    further along), but then stores the entry in the FIRST tombstone met on the way (tombstones -= 1) and only
    otherwise in the EMPTY slot.  A table with no EMPTY slot at all (every slot an entry or a tombstone) must still
    answer: get of a missing key probes `capacity` slots and returns default, and put of a new key uses a tombstone.

Run:  pytest test_ex7_probing.py
"""

EMPTY = object()
DELETED = object()


class LinearProbingMap:
    def __init__(self, capacity=13):
        self.capacity = capacity
        self.slots = [EMPTY] * capacity      # EMPTY, DELETED or [key, value]
        self.size = 0
        self.tombstones = 0
        self.probes = []

    def __len__(self):
        return self.size

    def put(self, key, value):
        raise NotImplementedError

    def get(self, key, default=None):
        raise NotImplementedError

    def remove(self, key):
        raise NotImplementedError

    def cells(self):
        raise NotImplementedError
