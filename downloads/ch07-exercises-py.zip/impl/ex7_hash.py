"""Exercise 6 (implementation): hash codes, compression and a look at how well a hash spreads keys.

Three milestones, in order; run the tests after each one.

Milestone 1 -- the polynomial string hash of video 1.
    to_int32(x) wraps any integer to a signed 32-bit value (Python integers never overflow, Java ints do):
        the result is in -2**31 ... 2**31 - 1 and equals x modulo 2**32.
    poly_hash(s, base=31) is h = s[0]*base**(n-1) + s[1]*base**(n-2) + ... + s[n-1] with every character taken as
        its code ord(ch), computed by the loop  h = to_int32(base * h + ord(ch))  so that for base 31 it equals
        Java's String.hashCode.  The empty string has hash code 0.
Milestone 2 -- compression and primes.
    compress(h, m) maps a hash code (it may be negative) to a table index 0 ... m - 1.
    next_prime(n) is the smallest prime >= n (use is_prime, which you also write).
Milestone 3 -- measure a hash function.
    bucket_stats(keys, hash_fn, m) puts every key in the bucket compress(hash_fn(key), m) and returns the tuple
        (distinct, longest, empty): the number of distinct hash codes, the length of the longest bucket and the
        number of empty buckets.  The tests repeat the experiment of video 1 on the 720 anagrams of "abcdef".

Run:  pytest test_ex7_hash.py
"""


def to_int32(x):
    raise NotImplementedError


def poly_hash(s, base=31):
    raise NotImplementedError


def sum_hash(s):
    """The bad hash of video 1 (given): add up the character codes."""
    return sum(ord(ch) for ch in s)


def compress(h, m):
    raise NotImplementedError


def is_prime(n):
    raise NotImplementedError


def next_prime(n):
    raise NotImplementedError


def bucket_stats(keys, hash_fn, m):
    raise NotImplementedError
