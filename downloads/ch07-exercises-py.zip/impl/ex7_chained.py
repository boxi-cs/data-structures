"""Exercise 7 (implementation): a hash map with separate chaining and rehashing, integer keys.

Three milestones, in order; run the tests after each one.

The hash code of an int key is the key itself and the bucket is  key % capacity  (Python's % is never
negative).  Every bucket is a list of [key, value] entries in insertion order; a new key is APPENDED to its chain.

Milestone 1 -- put and get.
    put(key, value): if the key is in its chain, replace the value and return the OLD value (the size does not
    change); otherwise append [key, value] to the chain, increase the size and return None.
    get(key, default=None): the value of the key, or default.
    Both set self.last_comparisons to the number of keys compared while walking the chain: when the key is found at
    position p of the chain (0-based) that is p + 1; when it is not in the chain it is the length of the chain.
    (video 2: get(12) = 1, get(16) = 3 and get(9) = 3 in the map of the video.)
    __len__ is the number of entries; keys() lists the keys bucket by bucket, each chain in order, for the tests.
Milestone 2 -- remove(key): delete the entry and return its value; raise KeyError if the key is missing (and set
    last_comparisons as for get).
Milestone 3 -- rehashing.  After a put that ADDED an entry, if max_load is not None and size > max_load * capacity,
    build a new table of next_prime(2 * capacity) buckets and insert every entry again (walk the old buckets in
    order, each chain in order, and append each entry to its new chain).  Count the entries re-inserted in
    self.moves (all rehashes together) and record every new capacity in self.capacities (starting with the
    initial one).  max_load=None never rehashes.

Run:  pytest test_ex7_chained.py
"""


def is_prime(n):
    """Given."""
    if n < 2:
        return False
    d = 2
    while d * d <= n:
        if n % d == 0:
            return False
        d += 1
    return True


def next_prime(n):
    """Given: the smallest prime >= n."""
    while not is_prime(n):
        n += 1
    return n


class ChainedMap:
    def __init__(self, capacity=7, max_load=0.75):
        self.capacity = capacity
        self.max_load = max_load
        self.buckets = [[] for _ in range(capacity)]
        self.size = 0
        self.moves = 0
        self.capacities = [capacity]
        self.last_comparisons = 0

    def __len__(self):
        return self.size

    def put(self, key, value):
        raise NotImplementedError

    def get(self, key, default=None):
        raise NotImplementedError

    def remove(self, key):
        raise NotImplementedError

    def keys(self):
        raise NotImplementedError
