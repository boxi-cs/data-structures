import random

import pytest

from ex7_probing import LinearProbingMap

VIDEO_KEYS = [18, 41, 22, 44, 59, 32, 31, 73]


def video_table():
    table = LinearProbingMap(13)
    probes = []
    for k in VIDEO_KEYS:
        table.put(k, str(k))
        probes.append(table.probes)
    return table, probes


def test_the_table_of_video_3():
    table, probes = video_table()
    assert probes == [[5], [2], [9], [5, 6], [7], [6, 7, 8], [5, 6, 7, 8, 9, 10], [8, 9, 10, 11]]
    assert sum(len(p) for p in probes) == 19
    assert table.cells() == ["-", "-", 41, "-", "-", 18, 44, 59, 32, 22, 31, 73, "-"]
    assert len(table) == 8


def test_get_and_update():
    table, _ = video_table()
    assert table.get(32) == "32" and table.probes == [6, 7, 8]
    assert table.get(99) is None and table.probes == [8, 9, 10, 11, 12]      # 99 % 13 = 8, stops at the empty slot 12
    assert table.get(99, "none") == "none"
    assert table.put(32, "new") == "32"
    assert table.get(32) == "new" and len(table) == 8


def test_wrapping_around_the_end():
    table = LinearProbingMap(5)
    table.put(4, "a")
    table.put(9, "b")                   # 9 % 5 = 4: probes 4, then wraps to 0
    assert table.probes == [4, 0]
    assert table.cells() == [9, "-", "-", "-", 4]
    assert table.get(14) is None and table.probes == [4, 0, 1]


def test_a_full_table():
    table = LinearProbingMap(4)
    for k in (0, 1, 2, 3):
        table.put(k, k)
    assert table.get(7) is None and table.probes == [3, 0, 1, 2]            # no empty slot: stop after `capacity` probes
    assert table.get(2) == 2
    with pytest.raises(RuntimeError):
        table.put(7, "x")
    assert table.put(2, "updated") == 2                                      # an existing key still works
    assert len(table) == 4


def test_remove_leaves_a_tombstone_and_get_skips_it():
    table, _ = video_table()
    assert table.remove(44) == "44"
    assert table.cells() == ["-", "-", 41, "-", "-", 18, "x", 59, 32, 22, 31, 73, "-"]
    assert len(table) == 7 and table.tombstones == 1
    assert table.get(32) == "32" and table.probes == [6, 7, 8]               # still found, past the tombstone
    assert table.get(44) is None and table.probes == [5, 6, 7, 8, 9, 10, 11, 12]
    with pytest.raises(KeyError):
        table.remove(44)
    with pytest.raises(KeyError):
        table.remove(100)
    assert table.tombstones == 1


def test_a_new_key_reuses_the_first_tombstone():
    table, _ = video_table()
    table.remove(44)
    assert table.put(57, "57") is None          # 57 % 13 = 5
    assert table.probes == [5, 6, 7, 8, 9, 10, 11, 12]     # probes to the empty slot 12 ...
    assert table.cells() == ["-", "-", 41, "-", "-", 18, 57, 59, 32, 22, 31, 73, "-"]      # ... but is stored in the tombstone
    assert table.tombstones == 0 and len(table) == 8


def test_an_existing_key_behind_a_tombstone_is_updated_not_duplicated():
    table, _ = video_table()
    table.remove(44)
    assert table.put(32, "again") == "32"        # 32 lives past the tombstone at 6
    assert table.cells()[6] == "x" and table.cells()[8] == 32
    assert len(table) == 7


def test_a_table_without_empty_slots_still_answers():
    table = LinearProbingMap(5)
    for k in range(5):
        table.put(k, k)
    for k in range(5):
        table.remove(k)                          # five tombstones, no EMPTY slot, no entries
    assert table.cells() == ["x"] * 5 and len(table) == 0
    assert table.get(7) is None and table.probes == [2, 3, 4, 0, 1]
    assert table.put(7, "seven") is None
    assert table.cells() == ["x", "x", 7, "x", "x"] and table.tombstones == 4
    assert table.get(7) == "seven"


def test_random_operations_match_a_dict():
    rng = random.Random(11)
    table, model = LinearProbingMap(13), {}
    for _ in range(5000):
        k = rng.randrange(40)
        op = rng.random()
        if op < 0.45:
            if k in model or len(model) + table.tombstones < 13 or table.tombstones > 0:
                assert table.put(k, k * 10) == model.get(k)
                model[k] = k * 10
        elif op < 0.75:
            assert table.get(k) == model.get(k)
        elif k in model:
            assert table.remove(k) == model.pop(k)
        else:
            with pytest.raises(KeyError):
                table.remove(k)
        assert len(table) == len(model)
    assert sorted(c for c in table.cells() if c not in ("-", "x")) == sorted(model)
