import itertools

import pytest

import ex7_hash
from ex7_hash import bucket_stats, compress, next_prime, poly_hash, sum_hash, to_int32


def reference(s, base=31):
    """The same hash with exact integers: the full polynomial, then wrapped once at the end."""
    total = 0
    for ch in s:
        total = total * base + ord(ch)
    total %= 1 << 32
    return total - (1 << 32) if total >= 1 << 31 else total


def test_to_int32_wraps_like_java():
    assert to_int32(0) == 0
    assert to_int32(2**31 - 1) == 2**31 - 1
    assert to_int32(2**31) == -(2**31)
    assert to_int32(2**32) == 0
    assert to_int32(-1) == -1
    assert to_int32(-(2**31) - 1) == 2**31 - 1
    assert to_int32(3 * 2**32 + 5) == 5


def test_the_numbers_of_video_1():
    assert poly_hash("hello") == 99162322
    assert poly_hash("stop") == 3540994
    assert poly_hash("pots") == 3446974
    assert poly_hash("Aa") == 2112 == poly_hash("BB")
    assert poly_hash("") == 0
    assert sum_hash("stop") == 454 == sum_hash("pots")


def test_the_most_negative_int():
    assert poly_hash("polygenelubricants") == -2147483648


def test_matches_the_exact_polynomial_for_any_base():
    for s in ("a", "ab", "hello world, this is a long enough string to overflow 32 bits many times", "zzzzzzzzzzzz"):
        for base in (31, 33, 131, 65599):
            assert poly_hash(s, base) == reference(s, base)


def test_compress_is_never_negative():
    assert compress(99162322, 13) == 12
    assert compress(-3, 7) == 4
    assert compress(-(2**31), 10) == 2
    for h in (-100, -1, 0, 1, 100, 2**31 - 1):
        for m in (1, 2, 7, 13, 1009):
            assert 0 <= compress(h, m) < m


def test_primes():
    assert [p for p in range(2, 40) if ex7_hash.is_prime(p)] == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]
    assert not ex7_hash.is_prime(1) and not ex7_hash.is_prime(0) and not ex7_hash.is_prime(-7)
    assert next_prime(14) == 17
    assert next_prime(17) == 17
    assert next_prime(2 * 7) == 17
    assert next_prime(2 * 673) == 1361
    assert next_prime(1) == 2


def anagrams():
    return ["".join(p) for p in itertools.permutations("abcdef")]


def test_bucket_stats_small():
    assert bucket_stats(["a", "b", "c"], lambda k: 0, 5) == (1, 3, 4)
    assert bucket_stats(["a", "b", "c"], lambda k: ord(k), 3) == (3, 1, 0)


def test_anagrams_with_the_bad_hash():
    keys = anagrams()
    assert len(keys) == 720
    assert bucket_stats(keys, sum_hash, 1009) == (1, 720, 1008)


def test_anagrams_with_the_polynomial_hash():
    assert bucket_stats(anagrams(), poly_hash, 1009) == (720, 4, 514)
