Chapter 7 exercises (Python)

Templates for the implementation exercises are in impl/, the read-the-code snippets in read/.
Every test in impl/ fails until you finish the milestones.

    pip install pytest
    cd impl && pytest -q
