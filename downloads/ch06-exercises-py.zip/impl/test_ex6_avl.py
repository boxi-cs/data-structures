import math
import random

import ex6_avl as avl
from ex6_avl import Node


def mk(key, left=None, right=None):
    """A node with the correct height field, computed here (not with your update)."""
    n = Node(key)
    n.left, n.right = left, right
    n.height = 1 + max(left.height if left else 0, right.height if right else 0)
    return n


def shape(n):
    if n is None:
        return "-"
    if n.left is None and n.right is None:
        return str(n.key)
    return f"{n.key}({shape(n.left)},{shape(n.right)})"


def true_height(n):
    return 0 if n is None else 1 + max(true_height(n.left), true_height(n.right))


def inorder(n):
    return [] if n is None else inorder(n.left) + [n.key] + inorder(n.right)


def check_avl(n):
    """Stored heights are right and every balance factor is -1, 0 or 1."""
    if n is None:
        return
    assert n.height == true_height(n), f"stored height of {n.key} is wrong"
    assert abs(true_height(n.right) - true_height(n.left)) <= 1, f"unbalanced at {n.key}"
    check_avl(n.left)
    check_avl(n.right)


def build(keys):
    root = None
    for k in keys:
        root = avl.insert(root, k)
    return root


def test_height_and_balance():
    assert avl.height(None) == 0
    leaf = mk(5)
    assert avl.height(leaf) == 1 and avl.balance(leaf) == 0
    n = mk(10, mk(5), mk(20, None, mk(30)))
    assert avl.height(n) == 3
    assert avl.balance(n) == 1  # right (2) minus left (1)
    assert avl.balance(mk(10, mk(5, mk(2)), None)) == -2


def test_update_recomputes_the_height_from_the_children():
    n = Node(10)
    n.left, n.right = mk(5, mk(2)), mk(20)
    avl.update(n)
    assert n.height == 3
    n.left = None
    avl.update(n)
    assert n.height == 2


def test_rebalance_leaves_a_balanced_node_alone():
    n = mk(10, mk(5), mk(20))
    assert avl.rebalance(n) is n and shape(n) == "10(5,20)"


def test_the_four_cases():
    cases = [
        ("left-left", [30, 20, 10], "30(20(10,-),-)", 1),
        ("right-right", [10, 20, 30], "10(-,20(-,30))", 1),
        ("left-right", [30, 10, 20], "30(10(-,20),-)", 2),
        ("right-left", [10, 30, 20], "10(-,30(20,-))", 2),
    ]
    for name, order, unbalanced, rotations in cases:
        avl.rotations = 0
        root = build(order)
        assert shape(root) == "20(10,30)", name
        assert avl.rotations == rotations, name
        check_avl(root)


def test_rebalance_directly_on_the_four_shapes():
    n = mk(30, mk(20, mk(10)))
    n.height = 3  # as if update(n) had been called
    assert shape(avl.rebalance(n)) == "20(10,30)"
    n = mk(30, mk(10, None, mk(20)))
    assert shape(avl.rebalance(n)) == "20(10,30)"
    n = mk(10, None, mk(20, None, mk(30)))
    assert shape(avl.rebalance(n)) == "20(10,30)"
    n = mk(10, None, mk(30, mk(20)))
    assert shape(avl.rebalance(n)) == "20(10,30)"


def test_inserting_1_to_7_counts_the_rotations_of_video_1():
    avl.rotations = 0
    root, seen = None, []
    for k in range(1, 8):
        root = avl.insert(root, k)
        seen.append(avl.rotations)
    assert seen == [0, 0, 1, 1, 2, 3, 4]
    assert shape(root) == "4(2(1,3),6(5,7))" and root.height == 3


def test_sorted_insertion_stays_logarithmic():
    for n, expected in ((1000, 10), (1023, 10), (2000, 11)):
        root = build(range(1, n + 1))
        assert root.height == expected
        assert inorder(root) == list(range(1, n + 1))
    avl.rotations = 0
    build(range(1, 1024))
    assert avl.rotations == 1013


def test_duplicates_are_ignored():
    root = build([5, 3, 8, 3, 5, 8, 1])
    assert inorder(root) == [1, 3, 5, 8]
    check_avl(root)


def test_random_insertions_keep_every_invariant():
    rng = random.Random(7)
    for _ in range(200):
        keys = [rng.randrange(500) for _ in range(rng.randrange(1, 120))]
        root = None
        for k in keys:
            root = avl.insert(root, k)
            check_avl(root)
        assert inorder(root) == sorted(set(keys))
        n = len(set(keys))
        assert root.height <= math.log(n + 1, (1 + 5 ** 0.5) / 2) + 1e-9  # h <= log_phi(n + 1)


def test_one_insertion_needs_at_most_two_single_rotations():
    rng = random.Random(8)
    root = None
    for k in rng.sample(range(10_000), 600):
        before = avl.rotations
        root = avl.insert(root, k)
        assert avl.rotations - before <= 2
