import random

import pytest

import ex6_rotate
from ex6_rotate import Node, rotate_left, rotate_right


def t(key, left=None, right=None):
    return Node(key, left, right)


def shape(n):
    if n is None:
        return "-"
    if n.left is None and n.right is None:
        return str(n.key)
    return f"{n.key}({shape(n.left)},{shape(n.right)})"


def inorder(n):
    return [] if n is None else inorder(n.left) + [n.key] + inorder(n.right)


def height(n):
    return 0 if n is None else 1 + max(height(n.left), height(n.right))


def root_of(n):
    while n.parent is not None:
        n = n.parent
    return n


def check_links(n, parent=None):
    """Every node's parent pointer must name the node that holds it as a child."""
    if n is None:
        return
    assert n.parent is parent, f"wrong parent link at {n.key}"
    check_links(n.left, n)
    check_links(n.right, n)


def test_right_rotation_of_the_root():
    root = t(30, t(20, t(10), t(25)), t(40))
    new = rotate_right(root)
    assert new.key == 20
    assert shape(new) == "20(10,30(25,40))"
    assert new.parent is None
    check_links(new)


def test_left_rotation_of_the_root():
    root = t(10, t(5), t(20, t(15), t(30)))
    new = rotate_left(root)
    assert shape(new) == "20(10(5,15),30)"
    check_links(new)


def test_the_middle_subtree_changes_sides():
    root = t(30, t(20, None, t(25)), None)
    new = rotate_right(root)
    assert shape(new) == "20(-,30(25,-))"
    assert new.right.left.key == 25
    check_links(new)


def test_rotation_inside_a_tree_keeps_the_parent_link_on_the_same_side():
    # x hangs on the LEFT of p
    p = t(50, t(30, t(20, t(10), None), t(40)), t(60))
    x = p.left
    y = rotate_right(x)
    assert y is p.left and y.key == 20
    assert shape(p) == "50(20(10,30(-,40)),60)"
    check_links(p)
    # x hangs on the RIGHT of p
    q = t(10, None, t(30, t(20, None, t(25)), t(40)))
    x = q.right
    y = rotate_right(x)
    assert y is q.right and shape(q) == "10(-,20(-,30(25,40)))"
    check_links(q)


def test_left_rotation_inside_a_tree_on_both_sides():
    p = t(50, t(10, None, t(30, t(20), t(40))), None)
    y = rotate_left(p.left)
    assert y is p.left and shape(p) == "50(30(10(-,20),40),-)"
    check_links(p)
    q = t(5, None, t(10, None, t(30, t(20), t(40))))
    y = rotate_left(q.right)
    assert y is q.right and shape(q) == "5(-,30(10(-,20),40))"
    check_links(q)


def test_a_chain_becomes_balanced():
    root = t(30, t(20, t(10)))
    assert height(root) == 3
    new = rotate_right(root)
    assert shape(new) == "20(10,30)" and height(new) == 2
    check_links(new)


def test_a_zig_zag_needs_two_rotations():
    root = t(30, t(10, None, t(20)))  # left-right case
    root.left = rotate_left(root.left)  # first rotate the CHILD...
    new = rotate_right(root)  # ...then the node
    assert shape(new) == "20(10,30)"
    check_links(new)


def test_a_rotation_can_be_undone():
    root = t(30, t(20, t(10), t(25)), t(40, t(35), t(50)))
    before = shape(root)
    new = rotate_right(root)
    back = rotate_left(new)
    assert shape(back) == before
    check_links(back)


def test_missing_child_raises():
    with pytest.raises(ValueError):
        rotate_right(t(1, None, t(2)))
    with pytest.raises(ValueError):
        rotate_left(t(2, t(1), None))


def random_tree(rng, n):
    keys = rng.sample(range(1000), n)
    root = None
    for k in keys:
        node = Node(k)
        if root is None:
            root = node
            continue
        cur = root
        while True:
            side = "left" if k < cur.key else "right"
            nxt = getattr(cur, side)
            if nxt is None:
                setattr(cur, side, node)
                node.parent = cur
                break
            cur = nxt
    return root


def all_nodes(n):
    return [] if n is None else [n] + all_nodes(n.left) + all_nodes(n.right)


def test_random_rotations_keep_the_order_and_the_links():
    rng = random.Random(6)
    for _ in range(300):
        root = random_tree(rng, rng.randrange(2, 40))
        keys = inorder(root)
        for _ in range(8):
            x = rng.choice(all_nodes(root))
            if rng.random() < 0.5 and x.left is not None:
                rotate_right(x)
            elif x.right is not None:
                rotate_left(x)
            root = root_of(root)
            assert inorder(root) == keys
            check_links(root)
