import bisect
import random

import ex6_sortedmap as sm

SCORES = [(72, "Ana"), (88, "Ben"), (95, "Cai"), (61, "Dee"), (79, "Eli"), (84, "Fay")]


def build(pairs):
    root = None
    for k, v in pairs:
        root = sm.insert(root, k, v)
    return root


def balanced(keys):
    """A perfectly balanced tree of the sorted keys (insert the middle first)."""
    root = None
    stack = [(0, len(keys) - 1)]
    while stack:
        lo, hi = stack.pop()
        if lo > hi:
            continue
        mid = (lo + hi) // 2
        root = sm.insert(root, keys[mid], str(keys[mid]))
        stack += [(lo, mid - 1), (mid + 1, hi)]
    return root


def height(n):
    return 0 if n is None else 1 + max(height(n.left), height(n.right))


def test_first_and_last():
    root = build(SCORES)
    assert sm.first(root) == (61, "Dee")
    assert sm.last(root) == (95, "Cai")
    assert sm.first(None) is None and sm.last(None) is None


def test_floor_and_ceiling_of_video_4():
    root = build(SCORES)
    assert sm.floor(root, 80) == (79, "Eli")
    assert sm.ceiling(root, 80) == (84, "Fay")
    assert sm.floor(root, 79) == (79, "Eli") and sm.ceiling(root, 79) == (79, "Eli")  # an exact hit is its own floor and ceiling


def test_floor_and_ceiling_outside_the_keys():
    root = build(SCORES)
    assert sm.floor(root, 60) is None
    assert sm.ceiling(root, 96) is None
    assert sm.floor(root, 1000) == (95, "Cai")
    assert sm.ceiling(root, -5) == (61, "Dee")
    assert sm.floor(None, 5) is None and sm.ceiling(None, 5) is None


def test_sub_map_is_half_open_and_in_order():
    root = build(SCORES)
    assert [k for k, _ in sm.sub_map(root, 70, 90)] == [72, 79, 84, 88]
    assert [k for k, _ in sm.sub_map(root, 72, 88)] == [72, 79, 84]  # lo included, hi excluded
    assert sm.sub_map(root, 89, 94) == []
    assert sm.sub_map(None, 0, 10) == []
    assert [k for k, _ in sm.sub_map(root, 0, 1000)] == [61, 72, 79, 84, 88, 95]


def test_the_queries_agree_with_bisect_on_random_trees():
    rng = random.Random(8)
    for _ in range(200):
        keys = sorted(rng.sample(range(300), rng.randrange(1, 60)))
        pairs = [(k, f"v{k}") for k in keys]
        shuffled = pairs[:]
        rng.shuffle(shuffled)
        root = build(shuffled)
        for _ in range(20):
            q = rng.randrange(-5, 310)
            i = bisect.bisect_right(keys, q)
            expected_floor = (keys[i - 1], f"v{keys[i - 1]}") if i > 0 else None
            j = bisect.bisect_left(keys, q)
            expected_ceiling = (keys[j], f"v{keys[j]}") if j < len(keys) else None
            assert sm.floor(root, q) == expected_floor
            assert sm.ceiling(root, q) == expected_ceiling
            hi = q + rng.randrange(0, 60)
            lo_i, hi_i = bisect.bisect_left(keys, q), bisect.bisect_left(keys, hi)
            assert sm.sub_map(root, q, hi) == pairs[lo_i:hi_i]


def test_sub_map_looks_only_at_the_subtrees_that_can_hold_the_range():
    keys = list(range(0, 2046, 2))  # 1023 keys, a balanced tree of height 10
    root = balanced(keys)
    h = height(root)
    rng = random.Random(9)
    for _ in range(300):
        lo = rng.randrange(-5, 2060)
        hi = lo + rng.randrange(0, 300)
        sm.visited = 0
        out = sm.sub_map(root, lo, hi)
        assert sm.visited <= 2 * h + len(out), (lo, hi, sm.visited, len(out))
    sm.visited = 0
    sm.sub_map(root, 1000, 1000)  # an empty range: just the two boundary paths
    assert sm.visited <= 2 * h
