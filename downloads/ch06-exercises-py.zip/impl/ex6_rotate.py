"""Exercise 6 (implementation): rotations on a binary tree whose nodes know their parent.

Three milestones, in order; run the tests after each one.

Milestone 1 -- rotate_right(x) for a node x that is the root of the whole tree (x.parent is None).
    Let y = x.left.  After the rotation y is the root of the subtree, x is the RIGHT child of y, and the
    subtree that used to be y.right (call it the middle subtree) becomes the LEFT child of x.  The in-order
    sequence of the keys does not change.  Return y, the new root of the subtree.
    Keep the parent links right: y.parent, x.parent and the parent of the middle subtree.
Milestone 2 -- the same when x has a parent p: y must hang from p on the SAME side where x used to hang
    (check whether p.left is x or p.right is x), and y.parent must become p.
Milestone 3 -- rotate_left(x), the mirror image (y = x.right, the middle subtree is y.left), and both
    functions raise ValueError when the child they need does not exist.

Run:  pytest test_ex6_rotate.py
"""


class Node:
    def __init__(self, key, left=None, right=None):
        self.key = key
        self.left = left
        self.right = right
        self.parent = None
        for child in (left, right):
            if child is not None:
                child.parent = self


def rotate_right(x):
    raise NotImplementedError


def rotate_left(x):
    raise NotImplementedError
