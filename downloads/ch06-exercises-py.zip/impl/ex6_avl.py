"""Exercise 7 (implementation): AVL insertion.

The rotations are given (they call update, which you write).  Three milestones, in order; run the tests
after each one.

Milestone 1 -- the bookkeeping.  A leaf has height 1 and an empty subtree (None) has height 0.
    height(n)   -> n.height, or 0 for None
    update(n)   -> set n.height = 1 + max(height(left), height(right))
    balance(n)  -> height(right) - height(left)   (the SAME convention as the videos: positive = leans right)
Milestone 2 -- rebalance(n): n has just been changed, its children are valid AVL trees but |balance(n)| may be 2.
    First update(n).  If balance(n) < -1 the node is left-heavy: when its left child leans RIGHT (balance > 0)
    rotate that child left first (the left-right case), then rotate n right.  The mirror image when
    balance(n) > 1.  Return the new root of the subtree (n itself when nothing is wrong).
Milestone 3 -- insert(root, key): the ordinary BST insertion (smaller keys go left, larger go right, a key
    that is already there is ignored), and on the way back up call rebalance on every node of the path.
    Return the new root of the whole tree.

Run:  pytest test_ex6_avl.py
"""

rotations = 0  # counts single rotations; a double rotation counts as two


class Node:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None
        self.height = 1  # a leaf has height 1; an empty subtree has height 0


def height(n):
    raise NotImplementedError


def update(n):
    raise NotImplementedError


def balance(n):
    raise NotImplementedError


def rotate_right(x):  # given
    global rotations
    rotations += 1
    y = x.left
    x.left = y.right
    y.right = x
    update(x)  # x is now below y, so x first
    update(y)
    return y


def rotate_left(x):  # given
    global rotations
    rotations += 1
    y = x.right
    x.right = y.left
    y.left = x
    update(x)
    update(y)
    return y


def rebalance(n):
    raise NotImplementedError


def insert(root, key):
    raise NotImplementedError
