"""Exercise 8 (implementation): the order queries of a sorted map, on a plain binary search tree.

Node and insert are given.  Write the five queries; each returns (key, value) pairs, or None when there is no
such entry.  Three milestones, in order; run the tests after each one.

Milestone 1 -- first(root) and last(root): the entry with the smallest / the largest key.
Milestone 2 -- floor(root, key) and ceiling(root, key): the entry with the GREATEST key <= key, and the entry
    with the SMALLEST key >= key.  A loop from the root that goes down ONE path is enough: whenever the current
    key is a candidate, remember it and keep looking for a closer one on the correct side.  O(height), no recursion needed.
Milestone 3 -- sub_map(root, lo, hi): the list of the entries with lo <= key < hi (half-open, as Java's
    TreeMap.subMap does) in increasing key order.  Do NOT visit the whole tree: skip a left subtree when
    every key in it is smaller than lo, and a right subtree when every key in it is >= hi.  Add 1 to the module
    variable `visited` once for every node you look at; the test checks that you visit at most 2 * height + k nodes
    for a range with k results.

Run:  pytest test_ex6_sortedmap.py
"""

visited = 0  # nodes examined by sub_map


class Node:
    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.left = None
        self.right = None


def insert(root, key, value):  # given: the plain BST insertion; a key that is already there gets the new value
    if root is None:
        return Node(key, value)
    cur = root
    while True:
        if key == cur.key:
            cur.value = value
            return root
        side = "left" if key < cur.key else "right"
        nxt = getattr(cur, side)
        if nxt is None:
            setattr(cur, side, Node(key, value))
            return root
        cur = nxt


def first(root):
    raise NotImplementedError


def last(root):
    raise NotImplementedError


def floor(root, key):
    raise NotImplementedError


def ceiling(root, key):
    raise NotImplementedError


def sub_map(root, lo, hi):
    raise NotImplementedError
