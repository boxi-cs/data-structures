"""Exercises 9 and 10 (read the code).  Each class below came from an AI assistant together with a claim.

In both exercises the claim is wrong because of a bug.  For each: find a small input that shows the bug
(insert the keys and check the AVL property with the HEIGHTS RECOMPUTED from the tree, not read from the
height field), say what exactly goes wrong and why small examples do not show it, and write the fix.

Exercise 9:  Avl9  -- "an AVL tree: insert rebalances with the right rotation for a left-heavy node and the
                       left rotation for a right-heavy node, so every balance factor stays in -1, 0, 1".
Exercise 10: Avl10 -- "an AVL tree whose rotations keep the stored heights up to date, so insert is O(log n)
                       and the height stays logarithmic".
"""


class Node:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None
        self.height = 1


def height(n):
    return n.height if n is not None else 0


def update(n):
    n.height = 1 + max(height(n.left), height(n.right))


def balance(n):
    return height(n.right) - height(n.left)  # positive = leans right


class Avl9:
    """An AVL tree.  insert uses the right rotation for a left-heavy node and the left rotation for a
    right-heavy node, so every balance factor stays in -1, 0, 1."""

    def __init__(self):
        self.root = None

    @staticmethod
    def rotate_right(x):
        y = x.left
        x.left = y.right
        y.right = x
        update(x)
        update(y)
        return y

    @staticmethod
    def rotate_left(x):
        y = x.right
        x.right = y.left
        y.left = x
        update(x)
        update(y)
        return y

    def rebalance(self, n):
        update(n)
        b = balance(n)
        if b < -1:
            return self.rotate_right(n)
        if b > 1:
            return self.rotate_left(n)
        return n

    def _insert(self, n, key):
        if n is None:
            return Node(key)
        if key < n.key:
            n.left = self._insert(n.left, key)
        elif key > n.key:
            n.right = self._insert(n.right, key)
        else:
            return n
        return self.rebalance(n)

    def insert(self, key):
        self.root = self._insert(self.root, key)


class Avl10:
    """An AVL tree whose rotations keep the stored heights up to date, so insert is O(log n) and the height
    stays logarithmic."""

    def __init__(self):
        self.root = None

    @staticmethod
    def rotate_right(x):
        y = x.left
        x.left = y.right
        y.right = x
        update(y)
        update(x)
        return y

    @staticmethod
    def rotate_left(x):
        y = x.right
        x.right = y.left
        y.left = x
        update(y)
        update(x)
        return y

    def rebalance(self, n):
        update(n)
        b = balance(n)
        if b < -1:
            if balance(n.left) > 0:
                n.left = self.rotate_left(n.left)
            return self.rotate_right(n)
        if b > 1:
            if balance(n.right) < 0:
                n.right = self.rotate_right(n.right)
            return self.rotate_left(n)
        return n

    def _insert(self, n, key):
        if n is None:
            return Node(key)
        if key < n.key:
            n.left = self._insert(n.left, key)
        elif key > n.key:
            n.right = self._insert(n.right, key)
        else:
            return n
        return self.rebalance(n)

    def insert(self, key):
        self.root = self._insert(self.root, key)
